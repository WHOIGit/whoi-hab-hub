--
-- PostgreSQL database dump
--

-- Dumped from database version 10.5 (Debian 10.5-2.pgdg90+1)
-- Dumped by pg_dump version 10.5 (Debian 10.5-2.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: account_emailaddress; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.account_emailaddress (
    id integer NOT NULL,
    email character varying(254) NOT NULL,
    verified boolean NOT NULL,
    "primary" boolean NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.account_emailaddress OWNER TO habmap_database;

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.account_emailaddress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailaddress_id_seq OWNER TO habmap_database;

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.account_emailaddress_id_seq OWNED BY public.account_emailaddress.id;


--
-- Name: account_emailconfirmation; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.account_emailconfirmation (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    sent timestamp with time zone,
    key character varying(64) NOT NULL,
    email_address_id integer NOT NULL
);


ALTER TABLE public.account_emailconfirmation OWNER TO habmap_database;

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.account_emailconfirmation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailconfirmation_id_seq OWNER TO habmap_database;

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.account_emailconfirmation_id_seq OWNED BY public.account_emailconfirmation.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO habmap_database;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO habmap_database;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO habmap_database;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO habmap_database;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO habmap_database;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO habmap_database;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO habmap_database;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO habmap_database;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO habmap_database;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO habmap_database;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO habmap_database;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO habmap_database;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO habmap_database;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO habmap_database;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.django_site_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO habmap_database;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: esp_instrument_deployment; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.esp_instrument_deployment (
    id integer NOT NULL,
    latitude numeric(10,7) NOT NULL,
    longitude numeric(10,7) NOT NULL,
    mooring_name character varying(100) NOT NULL,
    year integer NOT NULL,
    espinstrument_id integer NOT NULL
);


ALTER TABLE public.esp_instrument_deployment OWNER TO habmap_database;

--
-- Name: esp_instrument_deployment_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.esp_instrument_deployment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.esp_instrument_deployment_id_seq OWNER TO habmap_database;

--
-- Name: esp_instrument_deployment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.esp_instrument_deployment_id_seq OWNED BY public.esp_instrument_deployment.id;


--
-- Name: esp_instrument_espdatapoint; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.esp_instrument_espdatapoint (
    id integer NOT NULL,
    measurement character varying(20) NOT NULL,
    measurement_date timestamp with time zone NOT NULL,
    algal_species character varying(50) NOT NULL,
    deployment_id integer NOT NULL
);


ALTER TABLE public.esp_instrument_espdatapoint OWNER TO habmap_database;

--
-- Name: esp_instrument_espdatapoint_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.esp_instrument_espdatapoint_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.esp_instrument_espdatapoint_id_seq OWNER TO habmap_database;

--
-- Name: esp_instrument_espdatapoint_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.esp_instrument_espdatapoint_id_seq OWNED BY public.esp_instrument_espdatapoint.id;


--
-- Name: esp_instrument_espinstrument; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.esp_instrument_espinstrument (
    id integer NOT NULL,
    esp_name character varying(100) NOT NULL
);


ALTER TABLE public.esp_instrument_espinstrument OWNER TO habmap_database;

--
-- Name: esp_instrument_espinstrument_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.esp_instrument_espinstrument_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.esp_instrument_espinstrument_id_seq OWNER TO habmap_database;

--
-- Name: esp_instrument_espinstrument_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.esp_instrument_espinstrument_id_seq OWNED BY public.esp_instrument_espinstrument.id;


--
-- Name: socialaccount_socialaccount; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.socialaccount_socialaccount (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    uid character varying(191) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    extra_data text NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialaccount OWNER TO habmap_database;

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.socialaccount_socialaccount_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialaccount_id_seq OWNER TO habmap_database;

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.socialaccount_socialaccount_id_seq OWNED BY public.socialaccount_socialaccount.id;


--
-- Name: socialaccount_socialapp; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.socialaccount_socialapp (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    name character varying(40) NOT NULL,
    client_id character varying(191) NOT NULL,
    secret character varying(191) NOT NULL,
    key character varying(191) NOT NULL
);


ALTER TABLE public.socialaccount_socialapp OWNER TO habmap_database;

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.socialaccount_socialapp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_id_seq OWNER TO habmap_database;

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.socialaccount_socialapp_id_seq OWNED BY public.socialaccount_socialapp.id;


--
-- Name: socialaccount_socialapp_sites; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.socialaccount_socialapp_sites (
    id integer NOT NULL,
    socialapp_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialapp_sites OWNER TO habmap_database;

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.socialaccount_socialapp_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_sites_id_seq OWNER TO habmap_database;

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.socialaccount_socialapp_sites_id_seq OWNED BY public.socialaccount_socialapp_sites.id;


--
-- Name: socialaccount_socialtoken; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.socialaccount_socialtoken (
    id integer NOT NULL,
    token text NOT NULL,
    token_secret text NOT NULL,
    expires_at timestamp with time zone,
    account_id integer NOT NULL,
    app_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialtoken OWNER TO habmap_database;

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.socialaccount_socialtoken_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialtoken_id_seq OWNER TO habmap_database;

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.socialaccount_socialtoken_id_seq OWNED BY public.socialaccount_socialtoken.id;


--
-- Name: stations_datapoint; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.stations_datapoint (
    id integer NOT NULL,
    measurement character varying(20) NOT NULL,
    measurement_date timestamp with time zone NOT NULL,
    station_id integer NOT NULL,
    species_id integer
);


ALTER TABLE public.stations_datapoint OWNER TO habmap_database;

--
-- Name: stations_datapoint_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.stations_datapoint_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stations_datapoint_id_seq OWNER TO habmap_database;

--
-- Name: stations_datapoint_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.stations_datapoint_id_seq OWNED BY public.stations_datapoint.id;


--
-- Name: stations_species; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.stations_species (
    id integer NOT NULL,
    species_name character varying(100) NOT NULL,
    italicize boolean NOT NULL
);


ALTER TABLE public.stations_species OWNER TO habmap_database;

--
-- Name: stations_species_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.stations_species_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stations_species_id_seq OWNER TO habmap_database;

--
-- Name: stations_species_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.stations_species_id_seq OWNED BY public.stations_species.id;


--
-- Name: stations_station; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.stations_station (
    id integer NOT NULL,
    station_name character varying(100) NOT NULL,
    station_location character varying(100) NOT NULL,
    latitude numeric(10,7) NOT NULL,
    longitude numeric(10,7) NOT NULL,
    state character varying(50) NOT NULL
);


ALTER TABLE public.stations_station OWNER TO habmap_database;

--
-- Name: stations_station_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.stations_station_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stations_station_id_seq OWNER TO habmap_database;

--
-- Name: stations_station_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.stations_station_id_seq OWNED BY public.stations_station.id;


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.users_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.users_user OWNER TO habmap_database;

--
-- Name: users_user_groups; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.users_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.users_user_groups OWNER TO habmap_database;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.users_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_groups_id_seq OWNER TO habmap_database;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.users_user_groups_id_seq OWNED BY public.users_user_groups.id;


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO habmap_database;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users_user.id;


--
-- Name: users_user_user_permissions; Type: TABLE; Schema: public; Owner: habmap_database
--

CREATE TABLE public.users_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.users_user_user_permissions OWNER TO habmap_database;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: habmap_database
--

CREATE SEQUENCE public.users_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_user_permissions_id_seq OWNER TO habmap_database;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: habmap_database
--

ALTER SEQUENCE public.users_user_user_permissions_id_seq OWNED BY public.users_user_user_permissions.id;


--
-- Name: account_emailaddress id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.account_emailaddress ALTER COLUMN id SET DEFAULT nextval('public.account_emailaddress_id_seq'::regclass);


--
-- Name: account_emailconfirmation id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.account_emailconfirmation ALTER COLUMN id SET DEFAULT nextval('public.account_emailconfirmation_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: esp_instrument_deployment id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.esp_instrument_deployment ALTER COLUMN id SET DEFAULT nextval('public.esp_instrument_deployment_id_seq'::regclass);


--
-- Name: esp_instrument_espdatapoint id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.esp_instrument_espdatapoint ALTER COLUMN id SET DEFAULT nextval('public.esp_instrument_espdatapoint_id_seq'::regclass);


--
-- Name: esp_instrument_espinstrument id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.esp_instrument_espinstrument ALTER COLUMN id SET DEFAULT nextval('public.esp_instrument_espinstrument_id_seq'::regclass);


--
-- Name: socialaccount_socialaccount id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.socialaccount_socialaccount ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialaccount_id_seq'::regclass);


--
-- Name: socialaccount_socialapp id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.socialaccount_socialapp ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_id_seq'::regclass);


--
-- Name: socialaccount_socialapp_sites id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_sites_id_seq'::regclass);


--
-- Name: socialaccount_socialtoken id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.socialaccount_socialtoken ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialtoken_id_seq'::regclass);


--
-- Name: stations_datapoint id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.stations_datapoint ALTER COLUMN id SET DEFAULT nextval('public.stations_datapoint_id_seq'::regclass);


--
-- Name: stations_species id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.stations_species ALTER COLUMN id SET DEFAULT nextval('public.stations_species_id_seq'::regclass);


--
-- Name: stations_station id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.stations_station ALTER COLUMN id SET DEFAULT nextval('public.stations_station_id_seq'::regclass);


--
-- Name: users_user id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.users_user ALTER COLUMN id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: users_user_groups id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.users_user_groups ALTER COLUMN id SET DEFAULT nextval('public.users_user_groups_id_seq'::regclass);


--
-- Name: users_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.users_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.users_user_user_permissions_id_seq'::regclass);


--
-- Data for Name: account_emailaddress; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.account_emailaddress (id, email, verified, "primary", user_id) FROM stdin;
1	eandrews@whoi.edu	t	t	1
\.


--
-- Data for Name: account_emailconfirmation; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.account_emailconfirmation (id, created, sent, key, email_address_id) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can add group	2	add_group
5	Can change group	2	change_group
6	Can delete group	2	delete_group
7	Can add content type	3	add_contenttype
8	Can change content type	3	change_contenttype
9	Can delete content type	3	delete_contenttype
10	Can add session	4	add_session
11	Can change session	4	change_session
12	Can delete session	4	delete_session
13	Can add site	5	add_site
14	Can change site	5	change_site
15	Can delete site	5	delete_site
16	Can add log entry	6	add_logentry
17	Can change log entry	6	change_logentry
18	Can delete log entry	6	delete_logentry
19	Can add email address	7	add_emailaddress
20	Can change email address	7	change_emailaddress
21	Can delete email address	7	delete_emailaddress
22	Can add email confirmation	8	add_emailconfirmation
23	Can change email confirmation	8	change_emailconfirmation
24	Can delete email confirmation	8	delete_emailconfirmation
25	Can add social account	9	add_socialaccount
26	Can change social account	9	change_socialaccount
27	Can delete social account	9	delete_socialaccount
28	Can add social application	10	add_socialapp
29	Can change social application	10	change_socialapp
30	Can delete social application	10	delete_socialapp
31	Can add social application token	11	add_socialtoken
32	Can change social application token	11	change_socialtoken
33	Can delete social application token	11	delete_socialtoken
34	Can add user	12	add_user
35	Can change user	12	change_user
36	Can delete user	12	delete_user
37	Can add station	13	add_station
38	Can change station	13	change_station
39	Can delete station	13	delete_station
40	Can add datapoint	14	add_datapoint
41	Can change datapoint	14	change_datapoint
42	Can delete datapoint	14	delete_datapoint
43	Can add species	15	add_species
44	Can change species	15	change_species
45	Can delete species	15	delete_species
46	Can add esp instrument	16	add_espinstrument
47	Can change esp instrument	16	change_espinstrument
48	Can delete esp instrument	16	delete_espinstrument
49	Can add deployment	17	add_deployment
50	Can change deployment	17	change_deployment
51	Can delete deployment	17	delete_deployment
82	Can add esp datapoint	50	add_espdatapoint
83	Can change esp datapoint	50	change_espdatapoint
84	Can delete esp datapoint	50	delete_espdatapoint
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2018-12-17 20:01:16.947708+00	177	10.11	1	new through import_export	13	1
2	2018-12-17 20:01:16.954753+00	178	10.33	1	new through import_export	13	1
3	2018-12-17 20:01:16.960928+00	179	12.01	1	new through import_export	13	1
4	2018-12-17 20:01:16.96694+00	180	12.03	1	new through import_export	13	1
5	2018-12-17 20:01:16.972976+00	181	12.13	1	new through import_export	13	1
6	2018-12-17 20:01:16.978741+00	182	12.28	1	new through import_export	13	1
7	2018-12-17 20:01:16.985934+00	183	12.34	1	new through import_export	13	1
8	2018-12-17 20:01:16.993142+00	184	15.25	1	new through import_export	13	1
9	2018-12-17 20:01:17.000612+00	185	16.41	1	new through import_export	13	1
10	2018-12-17 20:01:17.007172+00	186	19.15	1	new through import_export	13	1
11	2018-12-17 20:01:17.013361+00	187	21.09	1	new through import_export	13	1
12	2018-12-17 20:01:17.019484+00	188	23.07	1	new through import_export	13	1
13	2018-12-17 20:01:17.025613+00	189	24.08	1	new through import_export	13	1
14	2018-12-17 20:01:17.031966+00	190	25.06	1	new through import_export	13	1
15	2018-12-17 20:01:17.038232+00	191	26.07	1	new through import_export	13	1
16	2018-12-17 20:01:17.044462+00	192	26.15	1	new through import_export	13	1
17	2018-12-17 20:01:17.050616+00	193	27.05	1	new through import_export	13	1
18	2018-12-17 20:01:17.056833+00	194	27.46	1	new through import_export	13	1
19	2018-12-17 20:01:17.062902+00	195	MB11	1	new through import_export	13	1
20	2018-12-17 20:01:17.068809+00	196	MB7	1	new through import_export	13	1
21	2018-12-17 20:01:17.076253+00	197	MB5	1	new through import_export	13	1
22	2018-12-17 20:01:17.082644+00	198	CCB42	1	new through import_export	13	1
23	2018-12-17 20:01:17.088897+00	199	BB45	1	new through import_export	13	1
24	2018-12-17 20:01:17.09558+00	200	OC3	1	new through import_export	13	1
25	2018-12-17 20:01:17.102521+00	201	OC5	1	new through import_export	13	1
26	2018-12-17 20:01:17.108755+00	202	OC6	1	new through import_export	13	1
27	2018-12-17 20:01:17.114922+00	203	SC52	1	new through import_export	13	1
28	2018-12-17 20:01:17.121288+00	204	CCB25	1	new through import_export	13	1
29	2018-12-17 20:01:17.127311+00	205	N2	1	new through import_export	13	1
30	2018-12-17 20:01:17.133318+00	206	N4	1	new through import_export	13	1
31	2018-12-17 20:01:17.139629+00	207	N7	1	new through import_export	13	1
32	2018-12-17 20:01:17.146168+00	208	N9	1	new through import_export	13	1
33	2018-12-17 20:01:17.152419+00	209	CCB4	1	new through import_export	13	1
34	2018-12-17 20:01:17.158754+00	210	CCB11	1	new through import_export	13	1
35	2018-12-17 20:01:17.165189+00	211	Unlisted	1	new through import_export	13	1
36	2018-12-17 20:01:17.171436+00	212	OC6	1	new through import_export	13	1
37	2018-12-17 20:01:17.177416+00	213	OC5	1	new through import_export	13	1
38	2018-12-17 20:01:17.18348+00	214	V24	1	new through import_export	13	1
39	2018-12-17 20:01:17.189922+00	215	N2	1	new through import_export	13	1
40	2018-12-17 20:01:17.19643+00	216	N4	1	new through import_export	13	1
41	2018-12-17 20:01:17.202829+00	217	N7	1	new through import_export	13	1
42	2018-12-17 20:01:17.209678+00	218	N9	1	new through import_export	13	1
43	2018-12-17 20:01:17.216471+00	219	NT3	1	new through import_export	13	1
44	2018-12-18 19:03:31.592998+00	75	Datapoint object (75)	1	new through import_export	14	1
45	2018-12-18 19:03:31.601559+00	76	Datapoint object (76)	1	new through import_export	14	1
46	2018-12-18 19:03:31.60791+00	77	Datapoint object (77)	1	new through import_export	14	1
47	2018-12-18 19:03:31.614191+00	78	Datapoint object (78)	1	new through import_export	14	1
48	2018-12-18 19:03:31.620172+00	79	Datapoint object (79)	1	new through import_export	14	1
49	2018-12-18 19:03:31.626638+00	80	Datapoint object (80)	1	new through import_export	14	1
50	2018-12-18 19:03:31.633234+00	81	Datapoint object (81)	1	new through import_export	14	1
51	2018-12-18 19:03:31.639487+00	82	Datapoint object (82)	1	new through import_export	14	1
52	2018-12-18 19:03:31.645536+00	83	Datapoint object (83)	1	new through import_export	14	1
53	2018-12-18 19:03:31.651505+00	84	Datapoint object (84)	1	new through import_export	14	1
54	2018-12-18 19:03:31.657911+00	85	Datapoint object (85)	1	new through import_export	14	1
55	2018-12-18 19:03:31.664536+00	86	Datapoint object (86)	1	new through import_export	14	1
56	2018-12-18 19:03:31.670692+00	87	Datapoint object (87)	1	new through import_export	14	1
57	2018-12-18 19:03:31.676605+00	88	Datapoint object (88)	1	new through import_export	14	1
58	2018-12-18 19:03:31.682763+00	89	Datapoint object (89)	1	new through import_export	14	1
59	2018-12-18 19:03:31.689069+00	90	Datapoint object (90)	1	new through import_export	14	1
60	2018-12-18 19:03:31.695428+00	91	Datapoint object (91)	1	new through import_export	14	1
61	2018-12-18 19:03:31.701491+00	92	Datapoint object (92)	1	new through import_export	14	1
62	2018-12-18 19:03:31.7074+00	93	Datapoint object (93)	1	new through import_export	14	1
63	2018-12-18 19:03:31.713117+00	94	Datapoint object (94)	1	new through import_export	14	1
64	2018-12-18 19:03:31.718886+00	95	Datapoint object (95)	1	new through import_export	14	1
65	2018-12-18 19:03:31.725259+00	96	Datapoint object (96)	1	new through import_export	14	1
66	2018-12-18 19:03:31.731623+00	97	Datapoint object (97)	1	new through import_export	14	1
67	2018-12-18 19:03:31.737552+00	98	Datapoint object (98)	1	new through import_export	14	1
68	2018-12-18 19:03:31.744635+00	99	Datapoint object (99)	1	new through import_export	14	1
69	2018-12-18 19:03:31.751047+00	100	Datapoint object (100)	1	new through import_export	14	1
70	2018-12-18 19:03:31.757669+00	101	Datapoint object (101)	1	new through import_export	14	1
71	2018-12-18 19:03:31.764157+00	102	Datapoint object (102)	1	new through import_export	14	1
72	2018-12-18 19:03:31.770385+00	103	Datapoint object (103)	1	new through import_export	14	1
73	2018-12-18 19:03:31.776255+00	104	Datapoint object (104)	1	new through import_export	14	1
74	2018-12-18 19:03:31.782177+00	105	Datapoint object (105)	1	new through import_export	14	1
75	2018-12-18 19:03:31.787757+00	106	Datapoint object (106)	1	new through import_export	14	1
76	2018-12-18 19:03:31.794513+00	107	Datapoint object (107)	1	new through import_export	14	1
77	2018-12-18 19:03:31.800798+00	108	Datapoint object (108)	1	new through import_export	14	1
78	2018-12-18 19:03:31.807172+00	109	Datapoint object (109)	1	new through import_export	14	1
79	2018-12-18 19:03:31.813755+00	110	Datapoint object (110)	1	new through import_export	14	1
80	2018-12-18 19:03:31.819886+00	111	Datapoint object (111)	1	new through import_export	14	1
81	2018-12-18 19:03:31.826254+00	112	Datapoint object (112)	1	new through import_export	14	1
161	2018-12-18 19:49:21.923886+00	109	10.11 - 2017-06-12 04:00:00+00:00	3		14	1
82	2018-12-18 19:03:31.832127+00	113	Datapoint object (113)	1	new through import_export	14	1
83	2018-12-18 19:03:31.841435+00	114	Datapoint object (114)	1	new through import_export	14	1
84	2018-12-18 19:03:31.84752+00	115	Datapoint object (115)	1	new through import_export	14	1
85	2018-12-18 19:03:31.853847+00	116	Datapoint object (116)	1	new through import_export	14	1
86	2018-12-18 19:03:31.860693+00	117	Datapoint object (117)	1	new through import_export	14	1
87	2018-12-18 19:03:31.86709+00	118	Datapoint object (118)	1	new through import_export	14	1
88	2018-12-18 19:03:31.873669+00	119	Datapoint object (119)	1	new through import_export	14	1
89	2018-12-18 19:03:31.879951+00	120	Datapoint object (120)	1	new through import_export	14	1
90	2018-12-18 19:03:31.887457+00	121	Datapoint object (121)	1	new through import_export	14	1
91	2018-12-18 19:03:31.894058+00	122	Datapoint object (122)	1	new through import_export	14	1
92	2018-12-18 19:03:31.900201+00	123	Datapoint object (123)	1	new through import_export	14	1
93	2018-12-18 19:03:31.906828+00	124	Datapoint object (124)	1	new through import_export	14	1
94	2018-12-18 19:03:31.913137+00	125	Datapoint object (125)	1	new through import_export	14	1
95	2018-12-18 19:03:31.919755+00	126	Datapoint object (126)	1	new through import_export	14	1
96	2018-12-18 19:03:31.926385+00	127	Datapoint object (127)	1	new through import_export	14	1
97	2018-12-18 19:03:31.932858+00	128	Datapoint object (128)	1	new through import_export	14	1
98	2018-12-18 19:03:31.938977+00	129	Datapoint object (129)	1	new through import_export	14	1
99	2018-12-18 19:03:31.945185+00	130	Datapoint object (130)	1	new through import_export	14	1
100	2018-12-18 19:03:31.951345+00	131	Datapoint object (131)	1	new through import_export	14	1
101	2018-12-18 19:03:31.957575+00	132	Datapoint object (132)	1	new through import_export	14	1
102	2018-12-18 19:03:31.964173+00	133	Datapoint object (133)	1	new through import_export	14	1
103	2018-12-18 19:03:31.970961+00	134	Datapoint object (134)	1	new through import_export	14	1
104	2018-12-18 19:03:31.977207+00	135	Datapoint object (135)	1	new through import_export	14	1
105	2018-12-18 19:03:31.983261+00	136	Datapoint object (136)	1	new through import_export	14	1
106	2018-12-18 19:03:31.989342+00	137	Datapoint object (137)	1	new through import_export	14	1
107	2018-12-18 19:03:31.995623+00	138	Datapoint object (138)	1	new through import_export	14	1
108	2018-12-18 19:03:32.001349+00	139	Datapoint object (139)	1	new through import_export	14	1
109	2018-12-18 19:03:32.007422+00	140	Datapoint object (140)	1	new through import_export	14	1
110	2018-12-18 19:03:32.013461+00	141	Datapoint object (141)	1	new through import_export	14	1
111	2018-12-18 19:03:32.019281+00	142	Datapoint object (142)	1	new through import_export	14	1
112	2018-12-18 19:03:32.025815+00	143	Datapoint object (143)	1	new through import_export	14	1
113	2018-12-18 19:03:32.032566+00	144	Datapoint object (144)	1	new through import_export	14	1
114	2018-12-18 19:03:32.039263+00	145	Datapoint object (145)	1	new through import_export	14	1
115	2018-12-18 19:03:32.045288+00	146	Datapoint object (146)	1	new through import_export	14	1
116	2018-12-18 19:03:32.052906+00	147	Datapoint object (147)	1	new through import_export	14	1
117	2018-12-18 19:03:32.059109+00	148	Datapoint object (148)	1	new through import_export	14	1
118	2018-12-18 19:44:07.443813+00	1	Mytilus edulis	1	[{"added": {}}]	15	1
119	2018-12-18 19:44:16.456873+00	2	Ocean Quahog	1	[{"added": {}}]	15	1
120	2018-12-18 19:44:46.022193+00	3	Mya arenaria	1	[{"added": {}}]	15	1
121	2018-12-18 19:44:53.707085+00	4	Other	1	[{"added": {}}]	15	1
122	2018-12-18 19:49:21.647841+00	148	10.11 - 2018-03-12 04:00:00+00:00	3		14	1
123	2018-12-18 19:49:21.656371+00	147	10.11 - 2017-10-16 04:00:00+00:00	3		14	1
124	2018-12-18 19:49:21.663671+00	146	10.11 - 2017-10-15 04:00:00+00:00	3		14	1
125	2018-12-18 19:49:21.670409+00	145	10.11 - 2017-10-10 04:00:00+00:00	3		14	1
126	2018-12-18 19:49:21.67696+00	144	10.11 - 2017-10-02 04:00:00+00:00	3		14	1
127	2018-12-18 19:49:21.683575+00	143	10.11 - 2017-09-18 04:00:00+00:00	3		14	1
128	2018-12-18 19:49:21.690519+00	142	10.11 - 2017-09-17 04:00:00+00:00	3		14	1
129	2018-12-18 19:49:21.698774+00	141	10.11 - 2017-09-11 04:00:00+00:00	3		14	1
130	2018-12-18 19:49:21.705614+00	140	10.11 - 2017-09-10 04:00:00+00:00	3		14	1
131	2018-12-18 19:49:21.712428+00	139	10.11 - 2017-09-05 04:00:00+00:00	3		14	1
132	2018-12-18 19:49:21.719818+00	138	10.11 - 2017-09-04 04:00:00+00:00	3		14	1
133	2018-12-18 19:49:21.726903+00	137	10.11 - 2017-09-03 04:00:00+00:00	3		14	1
134	2018-12-18 19:49:21.733694+00	136	10.11 - 2017-08-23 04:00:00+00:00	3		14	1
135	2018-12-18 19:49:21.740198+00	135	10.11 - 2017-08-22 04:00:00+00:00	3		14	1
136	2018-12-18 19:49:21.746929+00	134	10.11 - 2017-08-21 04:00:00+00:00	3		14	1
137	2018-12-18 19:49:21.753836+00	133	10.11 - 2017-08-20 04:00:00+00:00	3		14	1
138	2018-12-18 19:49:21.761041+00	132	10.11 - 2017-08-17 04:00:00+00:00	3		14	1
139	2018-12-18 19:49:21.76799+00	131	10.11 - 2017-08-14 04:00:00+00:00	3		14	1
140	2018-12-18 19:49:21.774801+00	130	10.11 - 2017-08-13 04:00:00+00:00	3		14	1
141	2018-12-18 19:49:21.782616+00	129	10.11 - 2017-08-08 04:00:00+00:00	3		14	1
142	2018-12-18 19:49:21.789815+00	128	10.11 - 2017-08-07 04:00:00+00:00	3		14	1
143	2018-12-18 19:49:21.796607+00	127	10.11 - 2017-08-06 04:00:00+00:00	3		14	1
144	2018-12-18 19:49:21.803894+00	126	10.11 - 2017-07-31 04:00:00+00:00	3		14	1
145	2018-12-18 19:49:21.811128+00	125	10.11 - 2017-07-30 04:00:00+00:00	3		14	1
146	2018-12-18 19:49:21.817758+00	124	10.11 - 2017-07-24 04:00:00+00:00	3		14	1
147	2018-12-18 19:49:21.825546+00	123	10.11 - 2017-07-23 04:00:00+00:00	3		14	1
148	2018-12-18 19:49:21.8347+00	122	10.11 - 2017-07-17 04:00:00+00:00	3		14	1
149	2018-12-18 19:49:21.841905+00	121	10.11 - 2017-07-16 04:00:00+00:00	3		14	1
150	2018-12-18 19:49:21.848705+00	120	10.11 - 2017-07-14 04:00:00+00:00	3		14	1
151	2018-12-18 19:49:21.856029+00	119	10.11 - 2017-07-10 04:00:00+00:00	3		14	1
152	2018-12-18 19:49:21.863323+00	118	10.11 - 2017-07-09 04:00:00+00:00	3		14	1
153	2018-12-18 19:49:21.87007+00	117	10.11 - 2017-07-05 04:00:00+00:00	3		14	1
154	2018-12-18 19:49:21.876669+00	116	10.11 - 2017-07-02 04:00:00+00:00	3		14	1
155	2018-12-18 19:49:21.883431+00	115	10.11 - 2017-06-26 04:00:00+00:00	3		14	1
156	2018-12-18 19:49:21.890397+00	114	10.11 - 2017-06-25 04:00:00+00:00	3		14	1
157	2018-12-18 19:49:21.897554+00	113	10.11 - 2017-06-23 04:00:00+00:00	3		14	1
158	2018-12-18 19:49:21.904207+00	112	10.11 - 2017-06-22 04:00:00+00:00	3		14	1
159	2018-12-18 19:49:21.910594+00	111	10.11 - 2017-06-19 04:00:00+00:00	3		14	1
160	2018-12-18 19:49:21.917+00	110	10.11 - 2017-06-18 04:00:00+00:00	3		14	1
162	2018-12-18 19:49:21.931044+00	108	10.11 - 2017-06-11 04:00:00+00:00	3		14	1
163	2018-12-18 19:49:21.93735+00	107	10.11 - 2017-06-10 04:00:00+00:00	3		14	1
164	2018-12-18 19:49:21.94411+00	106	10.11 - 2017-06-09 04:00:00+00:00	3		14	1
165	2018-12-18 19:49:21.950749+00	105	10.11 - 2017-06-05 04:00:00+00:00	3		14	1
166	2018-12-18 19:49:21.958432+00	104	10.11 - 2017-06-04 04:00:00+00:00	3		14	1
167	2018-12-18 19:49:21.965325+00	103	10.11 - 2017-06-02 04:00:00+00:00	3		14	1
168	2018-12-18 19:49:21.971856+00	102	10.11 - 2017-05-30 04:00:00+00:00	3		14	1
169	2018-12-18 19:49:21.978213+00	101	10.11 - 2017-05-29 04:00:00+00:00	3		14	1
170	2018-12-18 19:49:21.984655+00	100	10.11 - 2017-05-28 04:00:00+00:00	3		14	1
171	2018-12-18 19:49:21.991706+00	99	10.11 - 2017-05-22 04:00:00+00:00	3		14	1
172	2018-12-18 19:49:21.998379+00	98	10.11 - 2017-05-21 04:00:00+00:00	3		14	1
173	2018-12-18 19:49:22.004767+00	97	10.11 - 2017-05-15 04:00:00+00:00	3		14	1
174	2018-12-18 19:49:22.01103+00	96	10.11 - 2017-05-14 04:00:00+00:00	3		14	1
175	2018-12-18 19:49:22.017133+00	95	10.11 - 2017-05-10 04:00:00+00:00	3		14	1
176	2018-12-18 19:49:22.024206+00	94	10.11 - 2017-05-09 04:00:00+00:00	3		14	1
177	2018-12-18 19:49:22.030416+00	93	10.11 - 2017-05-08 04:00:00+00:00	3		14	1
178	2018-12-18 19:49:22.037221+00	92	10.11 - 2017-05-07 04:00:00+00:00	3		14	1
179	2018-12-18 19:49:22.043172+00	91	10.11 - 2017-05-01 04:00:00+00:00	3		14	1
180	2018-12-18 19:49:22.049657+00	90	10.11 - 2017-04-30 04:00:00+00:00	3		14	1
181	2018-12-18 19:49:22.056293+00	89	10.11 - 2017-04-25 04:00:00+00:00	3		14	1
182	2018-12-18 19:49:22.06252+00	88	10.11 - 2017-04-24 04:00:00+00:00	3		14	1
183	2018-12-18 19:49:22.069064+00	87	10.11 - 2017-04-23 04:00:00+00:00	3		14	1
184	2018-12-18 19:49:22.075168+00	86	10.11 - 2017-04-20 04:00:00+00:00	3		14	1
185	2018-12-18 19:49:22.082994+00	85	10.11 - 2017-04-17 04:00:00+00:00	3		14	1
186	2018-12-18 19:49:22.090095+00	84	10.11 - 2017-04-16 04:00:00+00:00	3		14	1
187	2018-12-18 19:49:22.096587+00	83	10.11 - 2017-04-11 04:00:00+00:00	3		14	1
188	2018-12-18 19:49:22.103244+00	82	10.11 - 2017-04-10 04:00:00+00:00	3		14	1
189	2018-12-18 19:49:22.110286+00	81	10.11 - 2017-04-09 04:00:00+00:00	3		14	1
190	2018-12-18 19:49:22.125749+00	80	10.11 - 2017-04-03 04:00:00+00:00	3		14	1
191	2018-12-18 19:49:22.148351+00	79	10.11 - 2017-04-02 04:00:00+00:00	3		14	1
192	2018-12-18 19:49:22.180494+00	78	10.11 - 2017-03-27 04:00:00+00:00	3		14	1
193	2018-12-18 19:49:22.192591+00	77	10.11 - 2017-03-26 04:00:00+00:00	3		14	1
194	2018-12-18 19:49:22.201752+00	76	10.11 - 2017-03-19 04:00:00+00:00	3		14	1
195	2018-12-18 19:49:22.20888+00	75	10.11 - 2017-03-12 05:00:00+00:00	3		14	1
196	2018-12-18 19:50:04.665527+00	223	10.11 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
197	2018-12-18 19:50:04.672389+00	224	10.11 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
198	2018-12-18 19:50:04.678619+00	225	10.11 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
199	2018-12-18 19:50:04.685162+00	226	10.11 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
200	2018-12-18 19:50:04.691269+00	227	10.11 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
201	2018-12-18 19:50:04.697595+00	228	10.11 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
202	2018-12-18 19:50:04.704105+00	229	10.11 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
203	2018-12-18 19:50:04.710014+00	230	10.11 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
204	2018-12-18 19:50:04.715574+00	231	10.11 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
205	2018-12-18 19:50:04.721114+00	232	10.11 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
206	2018-12-18 19:50:04.728497+00	233	10.11 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
207	2018-12-18 19:50:04.735064+00	234	10.11 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
208	2018-12-18 19:50:04.741408+00	235	10.11 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
209	2018-12-18 19:50:04.747607+00	236	10.11 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
210	2018-12-18 19:50:04.753988+00	237	10.11 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
211	2018-12-18 19:50:04.760021+00	238	10.11 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
212	2018-12-18 19:50:04.766018+00	239	10.11 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
213	2018-12-18 19:50:04.772701+00	240	10.11 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
214	2018-12-18 19:50:04.778801+00	241	10.11 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
215	2018-12-18 19:50:04.784767+00	242	10.11 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
216	2018-12-18 19:50:04.791121+00	243	10.11 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
217	2018-12-18 19:50:04.79686+00	244	10.11 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
218	2018-12-18 19:50:04.802907+00	245	10.11 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
219	2018-12-18 19:50:04.809666+00	246	10.11 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
220	2018-12-18 19:50:04.815553+00	247	10.11 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
221	2018-12-18 19:50:04.821544+00	248	10.11 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
222	2018-12-18 19:50:04.827193+00	249	10.11 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
223	2018-12-18 19:50:04.833898+00	250	10.11 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
224	2018-12-18 19:50:04.840504+00	251	10.11 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
225	2018-12-18 19:50:04.846497+00	252	10.11 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
226	2018-12-18 19:50:04.853518+00	253	10.11 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
227	2018-12-18 19:50:04.859987+00	254	10.11 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
228	2018-12-18 19:50:04.865698+00	255	10.11 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
229	2018-12-18 19:50:04.871525+00	256	10.11 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
230	2018-12-18 19:50:04.879348+00	257	10.11 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
231	2018-12-18 19:50:04.885804+00	258	10.11 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
232	2018-12-18 19:50:04.892487+00	259	10.11 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
233	2018-12-18 19:50:04.899465+00	260	10.11 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
234	2018-12-18 19:50:04.906684+00	261	10.11 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
235	2018-12-18 19:50:04.912887+00	262	10.11 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
236	2018-12-18 19:50:04.918817+00	263	10.11 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
237	2018-12-18 19:50:04.925265+00	264	10.11 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
238	2018-12-18 19:50:04.931612+00	265	10.11 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
239	2018-12-18 19:50:04.938586+00	266	10.11 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
240	2018-12-18 19:50:04.945111+00	267	10.11 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
241	2018-12-18 19:50:04.951362+00	268	10.11 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
242	2018-12-18 19:50:04.958059+00	269	10.11 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
243	2018-12-18 19:50:04.964291+00	270	10.11 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
244	2018-12-18 19:50:04.970723+00	271	10.11 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
245	2018-12-18 19:50:04.97682+00	272	10.11 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
246	2018-12-18 19:50:04.982853+00	273	10.11 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
247	2018-12-18 19:50:04.988649+00	274	10.11 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
248	2018-12-18 19:50:04.995165+00	275	10.11 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
249	2018-12-18 19:50:05.001397+00	276	10.11 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
250	2018-12-18 19:50:05.007771+00	277	10.11 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
251	2018-12-18 19:50:05.014228+00	278	10.11 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
252	2018-12-18 19:50:05.020539+00	279	10.11 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
253	2018-12-18 19:50:05.026641+00	280	10.11 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
254	2018-12-18 19:50:05.032217+00	281	10.11 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
255	2018-12-18 19:50:05.03869+00	282	10.11 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
256	2018-12-18 19:50:05.044631+00	283	10.11 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
257	2018-12-18 19:50:05.050401+00	284	10.11 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
258	2018-12-18 19:50:05.056215+00	285	10.11 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
259	2018-12-18 19:50:05.063138+00	286	10.11 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
260	2018-12-18 19:50:05.069133+00	287	10.11 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
261	2018-12-18 19:50:05.088286+00	288	10.11 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
262	2018-12-18 19:50:05.105592+00	289	10.11 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
263	2018-12-18 19:50:05.119231+00	290	10.11 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
264	2018-12-18 19:50:05.150862+00	291	10.11 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
265	2018-12-18 19:50:05.157562+00	292	10.11 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
266	2018-12-18 19:50:05.164065+00	293	10.11 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
267	2018-12-18 19:50:05.170286+00	294	10.11 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
268	2018-12-18 19:50:05.176578+00	295	10.11 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
269	2018-12-18 19:50:05.182675+00	296	10.11 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
270	2018-12-18 19:52:20.492775+00	215	N2	3		13	1
271	2018-12-18 19:52:20.500592+00	216	N4	3		13	1
272	2018-12-18 19:52:20.508352+00	217	N7	3		13	1
273	2018-12-18 19:52:20.515252+00	218	N9	3		13	1
274	2018-12-18 19:52:20.522077+00	213	OC5	3		13	1
275	2018-12-18 19:52:20.528757+00	212	OC6	3		13	1
276	2018-12-18 19:58:45.564684+00	371	MB11 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
277	2018-12-18 19:58:45.571481+00	372	MB11 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
278	2018-12-18 19:58:45.577619+00	373	MB11 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
279	2018-12-18 19:58:45.584487+00	374	MB11 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
280	2018-12-18 19:58:45.591037+00	375	MB11 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
281	2018-12-18 19:58:45.597566+00	376	MB11 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
282	2018-12-18 19:58:45.603766+00	377	MB11 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
283	2018-12-18 19:58:45.610525+00	378	MB11 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
284	2018-12-18 19:58:45.617156+00	379	MB11 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
285	2018-12-18 19:58:45.62324+00	380	MB11 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
286	2018-12-18 19:58:45.629099+00	381	MB11 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
287	2018-12-18 19:58:45.634837+00	382	MB11 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
288	2018-12-18 19:58:45.640672+00	383	MB11 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
289	2018-12-18 19:58:45.647612+00	384	MB11 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
290	2018-12-18 19:58:45.653857+00	385	MB11 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
291	2018-12-18 19:58:45.660305+00	386	MB11 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
292	2018-12-18 19:58:45.666391+00	387	MB11 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
293	2018-12-18 19:58:45.673464+00	388	MB11 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
294	2018-12-18 19:58:45.680624+00	389	MB11 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
295	2018-12-18 19:58:45.686755+00	390	MB11 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
296	2018-12-18 19:58:45.692721+00	391	MB11 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
297	2018-12-18 19:58:45.698471+00	392	MB11 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
298	2018-12-18 19:58:45.705145+00	393	MB11 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
299	2018-12-18 19:58:45.711169+00	394	MB11 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
300	2018-12-18 19:58:45.717758+00	395	MB11 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
301	2018-12-18 19:58:45.723792+00	396	MB11 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
302	2018-12-18 19:58:45.729447+00	397	MB11 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
303	2018-12-18 19:58:45.735652+00	398	MB11 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
304	2018-12-18 19:58:45.741307+00	399	MB11 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
305	2018-12-18 19:58:45.747966+00	400	MB11 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
306	2018-12-18 19:58:45.753994+00	401	MB11 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
307	2018-12-18 19:58:45.759649+00	402	MB11 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
308	2018-12-18 19:58:45.765466+00	403	MB11 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
309	2018-12-18 19:58:45.772917+00	404	MB11 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
310	2018-12-18 19:58:45.77973+00	405	MB11 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
311	2018-12-18 19:58:45.785815+00	406	MB11 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
312	2018-12-18 19:58:45.791677+00	407	MB11 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
313	2018-12-18 19:58:45.797695+00	408	MB11 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
314	2018-12-18 19:58:45.803558+00	409	MB11 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
315	2018-12-18 19:58:45.80908+00	410	MB11 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
316	2018-12-18 19:58:45.825898+00	411	MB11 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
317	2018-12-18 19:58:45.836827+00	412	MB11 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
318	2018-12-18 19:58:45.852741+00	413	MB11 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
319	2018-12-18 19:58:45.865644+00	414	MB11 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
320	2018-12-18 19:58:45.898651+00	415	MB11 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
321	2018-12-18 19:58:45.904744+00	416	MB11 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
322	2018-12-18 19:58:45.911085+00	417	MB11 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
323	2018-12-18 19:58:45.917603+00	418	MB11 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
324	2018-12-18 19:58:45.923802+00	419	MB11 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
325	2018-12-18 19:58:45.92965+00	420	MB11 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
326	2018-12-18 19:58:45.935559+00	421	MB11 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
327	2018-12-18 19:58:45.941163+00	422	MB11 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
328	2018-12-18 19:58:45.947391+00	423	MB11 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
329	2018-12-18 19:58:45.954681+00	424	MB11 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
330	2018-12-18 19:58:45.961261+00	425	MB11 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
331	2018-12-18 19:58:45.967205+00	426	MB11 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
332	2018-12-18 19:58:45.973274+00	427	MB11 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
333	2018-12-18 19:58:45.980335+00	428	MB11 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
334	2018-12-18 19:58:45.986423+00	429	MB11 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
335	2018-12-18 19:58:45.992413+00	430	MB11 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
336	2018-12-18 19:58:45.99847+00	431	MB11 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
337	2018-12-18 19:58:46.004095+00	432	MB11 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
338	2018-12-18 19:58:46.009573+00	433	MB11 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
339	2018-12-18 19:58:46.016168+00	434	MB11 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
340	2018-12-18 19:58:46.022115+00	435	MB11 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
341	2018-12-18 19:58:46.027653+00	436	MB11 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
342	2018-12-18 19:58:46.033301+00	437	MB11 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
343	2018-12-18 19:58:46.038799+00	438	MB11 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
344	2018-12-18 19:58:46.044641+00	439	MB11 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
345	2018-12-18 19:58:46.051415+00	440	MB11 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
346	2018-12-18 19:58:46.057275+00	441	MB11 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
347	2018-12-18 19:58:46.062959+00	442	MB11 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
348	2018-12-18 19:58:46.068441+00	443	MB11 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
349	2018-12-18 19:58:46.074146+00	444	MB11 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
350	2019-01-03 19:41:20.407114+00	519	10.33 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
351	2019-01-03 19:41:20.417549+00	520	10.33 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
352	2019-01-03 19:41:20.424283+00	521	10.33 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
353	2019-01-03 19:41:20.430488+00	522	10.33 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
354	2019-01-03 19:41:20.436501+00	523	10.33 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
355	2019-01-03 19:41:20.442638+00	524	10.33 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
356	2019-01-03 19:41:20.448823+00	525	10.33 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
357	2019-01-03 19:41:20.455351+00	526	10.33 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
358	2019-01-03 19:41:20.461529+00	527	10.33 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
359	2019-01-03 19:41:20.46772+00	528	10.33 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
360	2019-01-03 19:41:20.473864+00	529	10.33 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
361	2019-01-03 19:41:20.479877+00	530	10.33 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
362	2019-01-03 19:41:20.486109+00	531	10.33 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
363	2019-01-03 19:41:20.492371+00	532	10.33 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
364	2019-01-03 19:41:20.499204+00	533	10.33 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
365	2019-01-03 19:41:20.505196+00	534	10.33 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
366	2019-01-03 19:41:20.51108+00	535	10.33 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
435	2019-01-18 19:16:31.649813+00	8	2016 - ESP Dennis - ESP-2	1	[{"added": {}}]	17	1
367	2019-01-03 19:41:20.516813+00	536	10.33 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
368	2019-01-03 19:41:20.530246+00	537	10.33 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
369	2019-01-03 19:41:20.5467+00	538	10.33 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
370	2019-01-03 19:41:20.567249+00	539	10.33 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
371	2019-01-03 19:41:20.58177+00	540	10.33 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
372	2019-01-03 19:41:20.607257+00	541	10.33 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
373	2019-01-03 19:41:20.615072+00	542	10.33 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
374	2019-01-03 19:41:20.621438+00	543	10.33 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
375	2019-01-03 19:41:20.627629+00	544	10.33 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
376	2019-01-03 19:41:20.633524+00	545	10.33 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
377	2019-01-03 19:41:20.640655+00	546	10.33 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
378	2019-01-03 19:41:20.64687+00	547	10.33 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
379	2019-01-03 19:41:20.652806+00	548	10.33 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
380	2019-01-03 19:41:20.658738+00	549	10.33 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
381	2019-01-03 19:41:20.664577+00	550	10.33 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
382	2019-01-03 19:41:20.670694+00	551	10.33 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
383	2019-01-03 19:41:20.676223+00	552	10.33 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
384	2019-01-03 19:41:20.684121+00	553	10.33 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
385	2019-01-03 19:41:20.691132+00	554	10.33 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
386	2019-01-03 19:41:20.697065+00	555	10.33 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
387	2019-01-03 19:41:20.705098+00	556	10.33 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
388	2019-01-03 19:41:20.711197+00	557	10.33 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
389	2019-01-03 19:41:20.716895+00	558	10.33 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
390	2019-01-03 19:41:20.722892+00	559	10.33 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
391	2019-01-03 19:41:20.728603+00	560	10.33 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
392	2019-01-03 19:41:20.734432+00	561	10.33 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
393	2019-01-03 19:41:20.74045+00	562	10.33 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
394	2019-01-03 19:41:20.746967+00	563	10.33 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
395	2019-01-03 19:41:20.753353+00	564	10.33 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
396	2019-01-03 19:41:20.759445+00	565	10.33 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
397	2019-01-03 19:41:20.766218+00	566	10.33 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
398	2019-01-03 19:41:20.772594+00	567	10.33 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
399	2019-01-03 19:41:20.778544+00	568	10.33 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
400	2019-01-03 19:41:20.784492+00	569	10.33 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
401	2019-01-03 19:41:20.792723+00	570	10.33 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
402	2019-01-03 19:41:20.799286+00	571	10.33 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
403	2019-01-03 19:41:20.805932+00	572	10.33 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
404	2019-01-03 19:41:20.8129+00	573	10.33 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
405	2019-01-03 19:41:20.819275+00	574	10.33 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
406	2019-01-03 19:41:20.825633+00	575	10.33 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
407	2019-01-03 19:41:20.832138+00	576	10.33 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
408	2019-01-03 19:41:20.83918+00	577	10.33 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
409	2019-01-03 19:41:20.846556+00	578	10.33 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
410	2019-01-03 19:41:20.853017+00	579	10.33 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
411	2019-01-03 19:41:20.859603+00	580	10.33 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
412	2019-01-03 19:41:20.866578+00	581	10.33 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
413	2019-01-03 19:41:20.872651+00	582	10.33 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
414	2019-01-03 19:41:20.878378+00	583	10.33 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
415	2019-01-03 19:41:20.884367+00	584	10.33 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
416	2019-01-03 19:41:20.891709+00	585	10.33 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
417	2019-01-03 19:41:20.89831+00	586	10.33 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
418	2019-01-03 19:41:20.904503+00	587	10.33 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
419	2019-01-03 19:41:20.910338+00	588	10.33 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
420	2019-01-03 19:41:20.916588+00	589	10.33 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
421	2019-01-03 19:41:20.92305+00	590	10.33 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
422	2019-01-03 19:41:20.929011+00	591	10.33 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
423	2019-01-03 19:41:20.934839+00	592	10.33 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
424	2019-01-07 20:16:11.6682+00	1	ESP Dennis	1	[{"added": {}}]	16	1
425	2019-01-07 20:16:17.745097+00	2	ESP Don	1	[{"added": {}}]	16	1
426	2019-01-07 20:16:30.906109+00	3	ESP Jake	1	[{"added": {}}]	16	1
427	2019-01-07 20:16:40.826129+00	4	ESP Roman	1	[{"added": {}}]	16	1
428	2019-01-07 20:37:58.33943+00	1	2014 - ESP Don - ESP-1	1	[{"added": {}}]	17	1
429	2019-01-07 20:38:47.233251+00	2	2014 - ESP Jake - ESP-2	1	[{"added": {}}]	17	1
430	2019-01-07 20:39:05.502426+00	3	2014 - ESP Dennis - ESP-3	1	[{"added": {}}]	17	1
431	2019-01-07 20:39:43.7741+00	4	2015 - ESP Don - ESP-1	1	[{"added": {}}]	17	1
432	2019-01-07 20:40:02.826978+00	5	2015 - ESP Dennis - ESP-2	1	[{"added": {}}]	17	1
433	2019-01-07 20:40:20.769727+00	6	2015 - ESP Jake - ESP-3	1	[{"added": {}}]	17	1
434	2019-01-18 19:15:45.975365+00	7	2016 - ESP Don - ESP-1	1	[{"added": {}}]	17	1
436	2019-01-18 19:17:21.440069+00	9	2016 - ESP Jake - Bowdoin wetlab	1	[{"added": {}}]	17	1
437	2019-01-18 19:17:48.918808+00	10	2017 - ESP Jake - ESP-1	1	[{"added": {}}]	17	1
438	2019-01-18 19:18:07.175987+00	11	2017 - ESP Dennis - ESP-2	1	[{"added": {}}]	17	1
439	2019-01-18 19:18:26.679394+00	12	2017 - ESP Roman - ESP-3	1	[{"added": {}}]	17	1
440	2019-01-18 19:18:44.344347+00	13	2017 - ESP Don - ESP-4	1	[{"added": {}}]	17	1
441	2019-01-18 19:19:38.776255+00	14	2018 - ESP Don - ESP-1	1	[{"added": {}}]	17	1
442	2019-01-18 19:19:55.315953+00	15	2018 - ESP Dennis - ESP-2	1	[{"added": {}}]	17	1
443	2019-01-18 19:20:11.123254+00	16	2018 - ESP Jake - Bowdoin wetlab	1	[{"added": {}}]	17	1
444	2019-01-18 19:39:36.855616+00	667	12.01 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
445	2019-01-18 19:39:36.864238+00	668	12.01 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
446	2019-01-18 19:39:36.871241+00	669	12.01 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
447	2019-01-18 19:39:36.878435+00	670	12.01 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
448	2019-01-18 19:39:36.885329+00	671	12.01 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
449	2019-01-18 19:39:36.892057+00	672	12.01 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
450	2019-01-18 19:39:36.900454+00	673	12.01 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
451	2019-01-18 19:39:36.907943+00	674	12.01 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
452	2019-01-18 19:39:36.915882+00	675	12.01 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
453	2019-01-18 19:39:36.923417+00	676	12.01 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
454	2019-01-18 19:39:36.931618+00	677	12.01 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
455	2019-01-18 19:39:36.940093+00	678	12.01 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
456	2019-01-18 19:39:36.948315+00	679	12.01 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
457	2019-01-18 19:39:36.95542+00	680	12.01 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
458	2019-01-18 19:39:36.962615+00	681	12.01 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
459	2019-01-18 19:39:36.970179+00	682	12.01 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
460	2019-01-18 19:39:36.977499+00	683	12.01 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
461	2019-01-18 19:39:36.984732+00	684	12.01 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
462	2019-01-18 19:39:36.992564+00	685	12.01 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
463	2019-01-18 19:39:37.000607+00	686	12.01 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
464	2019-01-18 19:39:37.007714+00	687	12.01 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
465	2019-01-18 19:39:37.016574+00	688	12.01 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
466	2019-01-18 19:39:37.02525+00	689	12.01 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
467	2019-01-18 19:39:37.033087+00	690	12.01 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
468	2019-01-18 19:39:37.040592+00	691	12.01 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
469	2019-01-18 19:39:37.049451+00	692	12.01 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
470	2019-01-18 19:39:37.057646+00	693	12.01 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
471	2019-01-18 19:39:37.066646+00	694	12.01 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
472	2019-01-18 19:39:37.076135+00	695	12.01 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
473	2019-01-18 19:39:37.085751+00	696	12.01 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
474	2019-01-18 19:39:37.09601+00	697	12.01 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
475	2019-01-18 19:39:37.105663+00	698	12.01 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
476	2019-01-18 19:39:37.114517+00	699	12.01 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
477	2019-01-18 19:39:37.123381+00	700	12.01 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
478	2019-01-18 19:39:37.132434+00	701	12.01 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
479	2019-01-18 19:39:37.142194+00	702	12.01 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
480	2019-01-18 19:39:37.151031+00	703	12.01 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
481	2019-01-18 19:39:37.159643+00	704	12.01 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
482	2019-01-18 19:39:37.16897+00	705	12.01 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
483	2019-01-18 19:39:37.176933+00	706	12.01 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
484	2019-01-18 19:39:37.185692+00	707	12.01 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
485	2019-01-18 19:39:37.19408+00	708	12.01 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
486	2019-01-18 19:39:37.202743+00	709	12.01 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
487	2019-01-18 19:39:37.210521+00	710	12.01 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
488	2019-01-18 19:39:37.22002+00	711	12.01 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
489	2019-01-18 19:39:37.229162+00	712	12.01 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
490	2019-01-18 19:39:37.237579+00	713	12.01 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
491	2019-01-18 19:39:37.246033+00	714	12.01 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
492	2019-01-18 19:39:37.254523+00	715	12.01 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
493	2019-01-18 19:39:37.263347+00	716	12.01 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
494	2019-01-18 19:39:37.271984+00	717	12.01 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
495	2019-01-18 19:39:37.280706+00	718	12.01 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
496	2019-01-18 19:39:37.290401+00	719	12.01 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
497	2019-01-18 19:39:37.299118+00	720	12.01 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
498	2019-01-18 19:39:37.306276+00	721	12.01 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
499	2019-01-18 19:39:37.313539+00	722	12.01 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
500	2019-01-18 19:39:37.320745+00	723	12.01 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
501	2019-01-18 19:39:37.327551+00	724	12.01 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
502	2019-01-18 19:39:37.335729+00	725	12.01 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
503	2019-01-18 19:39:37.342633+00	726	12.01 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
504	2019-01-18 19:39:37.348877+00	727	12.01 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
505	2019-01-18 19:39:37.354964+00	728	12.01 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
506	2019-01-18 19:39:37.362266+00	729	12.01 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
507	2019-01-18 19:39:37.368534+00	730	12.01 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
508	2019-01-18 19:39:37.37499+00	731	12.01 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
509	2019-01-18 19:39:37.382892+00	732	12.01 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
510	2019-01-18 19:39:37.390927+00	733	12.01 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
511	2019-01-18 19:39:37.398593+00	734	12.01 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
512	2019-01-18 19:39:37.405568+00	735	12.01 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
513	2019-01-18 19:39:37.424657+00	736	12.01 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
514	2019-01-18 19:39:37.44286+00	737	12.01 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
515	2019-01-18 19:39:37.46766+00	738	12.01 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
516	2019-01-18 19:39:37.502031+00	739	12.01 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
517	2019-01-18 19:39:37.509137+00	740	12.01 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
518	2019-01-18 19:42:59.770766+00	815	12.03 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
519	2019-01-18 19:42:59.777516+00	816	12.03 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
520	2019-01-18 19:42:59.783598+00	817	12.03 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
521	2019-01-18 19:42:59.789504+00	818	12.03 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
522	2019-01-18 19:42:59.795577+00	819	12.03 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
523	2019-01-18 19:42:59.801945+00	820	12.03 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
524	2019-01-18 19:42:59.808575+00	821	12.03 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
525	2019-01-18 19:42:59.815061+00	822	12.03 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
526	2019-01-18 19:42:59.820926+00	823	12.03 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
527	2019-01-18 19:42:59.827397+00	824	12.03 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
528	2019-01-18 19:42:59.833254+00	825	12.03 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
529	2019-01-18 19:42:59.839582+00	826	12.03 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
530	2019-01-18 19:42:59.8457+00	827	12.03 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
531	2019-01-18 19:42:59.851858+00	828	12.03 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
532	2019-01-18 19:42:59.857702+00	829	12.03 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
533	2019-01-18 19:42:59.863537+00	830	12.03 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
534	2019-01-18 19:42:59.869437+00	831	12.03 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
535	2019-01-18 19:42:59.875104+00	832	12.03 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
536	2019-01-18 19:42:59.881278+00	833	12.03 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
537	2019-01-18 19:42:59.887111+00	834	12.03 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
538	2019-01-18 19:42:59.893331+00	835	12.03 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
539	2019-01-18 19:42:59.90141+00	836	12.03 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
540	2019-01-18 19:42:59.908521+00	837	12.03 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
541	2019-01-18 19:42:59.914904+00	838	12.03 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
542	2019-01-18 19:42:59.921216+00	839	12.03 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
543	2019-01-18 19:42:59.927631+00	840	12.03 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
544	2019-01-18 19:42:59.934344+00	841	12.03 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
545	2019-01-18 19:42:59.940887+00	842	12.03 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
546	2019-01-18 19:42:59.947437+00	843	12.03 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
547	2019-01-18 19:42:59.953532+00	844	12.03 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
548	2019-01-18 19:42:59.959872+00	845	12.03 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
549	2019-01-18 19:42:59.966333+00	846	12.03 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
550	2019-01-18 19:42:59.972873+00	847	12.03 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
551	2019-01-18 19:42:59.978827+00	848	12.03 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
552	2019-01-18 19:42:59.984565+00	849	12.03 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
553	2019-01-18 19:42:59.991483+00	850	12.03 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
554	2019-01-18 19:42:59.9978+00	851	12.03 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
555	2019-01-18 19:43:00.005508+00	852	12.03 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
556	2019-01-18 19:43:00.01181+00	853	12.03 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
557	2019-01-18 19:43:00.017626+00	854	12.03 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
558	2019-01-18 19:43:00.023545+00	855	12.03 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
559	2019-01-18 19:43:00.029753+00	856	12.03 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
560	2019-01-18 19:43:00.036653+00	857	12.03 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
561	2019-01-18 19:43:00.04263+00	858	12.03 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
562	2019-01-18 19:43:00.048284+00	859	12.03 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
563	2019-01-18 19:43:00.054803+00	860	12.03 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
564	2019-01-18 19:43:00.060692+00	861	12.03 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
565	2019-01-18 19:43:00.066541+00	862	12.03 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
566	2019-01-18 19:43:00.072292+00	863	12.03 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
567	2019-01-18 19:43:00.078075+00	864	12.03 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
568	2019-01-18 19:43:00.083994+00	865	12.03 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
569	2019-01-18 19:43:00.089881+00	866	12.03 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
570	2019-01-18 19:43:00.096485+00	867	12.03 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
571	2019-01-18 19:43:00.103498+00	868	12.03 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
572	2019-01-18 19:43:00.109113+00	869	12.03 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
573	2019-01-18 19:43:00.115857+00	870	12.03 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
574	2019-01-18 19:43:00.122218+00	871	12.03 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
575	2019-01-18 19:43:00.127946+00	872	12.03 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
576	2019-01-18 19:43:00.13364+00	873	12.03 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
577	2019-01-18 19:43:00.139494+00	874	12.03 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
578	2019-01-18 19:43:00.147083+00	875	12.03 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
579	2019-01-18 19:43:00.154405+00	876	12.03 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
580	2019-01-18 19:43:00.161513+00	877	12.03 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
581	2019-01-18 19:43:00.168245+00	878	12.03 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
582	2019-01-18 19:43:00.175028+00	879	12.03 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
583	2019-01-18 19:43:00.18143+00	880	12.03 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
584	2019-01-18 19:43:00.187747+00	881	12.03 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
585	2019-01-18 19:43:00.194072+00	882	12.03 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
586	2019-01-18 19:43:00.200766+00	883	12.03 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
587	2019-01-18 19:43:00.207893+00	884	12.03 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
588	2019-01-18 19:43:00.214287+00	885	12.03 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
589	2019-01-18 19:43:00.220845+00	886	12.03 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
590	2019-01-18 19:43:00.226936+00	887	12.03 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
591	2019-01-18 19:43:00.233063+00	888	12.03 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
592	2019-01-18 19:45:46.869219+00	963	12.13 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
593	2019-01-18 19:45:46.875692+00	964	12.13 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
594	2019-01-18 19:45:46.881489+00	965	12.13 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
595	2019-01-18 19:45:46.88764+00	966	12.13 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
596	2019-01-18 19:45:46.893551+00	967	12.13 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
597	2019-01-18 19:45:46.8999+00	968	12.13 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
598	2019-01-18 19:45:46.906148+00	969	12.13 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
599	2019-01-18 19:45:46.912431+00	970	12.13 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
600	2019-01-18 19:45:46.91849+00	971	12.13 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
601	2019-01-18 19:45:46.924473+00	972	12.13 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
602	2019-01-18 19:45:46.930489+00	973	12.13 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
603	2019-01-18 19:45:46.937061+00	974	12.13 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
604	2019-01-18 19:45:46.943466+00	975	12.13 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
605	2019-01-18 19:45:46.951123+00	976	12.13 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
606	2019-01-18 19:45:46.958721+00	977	12.13 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
607	2019-01-18 19:45:46.965419+00	978	12.13 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
608	2019-01-18 19:45:46.971851+00	979	12.13 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
609	2019-01-18 19:45:46.977739+00	980	12.13 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
610	2019-01-18 19:45:46.983837+00	981	12.13 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
611	2019-01-18 19:45:46.989771+00	982	12.13 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
612	2019-01-18 19:45:46.995824+00	983	12.13 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
613	2019-01-18 19:45:47.00276+00	984	12.13 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
614	2019-01-18 19:45:47.009041+00	985	12.13 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
615	2019-01-18 19:45:47.015703+00	986	12.13 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
616	2019-01-18 19:45:47.021592+00	987	12.13 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
617	2019-01-18 19:45:47.028321+00	988	12.13 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
618	2019-01-18 19:45:47.035886+00	989	12.13 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
619	2019-01-18 19:45:47.041996+00	990	12.13 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
620	2019-01-18 19:45:47.047756+00	991	12.13 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
621	2019-01-18 19:45:47.053502+00	992	12.13 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
622	2019-01-18 19:45:47.059021+00	993	12.13 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
623	2019-01-18 19:45:47.064597+00	994	12.13 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
624	2019-01-18 19:45:47.070702+00	995	12.13 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
625	2019-01-18 19:45:47.07646+00	996	12.13 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
626	2019-01-18 19:45:47.082618+00	997	12.13 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
627	2019-01-18 19:45:47.088928+00	998	12.13 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
628	2019-01-18 19:45:47.095193+00	999	12.13 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
629	2019-01-18 19:45:47.101939+00	1000	12.13 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
630	2019-01-18 19:45:47.107737+00	1001	12.13 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
631	2019-01-18 19:45:47.114703+00	1002	12.13 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
632	2019-01-18 19:45:47.120974+00	1003	12.13 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
633	2019-01-18 19:45:47.127108+00	1004	12.13 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
634	2019-01-18 19:45:47.13403+00	1005	12.13 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
635	2019-01-18 19:45:47.140621+00	1006	12.13 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
636	2019-01-18 19:45:47.146793+00	1007	12.13 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
637	2019-01-18 19:45:47.153444+00	1008	12.13 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
638	2019-01-18 19:45:47.15956+00	1009	12.13 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
639	2019-01-18 19:45:47.165983+00	1010	12.13 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
640	2019-01-18 19:45:47.172254+00	1011	12.13 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
641	2019-01-18 19:45:47.178184+00	1012	12.13 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
642	2019-01-18 19:45:47.18419+00	1013	12.13 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
643	2019-01-18 19:45:47.203531+00	1014	12.13 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
644	2019-01-18 19:45:47.223611+00	1015	12.13 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
645	2019-01-18 19:45:47.244035+00	1016	12.13 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
646	2019-01-18 19:45:47.271794+00	1017	12.13 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
647	2019-01-18 19:45:47.277707+00	1018	12.13 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
648	2019-01-18 19:45:47.283959+00	1019	12.13 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
649	2019-01-18 19:45:47.289812+00	1020	12.13 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
650	2019-01-18 19:45:47.296991+00	1021	12.13 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
651	2019-01-18 19:45:47.303597+00	1022	12.13 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
652	2019-01-18 19:45:47.310301+00	1023	12.13 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
653	2019-01-18 19:45:47.317822+00	1024	12.13 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
654	2019-01-18 19:45:47.325087+00	1025	12.13 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
655	2019-01-18 19:45:47.332441+00	1026	12.13 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
656	2019-01-18 19:45:47.339041+00	1027	12.13 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
657	2019-01-18 19:45:47.345302+00	1028	12.13 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
658	2019-01-18 19:45:47.352496+00	1029	12.13 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
659	2019-01-18 19:45:47.359853+00	1030	12.13 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
660	2019-01-18 19:45:47.367642+00	1031	12.13 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
661	2019-01-18 19:45:47.375579+00	1032	12.13 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
662	2019-01-18 19:45:47.382892+00	1033	12.13 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
663	2019-01-18 19:45:47.389784+00	1034	12.13 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
664	2019-01-18 19:45:47.396891+00	1035	12.13 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
665	2019-01-18 19:45:47.404607+00	1036	12.13 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
666	2019-01-18 19:48:32.88773+00	1111	12.28 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
667	2019-01-18 19:48:32.894762+00	1112	12.28 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
668	2019-01-18 19:48:32.901904+00	1113	12.28 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
669	2019-01-18 19:48:32.908553+00	1114	12.28 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
670	2019-01-18 19:48:32.914995+00	1115	12.28 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
671	2019-01-18 19:48:32.921452+00	1116	12.28 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
672	2019-01-18 19:48:32.928466+00	1117	12.28 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
673	2019-01-18 19:48:32.935337+00	1118	12.28 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
674	2019-01-18 19:48:32.941875+00	1119	12.28 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
675	2019-01-18 19:48:32.948097+00	1120	12.28 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
676	2019-01-18 19:48:32.954152+00	1121	12.28 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
677	2019-01-18 19:48:32.960451+00	1122	12.28 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
678	2019-01-18 19:48:32.966632+00	1123	12.28 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
679	2019-01-18 19:48:32.97359+00	1124	12.28 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
680	2019-01-18 19:48:32.979844+00	1125	12.28 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
681	2019-01-18 19:48:32.98562+00	1126	12.28 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
682	2019-01-18 19:48:32.991826+00	1127	12.28 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
683	2019-01-18 19:48:32.997848+00	1128	12.28 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
684	2019-01-18 19:48:33.004316+00	1129	12.28 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
685	2019-01-18 19:48:33.010393+00	1130	12.28 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
686	2019-01-18 19:48:33.016666+00	1131	12.28 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
687	2019-01-18 19:48:33.023248+00	1132	12.28 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
688	2019-01-18 19:48:33.029085+00	1133	12.28 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
689	2019-01-18 19:48:33.035055+00	1134	12.28 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
690	2019-01-18 19:48:33.052192+00	1135	12.28 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
691	2019-01-18 19:48:33.058737+00	1136	12.28 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
692	2019-01-18 19:48:33.076766+00	1137	12.28 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
693	2019-01-18 19:48:33.095744+00	1138	12.28 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
694	2019-01-18 19:48:33.129045+00	1139	12.28 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
695	2019-01-18 19:48:33.135591+00	1140	12.28 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
696	2019-01-18 19:48:33.141919+00	1141	12.28 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
697	2019-01-18 19:48:33.148518+00	1142	12.28 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
698	2019-01-18 19:48:33.155627+00	1143	12.28 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
699	2019-01-18 19:48:33.163242+00	1144	12.28 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
700	2019-01-18 19:48:33.170797+00	1145	12.28 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
701	2019-01-18 19:48:33.178646+00	1146	12.28 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
702	2019-01-18 19:48:33.185919+00	1147	12.28 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
703	2019-01-18 19:48:33.192725+00	1148	12.28 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
704	2019-01-18 19:48:33.200217+00	1149	12.28 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
705	2019-01-18 19:48:33.207248+00	1150	12.28 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
706	2019-01-18 19:48:33.214164+00	1151	12.28 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
707	2019-01-18 19:48:33.220768+00	1152	12.28 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
708	2019-01-18 19:48:33.22777+00	1153	12.28 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
709	2019-01-18 19:48:33.234002+00	1154	12.28 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
710	2019-01-18 19:48:33.240258+00	1155	12.28 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
711	2019-01-18 19:48:33.24651+00	1156	12.28 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
712	2019-01-18 19:48:33.252686+00	1157	12.28 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
713	2019-01-18 19:48:33.259036+00	1158	12.28 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
714	2019-01-18 19:48:33.265815+00	1159	12.28 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
715	2019-01-18 19:48:33.272197+00	1160	12.28 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
716	2019-01-18 19:48:33.278919+00	1161	12.28 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
717	2019-01-18 19:48:33.285169+00	1162	12.28 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
718	2019-01-18 19:48:33.292013+00	1163	12.28 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
719	2019-01-18 19:48:33.298979+00	1164	12.28 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
720	2019-01-18 19:48:33.307219+00	1165	12.28 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
721	2019-01-18 19:48:33.314213+00	1166	12.28 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
722	2019-01-18 19:48:33.322301+00	1167	12.28 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
723	2019-01-18 19:48:33.329432+00	1168	12.28 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
724	2019-01-18 19:48:33.335835+00	1169	12.28 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
725	2019-01-18 19:48:33.34236+00	1170	12.28 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
726	2019-01-18 19:48:33.348506+00	1171	12.28 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
727	2019-01-18 19:48:33.35461+00	1172	12.28 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
728	2019-01-18 19:48:33.361267+00	1173	12.28 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
729	2019-01-18 19:48:33.3681+00	1174	12.28 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
730	2019-01-18 19:48:33.374941+00	1175	12.28 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
731	2019-01-18 19:48:33.380978+00	1176	12.28 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
732	2019-01-18 19:48:33.38721+00	1177	12.28 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
733	2019-01-18 19:48:33.393372+00	1178	12.28 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
734	2019-01-18 19:48:33.399844+00	1179	12.28 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
735	2019-01-18 19:48:33.406715+00	1180	12.28 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
736	2019-01-18 19:48:33.413704+00	1181	12.28 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
737	2019-01-18 19:48:33.420522+00	1182	12.28 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
738	2019-01-18 19:48:33.427352+00	1183	12.28 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
739	2019-01-18 19:48:33.433959+00	1184	12.28 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
740	2019-01-18 19:51:38.233937+00	1259	12.34 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
741	2019-01-18 19:51:38.240078+00	1260	12.34 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
742	2019-01-18 19:51:38.246769+00	1261	12.34 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
743	2019-01-18 19:51:38.253793+00	1262	12.34 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
744	2019-01-18 19:51:38.261023+00	1263	12.34 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
745	2019-01-18 19:51:38.267587+00	1264	12.34 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
746	2019-01-18 19:51:38.274005+00	1265	12.34 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
747	2019-01-18 19:51:38.280392+00	1266	12.34 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
748	2019-01-18 19:51:38.287355+00	1267	12.34 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
749	2019-01-18 19:51:38.293697+00	1268	12.34 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
750	2019-01-18 19:51:38.300674+00	1269	12.34 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
751	2019-01-18 19:51:38.307106+00	1270	12.34 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
752	2019-01-18 19:51:38.313342+00	1271	12.34 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
753	2019-01-18 19:51:38.319703+00	1272	12.34 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
754	2019-01-18 19:51:38.326081+00	1273	12.34 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
755	2019-01-18 19:51:38.332473+00	1274	12.34 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
756	2019-01-18 19:51:38.338748+00	1275	12.34 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
757	2019-01-18 19:51:38.345444+00	1276	12.34 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
758	2019-01-18 19:51:38.352292+00	1277	12.34 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
759	2019-01-18 19:51:38.359561+00	1278	12.34 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
760	2019-01-18 19:51:38.367357+00	1279	12.34 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
761	2019-01-18 19:51:38.375238+00	1280	12.34 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
762	2019-01-18 19:51:38.381442+00	1281	12.34 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
763	2019-01-18 19:51:38.387928+00	1282	12.34 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
764	2019-01-18 19:51:38.395168+00	1283	12.34 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
765	2019-01-18 19:51:38.402757+00	1284	12.34 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
766	2019-01-18 19:51:38.413638+00	1285	12.34 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
767	2019-01-18 19:51:38.43343+00	1286	12.34 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
768	2019-01-18 19:51:38.453989+00	1287	12.34 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
769	2019-01-18 19:51:38.474599+00	1288	12.34 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
770	2019-01-18 19:51:38.509876+00	1289	12.34 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
771	2019-01-18 19:51:38.518267+00	1290	12.34 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
772	2019-01-18 19:51:38.526363+00	1291	12.34 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
773	2019-01-18 19:51:38.532986+00	1292	12.34 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
774	2019-01-18 19:51:38.539024+00	1293	12.34 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
775	2019-01-18 19:51:38.545744+00	1294	12.34 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
776	2019-01-18 19:51:38.553532+00	1295	12.34 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
777	2019-01-18 19:51:38.561082+00	1296	12.34 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
778	2019-01-18 19:51:38.56799+00	1297	12.34 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
779	2019-01-18 19:51:38.574252+00	1298	12.34 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
780	2019-01-18 19:51:38.580155+00	1299	12.34 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
781	2019-01-18 19:51:38.587297+00	1300	12.34 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
782	2019-01-18 19:51:38.594441+00	1301	12.34 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
783	2019-01-18 19:51:38.601589+00	1302	12.34 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
784	2019-01-18 19:51:38.607863+00	1303	12.34 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
785	2019-01-18 19:51:38.613968+00	1304	12.34 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
786	2019-01-18 19:51:38.62066+00	1305	12.34 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
787	2019-01-18 19:51:38.62673+00	1306	12.34 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
788	2019-01-18 19:51:38.63263+00	1307	12.34 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
789	2019-01-18 19:51:38.638382+00	1308	12.34 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
790	2019-01-18 19:51:38.644328+00	1309	12.34 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
791	2019-01-18 19:51:38.650052+00	1310	12.34 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
792	2019-01-18 19:51:38.656715+00	1311	12.34 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
793	2019-01-18 19:51:38.663274+00	1312	12.34 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
794	2019-01-18 19:51:38.669666+00	1313	12.34 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
795	2019-01-18 19:51:38.675924+00	1314	12.34 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
796	2019-01-18 19:51:38.682125+00	1315	12.34 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
797	2019-01-18 19:51:38.688426+00	1316	12.34 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
798	2019-01-18 19:51:38.694437+00	1317	12.34 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
799	2019-01-18 19:51:38.70037+00	1318	12.34 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
800	2019-01-18 19:51:38.706546+00	1319	12.34 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
801	2019-01-18 19:51:38.712519+00	1320	12.34 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
802	2019-01-18 19:51:38.718653+00	1321	12.34 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
803	2019-01-18 19:51:38.724468+00	1322	12.34 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
804	2019-01-18 19:51:38.730064+00	1323	12.34 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
805	2019-01-18 19:51:38.735723+00	1324	12.34 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
806	2019-01-18 19:51:38.741821+00	1325	12.34 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
807	2019-01-18 19:51:38.747641+00	1326	12.34 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
808	2019-01-18 19:51:38.754287+00	1327	12.34 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
809	2019-01-18 19:51:38.763357+00	1328	12.34 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
810	2019-01-18 19:51:38.772491+00	1329	12.34 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
811	2019-01-18 19:51:38.778985+00	1330	12.34 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
812	2019-01-18 19:51:38.785358+00	1331	12.34 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
813	2019-01-18 19:51:38.791616+00	1332	12.34 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
814	2019-01-18 19:52:02.28298+00	1407	15.25 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
815	2019-01-18 19:52:02.28939+00	1408	15.25 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
816	2019-01-18 19:52:02.296201+00	1409	15.25 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
817	2019-01-18 19:52:02.302967+00	1410	15.25 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
818	2019-01-18 19:52:02.309394+00	1411	15.25 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
819	2019-01-18 19:52:02.315787+00	1412	15.25 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
820	2019-01-18 19:52:02.322134+00	1413	15.25 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
821	2019-01-18 19:52:02.328211+00	1414	15.25 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
822	2019-01-18 19:52:02.342007+00	1415	15.25 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
823	2019-01-18 19:52:02.363838+00	1416	15.25 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
824	2019-01-18 19:52:02.370647+00	1417	15.25 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
825	2019-01-18 19:52:02.389068+00	1418	15.25 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
826	2019-01-18 19:52:02.418327+00	1419	15.25 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
827	2019-01-18 19:52:02.429514+00	1420	15.25 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
828	2019-01-18 19:52:02.436151+00	1421	15.25 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
829	2019-01-18 19:52:02.442312+00	1422	15.25 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
830	2019-01-18 19:52:02.448504+00	1423	15.25 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
831	2019-01-18 19:52:02.454839+00	1424	15.25 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
832	2019-01-18 19:52:02.461524+00	1425	15.25 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
833	2019-01-18 19:52:02.468079+00	1426	15.25 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
834	2019-01-18 19:52:02.474278+00	1427	15.25 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
835	2019-01-18 19:52:02.48005+00	1428	15.25 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
836	2019-01-18 19:52:02.485694+00	1429	15.25 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
837	2019-01-18 19:52:02.491722+00	1430	15.25 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
838	2019-01-18 19:52:02.498585+00	1431	15.25 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
839	2019-01-18 19:52:02.504982+00	1432	15.25 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
840	2019-01-18 19:52:02.510813+00	1433	15.25 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
841	2019-01-18 19:52:02.517229+00	1434	15.25 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
842	2019-01-18 19:52:02.523084+00	1435	15.25 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
843	2019-01-18 19:52:02.52937+00	1436	15.25 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
844	2019-01-18 19:52:02.535771+00	1437	15.25 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
845	2019-01-18 19:52:02.541473+00	1438	15.25 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
846	2019-01-18 19:52:02.547454+00	1439	15.25 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
847	2019-01-18 19:52:02.554305+00	1440	15.25 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
848	2019-01-18 19:52:02.560434+00	1441	15.25 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
849	2019-01-18 19:52:02.566758+00	1442	15.25 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
850	2019-01-18 19:52:02.573905+00	1443	15.25 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
851	2019-01-18 19:52:02.580563+00	1444	15.25 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
852	2019-01-18 19:52:02.586785+00	1445	15.25 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
853	2019-01-18 19:52:02.59276+00	1446	15.25 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
854	2019-01-18 19:52:02.600098+00	1447	15.25 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
855	2019-01-18 19:52:02.60648+00	1448	15.25 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
856	2019-01-18 19:52:02.612882+00	1449	15.25 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
857	2019-01-18 19:52:02.619778+00	1450	15.25 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
858	2019-01-18 19:52:02.625949+00	1451	15.25 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
859	2019-01-18 19:52:02.631877+00	1452	15.25 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
860	2019-01-18 19:52:02.637726+00	1453	15.25 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
861	2019-01-18 19:52:02.644424+00	1454	15.25 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
862	2019-01-18 19:52:02.650354+00	1455	15.25 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
863	2019-01-18 19:52:02.656395+00	1456	15.25 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
864	2019-01-18 19:52:02.662192+00	1457	15.25 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
865	2019-01-18 19:52:02.667785+00	1458	15.25 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
866	2019-01-18 19:52:02.673421+00	1459	15.25 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
867	2019-01-18 19:52:02.680078+00	1460	15.25 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
868	2019-01-18 19:52:02.686504+00	1461	15.25 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
869	2019-01-18 19:52:02.692592+00	1462	15.25 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
870	2019-01-18 19:52:02.698374+00	1463	15.25 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
871	2019-01-18 19:52:02.704922+00	1464	15.25 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
872	2019-01-18 19:52:02.712593+00	1465	15.25 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
873	2019-01-18 19:52:02.71964+00	1466	15.25 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
874	2019-01-18 19:52:02.726195+00	1467	15.25 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
875	2019-01-18 19:52:02.732709+00	1468	15.25 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
876	2019-01-18 19:52:02.73895+00	1469	15.25 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
877	2019-01-18 19:52:02.745415+00	1470	15.25 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
878	2019-01-18 19:52:02.752708+00	1471	15.25 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
879	2019-01-18 19:52:02.7593+00	1472	15.25 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
880	2019-01-18 19:52:02.766694+00	1473	15.25 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
881	2019-01-18 19:52:02.773037+00	1474	15.25 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
882	2019-01-18 19:52:02.779169+00	1475	15.25 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
883	2019-01-18 19:52:02.785281+00	1476	15.25 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
884	2019-01-18 19:52:02.791559+00	1477	15.25 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
885	2019-01-18 19:52:02.797793+00	1478	15.25 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
886	2019-01-18 19:52:02.804603+00	1479	15.25 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
887	2019-01-18 19:52:02.811258+00	1480	15.25 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
888	2019-01-18 19:53:37.470169+00	1555	16.41 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
889	2019-01-18 19:53:37.477328+00	1556	16.41 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
890	2019-01-18 19:53:37.484001+00	1557	16.41 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
891	2019-01-18 19:53:37.489764+00	1558	16.41 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
892	2019-01-18 19:53:37.496073+00	1559	16.41 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
893	2019-01-18 19:53:37.503267+00	1560	16.41 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
894	2019-01-18 19:53:37.510182+00	1561	16.41 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
895	2019-01-18 19:53:37.522365+00	1562	16.41 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
896	2019-01-18 19:53:37.529744+00	1563	16.41 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
897	2019-01-18 19:53:37.53661+00	1564	16.41 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
898	2019-01-18 19:53:37.543222+00	1565	16.41 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
899	2019-01-18 19:53:37.549909+00	1566	16.41 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
900	2019-01-18 19:53:37.556758+00	1567	16.41 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
901	2019-01-18 19:53:37.563273+00	1568	16.41 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
902	2019-01-18 19:53:37.569798+00	1569	16.41 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
903	2019-01-18 19:53:37.576201+00	1570	16.41 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
904	2019-01-18 19:53:37.582308+00	1571	16.41 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
905	2019-01-18 19:53:37.588289+00	1572	16.41 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
906	2019-01-18 19:53:37.595526+00	1573	16.41 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
907	2019-01-18 19:53:37.604954+00	1574	16.41 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
908	2019-01-18 19:53:37.612627+00	1575	16.41 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
909	2019-01-18 19:53:37.621554+00	1576	16.41 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
910	2019-01-18 19:53:37.628424+00	1577	16.41 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
911	2019-01-18 19:53:37.635694+00	1578	16.41 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
912	2019-01-18 19:53:37.642824+00	1579	16.41 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
913	2019-01-18 19:53:37.649766+00	1580	16.41 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
914	2019-01-18 19:53:37.657555+00	1581	16.41 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
915	2019-01-18 19:53:37.664924+00	1582	16.41 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
916	2019-01-18 19:53:37.671078+00	1583	16.41 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
917	2019-01-18 19:53:37.677261+00	1584	16.41 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
918	2019-01-18 19:53:37.683584+00	1585	16.41 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
919	2019-01-18 19:53:37.68991+00	1586	16.41 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
920	2019-01-18 19:53:37.695812+00	1587	16.41 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
921	2019-01-18 19:53:37.701452+00	1588	16.41 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
922	2019-01-18 19:53:37.707246+00	1589	16.41 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
923	2019-01-18 19:53:37.714897+00	1590	16.41 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
924	2019-01-18 19:53:37.720853+00	1591	16.41 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
925	2019-01-18 19:53:37.726867+00	1592	16.41 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
926	2019-01-18 19:53:37.732824+00	1593	16.41 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
927	2019-01-18 19:53:37.738801+00	1594	16.41 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
928	2019-01-18 19:53:37.744512+00	1595	16.41 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
929	2019-01-18 19:53:37.750904+00	1596	16.41 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
930	2019-01-18 19:53:37.757339+00	1597	16.41 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
931	2019-01-18 19:53:37.763388+00	1598	16.41 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
932	2019-01-18 19:53:37.769353+00	1599	16.41 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
933	2019-01-18 19:53:37.776549+00	1600	16.41 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
934	2019-01-18 19:53:37.782565+00	1601	16.41 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
935	2019-01-18 19:53:37.788473+00	1602	16.41 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
936	2019-01-18 19:53:37.794583+00	1603	16.41 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
937	2019-01-18 19:53:37.805494+00	1604	16.41 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
938	2019-01-18 19:53:37.817699+00	1605	16.41 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
939	2019-01-18 19:53:37.826612+00	1606	16.41 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
940	2019-01-18 19:53:37.83268+00	1607	16.41 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
941	2019-01-18 19:53:37.83975+00	1608	16.41 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
942	2019-01-18 19:53:37.846229+00	1609	16.41 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
943	2019-01-18 19:53:37.857306+00	1610	16.41 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
944	2019-01-18 19:53:37.869081+00	1611	16.41 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
945	2019-01-18 19:53:37.875854+00	1612	16.41 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
946	2019-01-18 19:53:37.881732+00	1613	16.41 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
947	2019-01-18 19:53:37.887893+00	1614	16.41 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
948	2019-01-18 19:53:37.893735+00	1615	16.41 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
949	2019-01-18 19:53:37.901726+00	1616	16.41 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
950	2019-01-18 19:53:37.909652+00	1617	16.41 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
951	2019-01-18 19:53:37.917252+00	1618	16.41 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
952	2019-01-18 19:53:37.924316+00	1619	16.41 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
953	2019-01-18 19:53:37.930218+00	1620	16.41 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
954	2019-01-18 19:53:37.936544+00	1621	16.41 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
955	2019-01-18 19:53:37.942847+00	1622	16.41 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
956	2019-01-18 19:53:37.949226+00	1623	16.41 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
957	2019-01-18 19:53:37.958317+00	1624	16.41 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
958	2019-01-18 19:53:37.9646+00	1625	16.41 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
959	2019-01-18 19:53:37.970656+00	1626	16.41 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
960	2019-01-18 19:53:37.977422+00	1627	16.41 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
961	2019-01-18 19:53:37.984697+00	1628	16.41 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
962	2019-01-18 19:56:06.865516+00	1703	19.15 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
963	2019-01-18 19:56:06.872114+00	1704	19.15 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
964	2019-01-18 19:56:06.87834+00	1705	19.15 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
965	2019-01-18 19:56:06.884797+00	1706	19.15 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
966	2019-01-18 19:56:06.890758+00	1707	19.15 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
967	2019-01-18 19:56:06.896864+00	1708	19.15 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
968	2019-01-18 19:56:06.903093+00	1709	19.15 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
969	2019-01-18 19:56:06.910159+00	1710	19.15 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
970	2019-01-18 19:56:06.916747+00	1711	19.15 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
971	2019-01-18 19:56:06.922914+00	1712	19.15 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
972	2019-01-18 19:56:06.928818+00	1713	19.15 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
973	2019-01-18 19:56:06.935178+00	1714	19.15 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
974	2019-01-18 19:56:06.941508+00	1715	19.15 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
975	2019-01-18 19:56:06.947915+00	1716	19.15 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
976	2019-01-18 19:56:06.954253+00	1717	19.15 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
977	2019-01-18 19:56:06.960072+00	1718	19.15 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
978	2019-01-18 19:56:06.967213+00	1719	19.15 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
979	2019-01-18 19:56:06.975529+00	1720	19.15 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
980	2019-01-18 19:56:06.982433+00	1721	19.15 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
981	2019-01-18 19:56:06.989082+00	1722	19.15 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
982	2019-01-18 19:56:06.995054+00	1723	19.15 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
983	2019-01-18 19:56:07.001571+00	1724	19.15 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
984	2019-01-18 19:56:07.007945+00	1725	19.15 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
985	2019-01-18 19:56:07.01387+00	1726	19.15 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
986	2019-01-18 19:56:07.020468+00	1727	19.15 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
987	2019-01-18 19:56:07.026592+00	1728	19.15 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
988	2019-01-18 19:56:07.032844+00	1729	19.15 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
989	2019-01-18 19:56:07.038706+00	1730	19.15 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
990	2019-01-18 19:56:07.044621+00	1731	19.15 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
991	2019-01-18 19:56:07.051162+00	1732	19.15 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
992	2019-01-18 19:56:07.057716+00	1733	19.15 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
993	2019-01-18 19:56:07.063971+00	1734	19.15 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
994	2019-01-18 19:56:07.070023+00	1735	19.15 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
995	2019-01-18 19:56:07.076402+00	1736	19.15 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
996	2019-01-18 19:56:07.083138+00	1737	19.15 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
997	2019-01-18 19:56:07.08925+00	1738	19.15 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
998	2019-01-18 19:56:07.095654+00	1739	19.15 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
999	2019-01-18 19:56:07.10226+00	1740	19.15 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
1000	2019-01-18 19:56:07.108011+00	1741	19.15 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
1001	2019-01-18 19:56:07.113928+00	1742	19.15 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
1002	2019-01-18 19:56:07.119324+00	1743	19.15 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
1003	2019-01-18 19:56:07.125895+00	1744	19.15 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
1004	2019-01-18 19:56:07.132163+00	1745	19.15 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
1005	2019-01-18 19:56:07.137936+00	1746	19.15 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
1006	2019-01-18 19:56:07.147274+00	1747	19.15 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
1007	2019-01-18 19:56:07.157271+00	1748	19.15 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
1008	2019-01-18 19:56:07.164078+00	1749	19.15 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
1009	2019-01-18 19:56:07.171084+00	1750	19.15 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
1010	2019-01-18 19:56:07.177356+00	1751	19.15 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
1011	2019-01-18 19:56:07.184735+00	1752	19.15 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
1012	2019-01-18 19:56:07.191142+00	1753	19.15 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
1013	2019-01-18 19:56:07.199709+00	1754	19.15 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
1014	2019-01-18 19:56:07.206622+00	1755	19.15 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
1015	2019-01-18 19:56:07.213725+00	1756	19.15 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
1016	2019-01-18 19:56:07.221882+00	1757	19.15 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
1017	2019-01-18 19:56:07.228252+00	1758	19.15 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
1018	2019-01-18 19:56:07.23482+00	1759	19.15 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
1019	2019-01-18 19:56:07.240984+00	1760	19.15 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
1020	2019-01-18 19:56:07.248797+00	1761	19.15 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
1021	2019-01-18 19:56:07.25627+00	1762	19.15 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
1022	2019-01-18 19:56:07.262988+00	1763	19.15 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
1023	2019-01-18 19:56:07.269729+00	1764	19.15 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
1024	2019-01-18 19:56:07.276641+00	1765	19.15 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
1025	2019-01-18 19:56:07.282931+00	1766	19.15 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
1026	2019-01-18 19:56:07.288799+00	1767	19.15 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
1027	2019-01-18 19:56:07.295424+00	1768	19.15 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
1028	2019-01-18 19:56:07.303987+00	1769	19.15 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
1029	2019-01-18 19:56:07.310638+00	1770	19.15 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
1030	2019-01-18 19:56:07.317515+00	1771	19.15 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
1031	2019-01-18 19:56:07.323891+00	1772	19.15 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
1032	2019-01-18 19:56:07.32992+00	1773	19.15 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
1033	2019-01-18 19:56:07.336381+00	1774	19.15 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
1034	2019-01-18 19:56:07.343651+00	1775	19.15 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
1035	2019-01-18 19:56:07.350684+00	1776	19.15 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
1036	2019-01-18 19:58:02.327815+00	1851	21.09 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
1037	2019-01-18 19:58:02.335313+00	1852	21.09 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
1038	2019-01-18 19:58:02.342291+00	1853	21.09 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
1039	2019-01-18 19:58:02.349513+00	1854	21.09 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
1040	2019-01-18 19:58:02.356914+00	1855	21.09 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
1041	2019-01-18 19:58:02.363025+00	1856	21.09 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
1042	2019-01-18 19:58:02.371169+00	1857	21.09 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
1043	2019-01-18 19:58:02.379173+00	1858	21.09 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
1044	2019-01-18 19:58:02.385714+00	1859	21.09 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
1045	2019-01-18 19:58:02.393682+00	1860	21.09 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
1046	2019-01-18 19:58:02.400584+00	1861	21.09 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
1047	2019-01-18 19:58:02.408237+00	1862	21.09 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
1048	2019-01-18 19:58:02.415357+00	1863	21.09 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
1049	2019-01-18 19:58:02.423151+00	1864	21.09 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
1050	2019-01-18 19:58:02.431181+00	1865	21.09 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
1051	2019-01-18 19:58:02.440277+00	1866	21.09 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
1052	2019-01-18 19:58:02.44734+00	1867	21.09 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
1053	2019-01-18 19:58:02.454264+00	1868	21.09 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
1054	2019-01-18 19:58:02.46191+00	1869	21.09 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
1055	2019-01-18 19:58:02.469419+00	1870	21.09 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
1056	2019-01-18 19:58:02.47686+00	1871	21.09 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
1057	2019-01-18 19:58:02.485882+00	1872	21.09 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
1058	2019-01-18 19:58:02.49488+00	1873	21.09 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
1059	2019-01-18 19:58:02.501631+00	1874	21.09 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
1060	2019-01-18 19:58:02.512243+00	1875	21.09 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
1061	2019-01-18 19:58:02.521952+00	1876	21.09 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
1062	2019-01-18 19:58:02.529914+00	1877	21.09 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
1063	2019-01-18 19:58:02.537006+00	1878	21.09 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
1064	2019-01-18 19:58:02.544453+00	1879	21.09 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
1065	2019-01-18 19:58:02.550885+00	1880	21.09 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
1066	2019-01-18 19:58:02.558396+00	1881	21.09 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
1067	2019-01-18 19:58:02.565547+00	1882	21.09 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
1068	2019-01-18 19:58:02.572485+00	1883	21.09 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
1069	2019-01-18 19:58:02.579121+00	1884	21.09 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
1070	2019-01-18 19:58:02.586882+00	1885	21.09 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
1071	2019-01-18 19:58:02.594023+00	1886	21.09 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
1072	2019-01-18 19:58:02.601074+00	1887	21.09 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
1073	2019-01-18 19:58:02.607805+00	1888	21.09 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
1074	2019-01-18 19:58:02.613858+00	1889	21.09 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
1075	2019-01-18 19:58:02.620144+00	1890	21.09 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
1076	2019-01-18 19:58:02.626385+00	1891	21.09 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
1077	2019-01-18 19:58:02.643822+00	1892	21.09 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
1078	2019-01-18 19:58:02.662222+00	1893	21.09 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
1079	2019-01-18 19:58:02.682146+00	1894	21.09 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
1080	2019-01-18 19:58:02.71369+00	1895	21.09 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
1081	2019-01-18 19:58:02.719671+00	1896	21.09 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
1082	2019-01-18 19:58:02.727153+00	1897	21.09 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
1083	2019-01-18 19:58:02.733519+00	1898	21.09 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
1084	2019-01-18 19:58:02.740175+00	1899	21.09 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
1085	2019-01-18 19:58:02.747165+00	1900	21.09 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
1086	2019-01-18 19:58:02.753937+00	1901	21.09 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
1087	2019-01-18 19:58:02.761519+00	1902	21.09 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
1088	2019-01-18 19:58:02.770046+00	1903	21.09 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
1089	2019-01-18 19:58:02.779294+00	1904	21.09 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
1090	2019-01-18 19:58:02.787418+00	1905	21.09 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
1091	2019-01-18 19:58:02.794976+00	1906	21.09 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
1092	2019-01-18 19:58:02.801961+00	1907	21.09 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
1093	2019-01-18 19:58:02.809169+00	1908	21.09 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
1094	2019-01-18 19:58:02.816264+00	1909	21.09 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
1095	2019-01-18 19:58:02.823784+00	1910	21.09 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
1096	2019-01-18 19:58:02.831463+00	1911	21.09 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
1097	2019-01-18 19:58:02.839158+00	1912	21.09 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
1098	2019-01-18 19:58:02.846515+00	1913	21.09 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
1099	2019-01-18 19:58:02.855655+00	1914	21.09 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
1100	2019-01-18 19:58:02.865465+00	1915	21.09 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
1101	2019-01-18 19:58:02.872714+00	1916	21.09 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
1102	2019-01-18 19:58:02.879772+00	1917	21.09 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
1103	2019-01-18 19:58:02.887379+00	1918	21.09 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
1104	2019-01-18 19:58:02.8961+00	1919	21.09 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
1105	2019-01-18 19:58:02.905088+00	1920	21.09 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
1106	2019-01-18 19:58:02.915139+00	1921	21.09 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
1107	2019-01-18 19:58:02.924707+00	1922	21.09 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
1108	2019-01-18 19:58:02.933296+00	1923	21.09 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
1109	2019-01-18 19:58:02.94127+00	1924	21.09 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
1110	2019-01-18 19:59:59.475281+00	1999	23.07 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
1111	2019-01-18 19:59:59.483054+00	2000	23.07 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
1112	2019-01-18 19:59:59.489505+00	2001	23.07 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
1113	2019-01-18 19:59:59.496137+00	2002	23.07 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
1114	2019-01-18 19:59:59.502666+00	2003	23.07 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
1115	2019-01-18 19:59:59.509673+00	2004	23.07 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
1116	2019-01-18 19:59:59.516854+00	2005	23.07 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
1117	2019-01-18 19:59:59.523908+00	2006	23.07 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
1118	2019-01-18 19:59:59.530247+00	2007	23.07 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
1119	2019-01-18 19:59:59.536818+00	2008	23.07 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
1120	2019-01-18 19:59:59.542754+00	2009	23.07 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
1121	2019-01-18 19:59:59.549256+00	2010	23.07 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
1122	2019-01-18 19:59:59.556669+00	2011	23.07 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
1123	2019-01-18 19:59:59.56442+00	2012	23.07 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
1124	2019-01-18 19:59:59.570961+00	2013	23.07 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
1125	2019-01-18 19:59:59.577093+00	2014	23.07 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
1126	2019-01-18 19:59:59.583155+00	2015	23.07 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
1127	2019-01-18 19:59:59.589105+00	2016	23.07 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
1128	2019-01-18 19:59:59.595394+00	2017	23.07 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
1129	2019-01-18 19:59:59.602858+00	2018	23.07 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
1130	2019-01-18 19:59:59.610303+00	2019	23.07 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
1131	2019-01-18 19:59:59.617407+00	2020	23.07 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
1132	2019-01-18 19:59:59.625088+00	2021	23.07 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
1133	2019-01-18 19:59:59.631939+00	2022	23.07 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
1134	2019-01-18 19:59:59.638595+00	2023	23.07 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
1135	2019-01-18 19:59:59.645332+00	2024	23.07 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
1136	2019-01-18 19:59:59.652238+00	2025	23.07 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
1137	2019-01-18 19:59:59.659078+00	2026	23.07 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
1138	2019-01-18 19:59:59.665814+00	2027	23.07 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
1139	2019-01-18 19:59:59.672083+00	2028	23.07 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
1140	2019-01-18 19:59:59.679378+00	2029	23.07 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
1141	2019-01-18 19:59:59.686385+00	2030	23.07 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
1142	2019-01-18 19:59:59.692695+00	2031	23.07 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
1143	2019-01-18 19:59:59.699103+00	2032	23.07 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
1144	2019-01-18 19:59:59.705254+00	2033	23.07 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
1145	2019-01-18 19:59:59.711759+00	2034	23.07 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
1146	2019-01-18 19:59:59.71816+00	2035	23.07 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
1147	2019-01-18 19:59:59.724658+00	2036	23.07 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
1148	2019-01-18 19:59:59.731258+00	2037	23.07 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
1149	2019-01-18 19:59:59.737509+00	2038	23.07 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
1150	2019-01-18 19:59:59.743649+00	2039	23.07 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
1151	2019-01-18 19:59:59.750627+00	2040	23.07 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
1152	2019-01-18 19:59:59.757272+00	2041	23.07 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
1153	2019-01-18 19:59:59.764316+00	2042	23.07 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
1154	2019-01-18 19:59:59.770844+00	2043	23.07 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
1155	2019-01-18 19:59:59.776749+00	2044	23.07 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
1156	2019-01-18 19:59:59.783952+00	2045	23.07 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
1157	2019-01-18 19:59:59.790436+00	2046	23.07 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
1158	2019-01-18 19:59:59.797194+00	2047	23.07 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
1159	2019-01-18 19:59:59.80363+00	2048	23.07 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
1160	2019-01-18 19:59:59.809479+00	2049	23.07 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
1161	2019-01-18 19:59:59.816059+00	2050	23.07 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
1162	2019-01-18 19:59:59.821861+00	2051	23.07 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
1163	2019-01-18 19:59:59.82875+00	2052	23.07 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
1164	2019-01-18 19:59:59.834877+00	2053	23.07 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
1165	2019-01-18 19:59:59.840636+00	2054	23.07 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
1166	2019-01-18 19:59:59.846502+00	2055	23.07 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
1167	2019-01-18 19:59:59.852618+00	2056	23.07 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
1168	2019-01-18 19:59:59.858751+00	2057	23.07 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
1169	2019-01-18 19:59:59.865098+00	2058	23.07 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
1170	2019-01-18 19:59:59.870848+00	2059	23.07 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
1171	2019-01-18 19:59:59.877429+00	2060	23.07 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
1172	2019-01-18 19:59:59.88365+00	2061	23.07 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
1173	2019-01-18 19:59:59.88934+00	2062	23.07 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
1174	2019-01-18 19:59:59.895216+00	2063	23.07 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
1175	2019-01-18 19:59:59.901919+00	2064	23.07 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
1176	2019-01-18 19:59:59.908614+00	2065	23.07 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
1177	2019-01-18 19:59:59.915319+00	2066	23.07 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
1178	2019-01-18 19:59:59.921446+00	2067	23.07 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
1179	2019-01-18 19:59:59.92793+00	2068	23.07 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
1180	2019-01-18 19:59:59.935509+00	2069	23.07 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
1181	2019-01-18 19:59:59.941606+00	2070	23.07 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
1182	2019-01-18 19:59:59.948096+00	2071	23.07 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
1183	2019-01-18 19:59:59.954192+00	2072	23.07 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
1184	2019-01-18 20:01:51.872183+00	2147	24.08 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
1185	2019-01-18 20:01:51.878578+00	2148	24.08 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
1186	2019-01-18 20:01:51.885461+00	2149	24.08 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
1187	2019-01-18 20:01:51.891612+00	2150	24.08 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
1188	2019-01-18 20:01:51.897957+00	2151	24.08 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
1189	2019-01-18 20:01:51.904771+00	2152	24.08 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
1190	2019-01-18 20:01:51.911404+00	2153	24.08 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
1191	2019-01-18 20:01:51.91836+00	2154	24.08 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
1192	2019-01-18 20:01:51.924458+00	2155	24.08 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
1193	2019-01-18 20:01:51.93112+00	2156	24.08 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
1194	2019-01-18 20:01:51.937944+00	2157	24.08 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
1195	2019-01-18 20:01:51.944117+00	2158	24.08 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
1196	2019-01-18 20:01:51.950043+00	2159	24.08 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
1197	2019-01-18 20:01:51.956609+00	2160	24.08 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
1198	2019-01-18 20:01:51.96267+00	2161	24.08 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
1199	2019-01-18 20:01:51.969635+00	2162	24.08 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
1200	2019-01-18 20:01:51.97548+00	2163	24.08 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
1201	2019-01-18 20:01:51.981096+00	2164	24.08 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
1202	2019-01-18 20:01:51.987026+00	2165	24.08 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
1203	2019-01-18 20:01:51.993181+00	2166	24.08 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
1204	2019-01-18 20:01:51.99987+00	2167	24.08 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
1205	2019-01-18 20:01:52.00636+00	2168	24.08 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
1206	2019-01-18 20:01:52.012222+00	2169	24.08 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
1207	2019-01-18 20:01:52.018937+00	2170	24.08 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
1208	2019-01-18 20:01:52.027353+00	2171	24.08 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
1209	2019-01-18 20:01:52.035609+00	2172	24.08 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
1210	2019-01-18 20:01:52.042433+00	2173	24.08 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
1211	2019-01-18 20:01:52.049252+00	2174	24.08 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
1212	2019-01-18 20:01:52.05556+00	2175	24.08 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
1213	2019-01-18 20:01:52.062594+00	2176	24.08 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
1214	2019-01-18 20:01:52.07035+00	2177	24.08 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
1215	2019-01-18 20:01:52.076881+00	2178	24.08 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
1216	2019-01-18 20:01:52.082881+00	2179	24.08 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
1217	2019-01-18 20:01:52.088955+00	2180	24.08 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
1218	2019-01-18 20:01:52.095032+00	2181	24.08 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
1219	2019-01-18 20:01:52.114939+00	2182	24.08 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
1220	2019-01-18 20:01:52.135874+00	2183	24.08 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
1221	2019-01-18 20:01:52.152958+00	2184	24.08 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
1222	2019-01-18 20:01:52.184633+00	2185	24.08 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
1223	2019-01-18 20:01:52.1915+00	2186	24.08 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
1224	2019-01-18 20:01:52.19816+00	2187	24.08 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
1225	2019-01-18 20:01:52.20477+00	2188	24.08 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
1226	2019-01-18 20:01:52.211179+00	2189	24.08 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
1227	2019-01-18 20:01:52.217708+00	2190	24.08 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
1228	2019-01-18 20:01:52.223996+00	2191	24.08 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
1229	2019-01-18 20:01:52.229905+00	2192	24.08 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
1230	2019-01-18 20:01:52.236663+00	2193	24.08 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
1231	2019-01-18 20:01:52.242743+00	2194	24.08 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
1232	2019-01-18 20:01:52.248767+00	2195	24.08 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
1233	2019-01-18 20:01:52.255673+00	2196	24.08 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
1234	2019-01-18 20:01:52.26321+00	2197	24.08 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
1235	2019-01-18 20:01:52.271868+00	2198	24.08 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
1236	2019-01-18 20:01:52.278422+00	2199	24.08 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
1237	2019-01-18 20:01:52.284535+00	2200	24.08 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
1238	2019-01-18 20:01:52.290194+00	2201	24.08 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
1239	2019-01-18 20:01:52.29846+00	2202	24.08 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
1240	2019-01-18 20:01:52.306284+00	2203	24.08 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
1241	2019-01-18 20:01:52.313287+00	2204	24.08 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
1242	2019-01-18 20:01:52.320176+00	2205	24.08 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
1243	2019-01-18 20:01:52.32681+00	2206	24.08 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
1244	2019-01-18 20:01:52.333081+00	2207	24.08 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
1245	2019-01-18 20:01:52.339396+00	2208	24.08 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
1246	2019-01-18 20:01:52.34516+00	2209	24.08 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
1247	2019-01-18 20:01:52.351195+00	2210	24.08 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
1248	2019-01-18 20:01:52.356904+00	2211	24.08 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
1249	2019-01-18 20:01:52.362486+00	2212	24.08 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
1250	2019-01-18 20:01:52.368329+00	2213	24.08 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
1251	2019-01-18 20:01:52.374423+00	2214	24.08 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
1252	2019-01-18 20:01:52.379923+00	2215	24.08 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
1253	2019-01-18 20:01:52.386467+00	2216	24.08 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
1254	2019-01-18 20:01:52.39231+00	2217	24.08 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
1255	2019-01-18 20:01:52.39931+00	2218	24.08 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
1256	2019-01-18 20:01:52.406697+00	2219	24.08 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
1257	2019-01-18 20:01:52.41246+00	2220	24.08 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
1258	2019-01-18 20:04:30.756023+00	2295	25.06 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
1259	2019-01-18 20:04:30.762973+00	2296	25.06 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
1260	2019-01-18 20:04:30.769516+00	2297	25.06 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
1261	2019-01-18 20:04:30.776236+00	2298	25.06 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
1262	2019-01-18 20:04:30.782249+00	2299	25.06 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
1263	2019-01-18 20:04:30.788015+00	2300	25.06 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
1264	2019-01-18 20:04:30.793634+00	2301	25.06 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
1265	2019-01-18 20:04:30.799671+00	2302	25.06 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
1266	2019-01-18 20:04:30.805369+00	2303	25.06 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
1267	2019-01-18 20:04:30.8111+00	2304	25.06 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
1268	2019-01-18 20:04:30.81733+00	2305	25.06 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
1269	2019-01-18 20:04:30.823038+00	2306	25.06 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
1270	2019-01-18 20:04:30.829215+00	2307	25.06 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
1271	2019-01-18 20:04:30.835739+00	2308	25.06 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
1272	2019-01-18 20:04:30.841689+00	2309	25.06 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
1273	2019-01-18 20:04:30.847867+00	2310	25.06 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
1274	2019-01-18 20:04:30.853622+00	2311	25.06 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
1275	2019-01-18 20:04:30.85933+00	2312	25.06 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
1276	2019-01-18 20:04:30.866243+00	2313	25.06 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
1277	2019-01-18 20:04:30.872039+00	2314	25.06 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
1278	2019-01-18 20:04:30.877742+00	2315	25.06 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
1279	2019-01-18 20:04:30.883192+00	2316	25.06 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
1280	2019-01-18 20:04:30.88869+00	2317	25.06 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
1281	2019-01-18 20:04:30.895144+00	2318	25.06 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
1282	2019-01-18 20:04:30.90129+00	2319	25.06 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
1283	2019-01-18 20:04:30.908193+00	2320	25.06 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
1284	2019-01-18 20:04:30.917131+00	2321	25.06 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
1285	2019-01-18 20:04:30.924236+00	2322	25.06 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
1286	2019-01-18 20:04:30.931209+00	2323	25.06 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
1287	2019-01-18 20:04:30.937167+00	2324	25.06 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
1288	2019-01-18 20:04:30.94453+00	2325	25.06 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
1289	2019-01-18 20:04:30.954416+00	2326	25.06 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
1290	2019-01-18 20:04:30.963438+00	2327	25.06 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
1291	2019-01-18 20:04:30.970473+00	2328	25.06 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
1292	2019-01-18 20:04:30.978623+00	2329	25.06 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
1293	2019-01-18 20:04:30.985707+00	2330	25.06 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
1294	2019-01-18 20:04:30.991613+00	2331	25.06 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
1295	2019-01-18 20:04:30.998902+00	2332	25.06 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
1296	2019-01-18 20:04:31.005724+00	2333	25.06 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
1297	2019-01-18 20:04:31.013539+00	2334	25.06 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
1298	2019-01-18 20:04:31.020536+00	2335	25.06 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
1299	2019-01-18 20:04:31.027473+00	2336	25.06 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
1300	2019-01-18 20:04:31.033667+00	2337	25.06 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
1301	2019-01-18 20:04:31.039329+00	2338	25.06 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
1302	2019-01-18 20:04:31.046683+00	2339	25.06 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
1303	2019-01-18 20:04:31.052763+00	2340	25.06 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
1304	2019-01-18 20:04:31.058573+00	2341	25.06 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
1305	2019-01-18 20:04:31.064971+00	2342	25.06 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
1306	2019-01-18 20:04:31.07068+00	2343	25.06 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
1307	2019-01-18 20:04:31.076508+00	2344	25.06 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
1308	2019-01-18 20:04:31.083638+00	2345	25.06 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
1309	2019-01-18 20:04:31.089442+00	2346	25.06 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
1310	2019-01-18 20:04:31.097825+00	2347	25.06 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
1311	2019-01-18 20:04:31.103591+00	2348	25.06 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
1312	2019-01-18 20:04:31.112679+00	2349	25.06 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
1313	2019-01-18 20:04:31.119163+00	2350	25.06 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
1314	2019-01-18 20:04:31.125721+00	2351	25.06 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
1315	2019-01-18 20:04:31.132176+00	2352	25.06 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
1316	2019-01-18 20:04:31.138657+00	2353	25.06 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
1317	2019-01-18 20:04:31.144824+00	2354	25.06 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
1318	2019-01-18 20:04:31.152523+00	2355	25.06 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
1319	2019-01-18 20:04:31.160281+00	2356	25.06 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
1320	2019-01-18 20:04:31.167634+00	2357	25.06 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
1321	2019-01-18 20:04:31.173811+00	2358	25.06 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
1322	2019-01-18 20:04:31.179965+00	2359	25.06 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
1323	2019-01-18 20:04:31.185704+00	2360	25.06 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
1324	2019-01-18 20:04:31.191427+00	2361	25.06 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
1325	2019-01-18 20:04:31.197357+00	2362	25.06 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
1326	2019-01-18 20:04:31.203374+00	2363	25.06 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
1327	2019-01-18 20:04:31.209453+00	2364	25.06 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
1328	2019-01-18 20:04:31.216014+00	2365	25.06 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
1329	2019-01-18 20:04:31.221922+00	2366	25.06 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
1330	2019-01-18 20:04:31.228605+00	2367	25.06 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
1331	2019-01-18 20:04:31.234853+00	2368	25.06 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
1332	2019-01-18 20:06:49.586559+00	2443	26.07 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
1333	2019-01-18 20:06:49.593083+00	2444	26.07 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
1334	2019-01-18 20:06:49.599437+00	2445	26.07 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
1335	2019-01-18 20:06:49.605463+00	2446	26.07 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
1336	2019-01-18 20:06:49.611311+00	2447	26.07 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
1337	2019-01-18 20:06:49.618171+00	2448	26.07 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
1338	2019-01-18 20:06:49.624713+00	2449	26.07 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
1339	2019-01-18 20:06:49.631051+00	2450	26.07 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
1340	2019-01-18 20:06:49.637291+00	2451	26.07 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
1341	2019-01-18 20:06:49.643694+00	2452	26.07 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
1342	2019-01-18 20:06:49.650146+00	2453	26.07 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
1343	2019-01-18 20:06:49.657+00	2454	26.07 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
1344	2019-01-18 20:06:49.663273+00	2455	26.07 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
1345	2019-01-18 20:06:49.669404+00	2456	26.07 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
1346	2019-01-18 20:06:49.676152+00	2457	26.07 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
1347	2019-01-18 20:06:49.683191+00	2458	26.07 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
1348	2019-01-18 20:06:49.690395+00	2459	26.07 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
1349	2019-01-18 20:06:49.697352+00	2460	26.07 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
1350	2019-01-18 20:06:49.704642+00	2461	26.07 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
1351	2019-01-18 20:06:49.711119+00	2462	26.07 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
1352	2019-01-18 20:06:49.717707+00	2463	26.07 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
1353	2019-01-18 20:06:49.723805+00	2464	26.07 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
1354	2019-01-18 20:06:49.730057+00	2465	26.07 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
1355	2019-01-18 20:06:49.7361+00	2466	26.07 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
1356	2019-01-18 20:06:49.742049+00	2467	26.07 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
1357	2019-01-18 20:06:49.747761+00	2468	26.07 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
1358	2019-01-18 20:06:49.754564+00	2469	26.07 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
1359	2019-01-18 20:06:49.760495+00	2470	26.07 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
1360	2019-01-18 20:06:49.767208+00	2471	26.07 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
1361	2019-01-18 20:06:49.774534+00	2472	26.07 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
1362	2019-01-18 20:06:49.780436+00	2473	26.07 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
1363	2019-01-18 20:06:49.787965+00	2474	26.07 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
1364	2019-01-18 20:06:49.795073+00	2475	26.07 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
1365	2019-01-18 20:06:49.801626+00	2476	26.07 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
1366	2019-01-18 20:06:49.807869+00	2477	26.07 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
1367	2019-01-18 20:06:49.813449+00	2478	26.07 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
1368	2019-01-18 20:06:49.819735+00	2479	26.07 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
1369	2019-01-18 20:06:49.825765+00	2480	26.07 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
1370	2019-01-18 20:06:49.832303+00	2481	26.07 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
1371	2019-01-18 20:06:49.839891+00	2482	26.07 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
1372	2019-01-18 20:06:49.846017+00	2483	26.07 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
1373	2019-01-18 20:06:49.852149+00	2484	26.07 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
1374	2019-01-18 20:06:49.858945+00	2485	26.07 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
1375	2019-01-18 20:06:49.865806+00	2486	26.07 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
1376	2019-01-18 20:06:49.873294+00	2487	26.07 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
1377	2019-01-18 20:06:49.879527+00	2488	26.07 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
1378	2019-01-18 20:06:49.886532+00	2489	26.07 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
1379	2019-01-18 20:06:49.892836+00	2490	26.07 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
1380	2019-01-18 20:06:49.899199+00	2491	26.07 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
1381	2019-01-18 20:06:49.906268+00	2492	26.07 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
1382	2019-01-18 20:06:49.912847+00	2493	26.07 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
1383	2019-01-18 20:06:49.921685+00	2494	26.07 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
1384	2019-01-18 20:06:49.929029+00	2495	26.07 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
1385	2019-01-18 20:06:49.935626+00	2496	26.07 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
1386	2019-01-18 20:06:49.941828+00	2497	26.07 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
1387	2019-01-18 20:06:49.948095+00	2498	26.07 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
1388	2019-01-18 20:06:49.955769+00	2499	26.07 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
1389	2019-01-18 20:06:49.962422+00	2500	26.07 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
1390	2019-01-18 20:06:49.968699+00	2501	26.07 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
1391	2019-01-18 20:06:49.974851+00	2502	26.07 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
1392	2019-01-18 20:06:49.980454+00	2503	26.07 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
1393	2019-01-18 20:06:49.986741+00	2504	26.07 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
1394	2019-01-18 20:06:49.992777+00	2505	26.07 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
1395	2019-01-18 20:06:49.999736+00	2506	26.07 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
1396	2019-01-18 20:06:50.006002+00	2507	26.07 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
1397	2019-01-18 20:06:50.012927+00	2508	26.07 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
1398	2019-01-18 20:06:50.019579+00	2509	26.07 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
1399	2019-01-18 20:06:50.033825+00	2510	26.07 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
1400	2019-01-18 20:06:50.044079+00	2511	26.07 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
1401	2019-01-18 20:06:50.062519+00	2512	26.07 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
1402	2019-01-18 20:06:50.08166+00	2513	26.07 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
1403	2019-01-18 20:06:50.113325+00	2514	26.07 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
1404	2019-01-18 20:06:50.120007+00	2515	26.07 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
1405	2019-01-18 20:06:50.125799+00	2516	26.07 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
1406	2019-01-18 20:08:24.741357+00	2591	26.15 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
1407	2019-01-18 20:08:24.74743+00	2592	26.15 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
1408	2019-01-18 20:08:24.753952+00	2593	26.15 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
1409	2019-01-18 20:08:24.763792+00	2594	26.15 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
1410	2019-01-18 20:08:24.771766+00	2595	26.15 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
1411	2019-01-18 20:08:24.778961+00	2596	26.15 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
1412	2019-01-18 20:08:24.785767+00	2597	26.15 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
1413	2019-01-18 20:08:24.792371+00	2598	26.15 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
1414	2019-01-18 20:08:24.798749+00	2599	26.15 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
1415	2019-01-18 20:08:24.807194+00	2600	26.15 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
1416	2019-01-18 20:08:24.815198+00	2601	26.15 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
1417	2019-01-18 20:08:24.821878+00	2602	26.15 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
1418	2019-01-18 20:08:24.82945+00	2603	26.15 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
1419	2019-01-18 20:08:24.835957+00	2604	26.15 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
1420	2019-01-18 20:08:24.843922+00	2605	26.15 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
1421	2019-01-18 20:08:24.850111+00	2606	26.15 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
1422	2019-01-18 20:08:24.857024+00	2607	26.15 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
1423	2019-01-18 20:08:24.864196+00	2608	26.15 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
1424	2019-01-18 20:08:24.870474+00	2609	26.15 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
1425	2019-01-18 20:08:24.877065+00	2610	26.15 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
1426	2019-01-18 20:08:24.883155+00	2611	26.15 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
1427	2019-01-18 20:08:24.889522+00	2612	26.15 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
1428	2019-01-18 20:08:24.895613+00	2613	26.15 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
1429	2019-01-18 20:08:24.902082+00	2614	26.15 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
1430	2019-01-18 20:08:24.910063+00	2615	26.15 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
1431	2019-01-18 20:08:24.917378+00	2616	26.15 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
1432	2019-01-18 20:08:24.924392+00	2617	26.15 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
1433	2019-01-18 20:08:24.930705+00	2618	26.15 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
1434	2019-01-18 20:08:24.936655+00	2619	26.15 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
1435	2019-01-18 20:08:24.943524+00	2620	26.15 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
1436	2019-01-18 20:08:24.949931+00	2621	26.15 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
1437	2019-01-18 20:08:24.95656+00	2622	26.15 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
1438	2019-01-18 20:08:24.963234+00	2623	26.15 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
1439	2019-01-18 20:08:24.969814+00	2624	26.15 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
1440	2019-01-18 20:08:24.97647+00	2625	26.15 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
1441	2019-01-18 20:08:24.982712+00	2626	26.15 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
1442	2019-01-18 20:08:24.988604+00	2627	26.15 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
1443	2019-01-18 20:08:24.994648+00	2628	26.15 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
1444	2019-01-18 20:08:25.000335+00	2629	26.15 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
1445	2019-01-18 20:08:25.006134+00	2630	26.15 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
1446	2019-01-18 20:08:25.012306+00	2631	26.15 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
1447	2019-01-18 20:08:25.018568+00	2632	26.15 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
1448	2019-01-18 20:08:25.024888+00	2633	26.15 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
1449	2019-01-18 20:08:25.031346+00	2634	26.15 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
1450	2019-01-18 20:08:25.037604+00	2635	26.15 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
1451	2019-01-18 20:08:25.044687+00	2636	26.15 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
1452	2019-01-18 20:08:25.050933+00	2637	26.15 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
1453	2019-01-18 20:08:25.058196+00	2638	26.15 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
1454	2019-01-18 20:08:25.064621+00	2639	26.15 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
1455	2019-01-18 20:08:25.071077+00	2640	26.15 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
1456	2019-01-18 20:08:25.078144+00	2641	26.15 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
1457	2019-01-18 20:08:25.084237+00	2642	26.15 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
1458	2019-01-18 20:08:25.090576+00	2643	26.15 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
1459	2019-01-18 20:08:25.09834+00	2644	26.15 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
1460	2019-01-18 20:08:25.104885+00	2645	26.15 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
1461	2019-01-18 20:08:25.110948+00	2646	26.15 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
1462	2019-01-18 20:08:25.116873+00	2647	26.15 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
1463	2019-01-18 20:08:25.123296+00	2648	26.15 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
1464	2019-01-18 20:08:25.129343+00	2649	26.15 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
1465	2019-01-18 20:08:25.135119+00	2650	26.15 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
1466	2019-01-18 20:08:25.141055+00	2651	26.15 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
1467	2019-01-18 20:08:25.146991+00	2652	26.15 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
1468	2019-01-18 20:08:25.152514+00	2653	26.15 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
1469	2019-01-18 20:08:25.159012+00	2654	26.15 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
1470	2019-01-18 20:08:25.165238+00	2655	26.15 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
1471	2019-01-18 20:08:25.171156+00	2656	26.15 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
1472	2019-01-18 20:08:25.17702+00	2657	26.15 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
1473	2019-01-18 20:08:25.183836+00	2658	26.15 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
1474	2019-01-18 20:08:25.19033+00	2659	26.15 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
1475	2019-01-18 20:08:25.196418+00	2660	26.15 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
1476	2019-01-18 20:08:25.203416+00	2661	26.15 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
1477	2019-01-18 20:08:25.211205+00	2662	26.15 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
1478	2019-01-18 20:08:25.217868+00	2663	26.15 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
1479	2019-01-18 20:08:25.226241+00	2664	26.15 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
1480	2019-01-18 20:11:33.030809+00	2739	27.05 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
1481	2019-01-18 20:11:33.037483+00	2740	27.05 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
1482	2019-01-18 20:11:33.043971+00	2741	27.05 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
1483	2019-01-18 20:11:33.050629+00	2742	27.05 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
1484	2019-01-18 20:11:33.057252+00	2743	27.05 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
1485	2019-01-18 20:11:33.063765+00	2744	27.05 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
1486	2019-01-18 20:11:33.069962+00	2745	27.05 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
1487	2019-01-18 20:11:33.076105+00	2746	27.05 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
1488	2019-01-18 20:11:33.081837+00	2747	27.05 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
1489	2019-01-18 20:11:33.087987+00	2748	27.05 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
1490	2019-01-18 20:11:33.093782+00	2749	27.05 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
1491	2019-01-18 20:11:33.100041+00	2750	27.05 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
1492	2019-01-18 20:11:33.106307+00	2751	27.05 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
1493	2019-01-18 20:11:33.113084+00	2752	27.05 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
1494	2019-01-18 20:11:33.120233+00	2753	27.05 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
1495	2019-01-18 20:11:33.126605+00	2754	27.05 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
1496	2019-01-18 20:11:33.133151+00	2755	27.05 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
1497	2019-01-18 20:11:33.139967+00	2756	27.05 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
1498	2019-01-18 20:11:33.14654+00	2757	27.05 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
1499	2019-01-18 20:11:33.153515+00	2758	27.05 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
1500	2019-01-18 20:11:33.160372+00	2759	27.05 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
1501	2019-01-18 20:11:33.167556+00	2760	27.05 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
1502	2019-01-18 20:11:33.174176+00	2761	27.05 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
1503	2019-01-18 20:11:33.18062+00	2762	27.05 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
1504	2019-01-18 20:11:33.187187+00	2763	27.05 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
1505	2019-01-18 20:11:33.193754+00	2764	27.05 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
1506	2019-01-18 20:11:33.20044+00	2765	27.05 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
1507	2019-01-18 20:11:33.207274+00	2766	27.05 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
1508	2019-01-18 20:11:33.214198+00	2767	27.05 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
1509	2019-01-18 20:11:33.221693+00	2768	27.05 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
1510	2019-01-18 20:11:33.228675+00	2769	27.05 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
1511	2019-01-18 20:11:33.235546+00	2770	27.05 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
1512	2019-01-18 20:11:33.24251+00	2771	27.05 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
1513	2019-01-18 20:11:33.249443+00	2772	27.05 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
1514	2019-01-18 20:11:33.256373+00	2773	27.05 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
1515	2019-01-18 20:11:33.263676+00	2774	27.05 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
1516	2019-01-18 20:11:33.270766+00	2775	27.05 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
1517	2019-01-18 20:11:33.27701+00	2776	27.05 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
1518	2019-01-18 20:11:33.282992+00	2777	27.05 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
1519	2019-01-18 20:11:33.290083+00	2778	27.05 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
1520	2019-01-18 20:11:33.296432+00	2779	27.05 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
1521	2019-01-18 20:11:33.302361+00	2780	27.05 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
1522	2019-01-18 20:11:33.308463+00	2781	27.05 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
1523	2019-01-18 20:11:33.314422+00	2782	27.05 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
1524	2019-01-18 20:11:33.320809+00	2783	27.05 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
1525	2019-01-18 20:11:33.327133+00	2784	27.05 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
1526	2019-01-18 20:11:33.3342+00	2785	27.05 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
1527	2019-01-18 20:11:33.340767+00	2786	27.05 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
1528	2019-01-18 20:11:33.346885+00	2787	27.05 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
1529	2019-01-18 20:11:33.353819+00	2788	27.05 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
1530	2019-01-18 20:11:33.36069+00	2789	27.05 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
1531	2019-01-18 20:11:33.36737+00	2790	27.05 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
1532	2019-01-18 20:11:33.3734+00	2791	27.05 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
1533	2019-01-18 20:11:33.379529+00	2792	27.05 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
1534	2019-01-18 20:11:33.386069+00	2793	27.05 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
1535	2019-01-18 20:11:33.39235+00	2794	27.05 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
1536	2019-01-18 20:11:33.399106+00	2795	27.05 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
1537	2019-01-18 20:11:33.406131+00	2796	27.05 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
1538	2019-01-18 20:11:33.412986+00	2797	27.05 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
1539	2019-01-18 20:11:33.421738+00	2798	27.05 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
1540	2019-01-18 20:11:33.429509+00	2799	27.05 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
1541	2019-01-18 20:11:33.437085+00	2800	27.05 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
1542	2019-01-18 20:11:33.44369+00	2801	27.05 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
1543	2019-01-18 20:11:33.45075+00	2802	27.05 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
1544	2019-01-18 20:11:33.458132+00	2803	27.05 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
1545	2019-01-18 20:11:33.466717+00	2804	27.05 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
1546	2019-01-18 20:11:33.479752+00	2805	27.05 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
1547	2019-01-18 20:11:33.49661+00	2806	27.05 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
1548	2019-01-18 20:11:33.516431+00	2807	27.05 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
1549	2019-01-18 20:11:33.536164+00	2808	27.05 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
1550	2019-01-18 20:11:33.56929+00	2809	27.05 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
1551	2019-01-18 20:11:33.57681+00	2810	27.05 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
1552	2019-01-18 20:11:33.583858+00	2811	27.05 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
1553	2019-01-18 20:11:33.591751+00	2812	27.05 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
1554	2019-01-18 20:11:58.251692+00	2887	27.46 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
1555	2019-01-18 20:11:58.257893+00	2888	27.46 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
1556	2019-01-18 20:11:58.263754+00	2889	27.46 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
1557	2019-01-18 20:11:58.270106+00	2890	27.46 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
1558	2019-01-18 20:11:58.276593+00	2891	27.46 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
1559	2019-01-18 20:11:58.282429+00	2892	27.46 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
1560	2019-01-18 20:11:58.288566+00	2893	27.46 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
1561	2019-01-18 20:11:58.294478+00	2894	27.46 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
1562	2019-01-18 20:11:58.301323+00	2895	27.46 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
1563	2019-01-18 20:11:58.308139+00	2896	27.46 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
1564	2019-01-18 20:11:58.314903+00	2897	27.46 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
1565	2019-01-18 20:11:58.321196+00	2898	27.46 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
1566	2019-01-18 20:11:58.327285+00	2899	27.46 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
1567	2019-01-18 20:11:58.333186+00	2900	27.46 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
1568	2019-01-18 20:11:58.338893+00	2901	27.46 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
1569	2019-01-18 20:11:58.34512+00	2902	27.46 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
1570	2019-01-18 20:11:58.351535+00	2903	27.46 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
1571	2019-01-18 20:11:58.358952+00	2904	27.46 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
1572	2019-01-18 20:11:58.365936+00	2905	27.46 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
1573	2019-01-18 20:11:58.372407+00	2906	27.46 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
1574	2019-01-18 20:11:58.378782+00	2907	27.46 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
1575	2019-01-18 20:11:58.384902+00	2908	27.46 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
1576	2019-01-18 20:11:58.390676+00	2909	27.46 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
1577	2019-01-18 20:11:58.396458+00	2910	27.46 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
1578	2019-01-18 20:11:58.401885+00	2911	27.46 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
1579	2019-01-18 20:11:58.408039+00	2912	27.46 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
1580	2019-01-18 20:11:58.414244+00	2913	27.46 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
1581	2019-01-18 20:11:58.420579+00	2914	27.46 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
1582	2019-01-18 20:11:58.427021+00	2915	27.46 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
1583	2019-01-18 20:11:58.433176+00	2916	27.46 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
1584	2019-01-18 20:11:58.439203+00	2917	27.46 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
1585	2019-01-18 20:11:58.445443+00	2918	27.46 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
1586	2019-01-18 20:11:58.452046+00	2919	27.46 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
1587	2019-01-18 20:11:58.458504+00	2920	27.46 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
1588	2019-01-18 20:11:58.464834+00	2921	27.46 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
1589	2019-01-18 20:11:58.470924+00	2922	27.46 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
1590	2019-01-18 20:11:58.47677+00	2923	27.46 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
1591	2019-01-18 20:11:58.482348+00	2924	27.46 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
1592	2019-01-18 20:11:58.487962+00	2925	27.46 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
1593	2019-01-18 20:11:58.493417+00	2926	27.46 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
1594	2019-01-18 20:11:58.499843+00	2927	27.46 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
1595	2019-01-18 20:11:58.505869+00	2928	27.46 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
1596	2019-01-18 20:11:58.511789+00	2929	27.46 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
1597	2019-01-18 20:11:58.518246+00	2930	27.46 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
1598	2019-01-18 20:11:58.52409+00	2931	27.46 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
1599	2019-01-18 20:11:58.529771+00	2932	27.46 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
1600	2019-01-18 20:11:58.536197+00	2933	27.46 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
1601	2019-01-18 20:11:58.542101+00	2934	27.46 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
1602	2019-01-18 20:11:58.548825+00	2935	27.46 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
1603	2019-01-18 20:11:58.557194+00	2936	27.46 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
1604	2019-01-18 20:11:58.563792+00	2937	27.46 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
1605	2019-01-18 20:11:58.570487+00	2938	27.46 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
1606	2019-01-18 20:11:58.576638+00	2939	27.46 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
1607	2019-01-18 20:11:58.583497+00	2940	27.46 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
1608	2019-01-18 20:11:58.589783+00	2941	27.46 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
1609	2019-01-18 20:11:58.595795+00	2942	27.46 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
1610	2019-01-18 20:11:58.602168+00	2943	27.46 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
1611	2019-01-18 20:11:58.608043+00	2944	27.46 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
1612	2019-01-18 20:11:58.614762+00	2945	27.46 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
1613	2019-01-18 20:11:58.621371+00	2946	27.46 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
1614	2019-01-18 20:11:58.627644+00	2947	27.46 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
1615	2019-01-18 20:11:58.633864+00	2948	27.46 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
1616	2019-01-18 20:11:58.639968+00	2949	27.46 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
1617	2019-01-18 20:11:58.645696+00	2950	27.46 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
1618	2019-01-18 20:11:58.651918+00	2951	27.46 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
1619	2019-01-18 20:11:58.658082+00	2952	27.46 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
1620	2019-01-18 20:11:58.664256+00	2953	27.46 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
1621	2019-01-18 20:11:58.670541+00	2954	27.46 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
1622	2019-01-18 20:11:58.676614+00	2955	27.46 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
1623	2019-01-18 20:11:58.682384+00	2956	27.46 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
1624	2019-01-18 20:11:58.688562+00	2957	27.46 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
1625	2019-01-18 20:11:58.694269+00	2958	27.46 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
1626	2019-01-18 20:11:58.701058+00	2959	27.46 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
1627	2019-01-18 20:11:58.707832+00	2960	27.46 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
1628	2019-01-18 20:17:39.622741+00	3035	MB7 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
1629	2019-01-18 20:17:39.631566+00	3036	MB7 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
1630	2019-01-18 20:17:39.641571+00	3037	MB7 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
1631	2019-01-18 20:17:39.650894+00	3038	MB7 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
1632	2019-01-18 20:17:39.660862+00	3039	MB7 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
1633	2019-01-18 20:17:39.671953+00	3040	MB7 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
1634	2019-01-18 20:17:39.681553+00	3041	MB7 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
1635	2019-01-18 20:17:39.693223+00	3042	MB7 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
1636	2019-01-18 20:17:39.704239+00	3043	MB7 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
1637	2019-01-18 20:17:39.715454+00	3044	MB7 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
1638	2019-01-18 20:17:39.725553+00	3045	MB7 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
1639	2019-01-18 20:17:39.735557+00	3046	MB7 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
1640	2019-01-18 20:17:39.746481+00	3047	MB7 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
1641	2019-01-18 20:17:39.756367+00	3048	MB7 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
1642	2019-01-18 20:17:39.767243+00	3049	MB7 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
1643	2019-01-18 20:17:39.778308+00	3050	MB7 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
1644	2019-01-18 20:17:39.789068+00	3051	MB7 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
1645	2019-01-18 20:17:39.798728+00	3052	MB7 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
1646	2019-01-18 20:17:39.808165+00	3053	MB7 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
1647	2019-01-18 20:17:39.819441+00	3054	MB7 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
1648	2019-01-18 20:17:39.82969+00	3055	MB7 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
1649	2019-01-18 20:17:39.840783+00	3056	MB7 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
1650	2019-01-18 20:17:39.851415+00	3057	MB7 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
1651	2019-01-18 20:17:39.862654+00	3058	MB7 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
1652	2019-01-18 20:17:39.872517+00	3059	MB7 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
1653	2019-01-18 20:17:39.883982+00	3060	MB7 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
1654	2019-01-18 20:17:39.894534+00	3061	MB7 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
1655	2019-01-18 20:17:39.910079+00	3062	MB7 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
1656	2019-01-18 20:17:39.922247+00	3063	MB7 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
1657	2019-01-18 20:17:39.934032+00	3064	MB7 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
1658	2019-01-18 20:17:39.945547+00	3065	MB7 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
1659	2019-01-18 20:17:39.955978+00	3066	MB7 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
1660	2019-01-18 20:17:39.967248+00	3067	MB7 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
1661	2019-01-18 20:17:39.977126+00	3068	MB7 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
1662	2019-01-18 20:17:39.987555+00	3069	MB7 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
1663	2019-01-18 20:17:39.999077+00	3070	MB7 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
1664	2019-01-18 20:17:40.011197+00	3071	MB7 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
1665	2019-01-18 20:17:40.022316+00	3072	MB7 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
1666	2019-01-18 20:17:40.032989+00	3073	MB7 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
1667	2019-01-18 20:17:40.043614+00	3074	MB7 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
1668	2019-01-18 20:17:40.054208+00	3075	MB7 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
1669	2019-01-18 20:17:40.074968+00	3076	MB7 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
1670	2019-01-18 20:17:40.085564+00	3077	MB7 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
1671	2019-01-18 20:17:40.095088+00	3078	MB7 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
1672	2019-01-18 20:17:40.122828+00	3079	MB7 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
1673	2019-01-18 20:17:40.15065+00	3080	MB7 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
1674	2019-01-18 20:17:40.173851+00	3081	MB7 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
1675	2019-01-18 20:17:40.216914+00	3082	MB7 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
1676	2019-01-18 20:17:40.239275+00	3083	MB7 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
1677	2019-01-18 20:17:40.249559+00	3084	MB7 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
1678	2019-01-18 20:17:40.259299+00	3085	MB7 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
1679	2019-01-18 20:17:40.270587+00	3086	MB7 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
1680	2019-01-18 20:17:40.279701+00	3087	MB7 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
1681	2019-01-18 20:17:40.289132+00	3088	MB7 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
1682	2019-01-18 20:17:40.299868+00	3089	MB7 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
1683	2019-01-18 20:17:40.310366+00	3090	MB7 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
1684	2019-01-18 20:17:40.320423+00	3091	MB7 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
1685	2019-01-18 20:17:40.331284+00	3092	MB7 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
1686	2019-01-18 20:17:40.341075+00	3093	MB7 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
1687	2019-01-18 20:17:40.351487+00	3094	MB7 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
1688	2019-01-18 20:17:40.360831+00	3095	MB7 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
1689	2019-01-18 20:17:40.370678+00	3096	MB7 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
1690	2019-01-18 20:17:40.380832+00	3097	MB7 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
1691	2019-01-18 20:17:40.390655+00	3098	MB7 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
1692	2019-01-18 20:17:40.400368+00	3099	MB7 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
1693	2019-01-18 20:17:40.409758+00	3100	MB7 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
1694	2019-01-18 20:17:40.420627+00	3101	MB7 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
1695	2019-01-18 20:17:40.431033+00	3102	MB7 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
1696	2019-01-18 20:17:40.441144+00	3103	MB7 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
1697	2019-01-18 20:17:40.451133+00	3104	MB7 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
1698	2019-01-18 20:17:40.461081+00	3105	MB7 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
1699	2019-01-18 20:17:40.470474+00	3106	MB7 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
1700	2019-01-18 20:17:40.48051+00	3107	MB7 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
1701	2019-01-18 20:17:40.489798+00	3108	MB7 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
1702	2019-01-18 20:35:23.945429+00	3183	MB5 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
1703	2019-01-18 20:35:23.951701+00	3184	MB5 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
1704	2019-01-18 20:35:23.960315+00	3185	MB5 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
1705	2019-01-18 20:35:23.969288+00	3186	MB5 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
1706	2019-01-18 20:35:23.978429+00	3187	MB5 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
1707	2019-01-18 20:35:23.984902+00	3188	MB5 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
1708	2019-01-18 20:35:23.991066+00	3189	MB5 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
1709	2019-01-18 20:35:23.997274+00	3190	MB5 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
1710	2019-01-18 20:35:24.00382+00	3191	MB5 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
1711	2019-01-18 20:35:24.01336+00	3192	MB5 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
1712	2019-01-18 20:35:24.02333+00	3193	MB5 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
1713	2019-01-18 20:35:24.031853+00	3194	MB5 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
1714	2019-01-18 20:35:24.037864+00	3195	MB5 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
1715	2019-01-18 20:35:24.044215+00	3196	MB5 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
1716	2019-01-18 20:35:24.050545+00	3197	MB5 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
1717	2019-01-18 20:35:24.057879+00	3198	MB5 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
1718	2019-01-18 20:35:24.070112+00	3199	MB5 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
1719	2019-01-18 20:35:24.080312+00	3200	MB5 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
1720	2019-01-18 20:35:24.086445+00	3201	MB5 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
1721	2019-01-18 20:35:24.092985+00	3202	MB5 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
1722	2019-01-18 20:35:24.099755+00	3203	MB5 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
1723	2019-01-18 20:35:24.106139+00	3204	MB5 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
1724	2019-01-18 20:35:24.116036+00	3205	MB5 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
1725	2019-01-18 20:35:24.124655+00	3206	MB5 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
1726	2019-01-18 20:35:24.133191+00	3207	MB5 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
1727	2019-01-18 20:35:24.13924+00	3208	MB5 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
1728	2019-01-18 20:35:24.145642+00	3209	MB5 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
1729	2019-01-18 20:35:24.151371+00	3210	MB5 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
1730	2019-01-18 20:35:24.157197+00	3211	MB5 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
1731	2019-01-18 20:35:24.163186+00	3212	MB5 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
1732	2019-01-18 20:35:24.169054+00	3213	MB5 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
1733	2019-01-18 20:35:24.174979+00	3214	MB5 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
1734	2019-01-18 20:35:24.181333+00	3215	MB5 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
1735	2019-01-18 20:35:24.187254+00	3216	MB5 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
1736	2019-01-18 20:35:24.196342+00	3217	MB5 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
1737	2019-01-18 20:35:24.203387+00	3218	MB5 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
1738	2019-01-18 20:35:24.209801+00	3219	MB5 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
1739	2019-01-18 20:35:24.217775+00	3220	MB5 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
1740	2019-01-18 20:35:24.224603+00	3221	MB5 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
1741	2019-01-18 20:35:24.231249+00	3222	MB5 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
1742	2019-01-18 20:35:24.237594+00	3223	MB5 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
1743	2019-01-18 20:35:24.243461+00	3224	MB5 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
1744	2019-01-18 20:35:24.249474+00	3225	MB5 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
1745	2019-01-18 20:35:24.2552+00	3226	MB5 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
1746	2019-01-18 20:35:24.261632+00	3227	MB5 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
1747	2019-01-18 20:35:24.268031+00	3228	MB5 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
1748	2019-01-18 20:35:24.273951+00	3229	MB5 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
1749	2019-01-18 20:35:24.281639+00	3230	MB5 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
1750	2019-01-18 20:35:24.289335+00	3231	MB5 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
1751	2019-01-18 20:35:24.296825+00	3232	MB5 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
1752	2019-01-18 20:35:24.303343+00	3233	MB5 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
1753	2019-01-18 20:35:24.309761+00	3234	MB5 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
1754	2019-01-18 20:35:24.316172+00	3235	MB5 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
1755	2019-01-18 20:35:24.323328+00	3236	MB5 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
1756	2019-01-18 20:35:24.331194+00	3237	MB5 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
1757	2019-01-18 20:35:24.337571+00	3238	MB5 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
1758	2019-01-18 20:35:24.345543+00	3239	MB5 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
1759	2019-01-18 20:35:24.352885+00	3240	MB5 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
1760	2019-01-18 20:35:24.359243+00	3241	MB5 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
1761	2019-01-18 20:35:24.366218+00	3242	MB5 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
1762	2019-01-18 20:35:24.372702+00	3243	MB5 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
1763	2019-01-18 20:35:24.379825+00	3244	MB5 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
1764	2019-01-18 20:35:24.385959+00	3245	MB5 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
1765	2019-01-18 20:35:24.391912+00	3246	MB5 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
1766	2019-01-18 20:35:24.397984+00	3247	MB5 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
1767	2019-01-18 20:35:24.404453+00	3248	MB5 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
1768	2019-01-18 20:35:24.41158+00	3249	MB5 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
1769	2019-01-18 20:35:24.417991+00	3250	MB5 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
1770	2019-01-18 20:35:24.423897+00	3251	MB5 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
1771	2019-01-18 20:35:24.430177+00	3252	MB5 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
1772	2019-01-18 20:35:24.436496+00	3253	MB5 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
1773	2019-01-18 20:35:24.442438+00	3254	MB5 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
1774	2019-01-18 20:35:24.449048+00	3255	MB5 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
1775	2019-01-18 20:35:24.455027+00	3256	MB5 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
1776	2019-01-18 20:37:30.080022+00	3331	CCB42 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
1777	2019-01-18 20:37:30.086452+00	3332	CCB42 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
1778	2019-01-18 20:37:30.09239+00	3333	CCB42 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
1779	2019-01-18 20:37:30.098565+00	3334	CCB42 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
1780	2019-01-18 20:37:30.105876+00	3335	CCB42 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
1781	2019-01-18 20:37:30.113829+00	3336	CCB42 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
1782	2019-01-18 20:37:30.121611+00	3337	CCB42 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
1783	2019-01-18 20:37:30.128441+00	3338	CCB42 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
1784	2019-01-18 20:37:30.134786+00	3339	CCB42 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
1785	2019-01-18 20:37:30.141016+00	3340	CCB42 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
1786	2019-01-18 20:37:30.147271+00	3341	CCB42 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
1787	2019-01-18 20:37:30.154247+00	3342	CCB42 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
1788	2019-01-18 20:37:30.161508+00	3343	CCB42 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
1789	2019-01-18 20:37:30.169936+00	3344	CCB42 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
1790	2019-01-18 20:37:30.176393+00	3345	CCB42 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
1791	2019-01-18 20:37:30.182767+00	3346	CCB42 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
1792	2019-01-18 20:37:30.189029+00	3347	CCB42 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
1793	2019-01-18 20:37:30.194794+00	3348	CCB42 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
1794	2019-01-18 20:37:30.200388+00	3349	CCB42 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
1795	2019-01-18 20:37:30.208159+00	3350	CCB42 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
1796	2019-01-18 20:37:30.215991+00	3351	CCB42 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
1797	2019-01-18 20:37:30.223146+00	3352	CCB42 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
1798	2019-01-18 20:37:30.229903+00	3353	CCB42 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
1799	2019-01-18 20:37:30.236822+00	3354	CCB42 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
1800	2019-01-18 20:37:30.242932+00	3355	CCB42 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
1801	2019-01-18 20:37:30.249018+00	3356	CCB42 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
1802	2019-01-18 20:37:30.257719+00	3357	CCB42 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
1803	2019-01-18 20:37:30.265682+00	3358	CCB42 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
1804	2019-01-18 20:37:30.272643+00	3359	CCB42 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
1805	2019-01-18 20:37:30.283098+00	3360	CCB42 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
1806	2019-01-18 20:37:30.290219+00	3361	CCB42 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
1807	2019-01-18 20:37:30.297386+00	3362	CCB42 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
1808	2019-01-18 20:37:30.304525+00	3363	CCB42 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
1809	2019-01-18 20:37:30.312043+00	3364	CCB42 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
1810	2019-01-18 20:37:30.320469+00	3365	CCB42 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
1811	2019-01-18 20:37:30.328561+00	3366	CCB42 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
1812	2019-01-18 20:37:30.33515+00	3367	CCB42 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
1813	2019-01-18 20:37:30.341798+00	3368	CCB42 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
1814	2019-01-18 20:37:30.34877+00	3369	CCB42 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
1815	2019-01-18 20:37:30.356311+00	3370	CCB42 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
1816	2019-01-18 20:37:30.375988+00	3371	CCB42 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
1817	2019-01-18 20:37:30.394556+00	3372	CCB42 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
1818	2019-01-18 20:37:30.409262+00	3373	CCB42 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
1819	2019-01-18 20:37:30.446344+00	3374	CCB42 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
1820	2019-01-18 20:37:30.453579+00	3375	CCB42 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
1821	2019-01-18 20:37:30.460286+00	3376	CCB42 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
1822	2019-01-18 20:37:30.466475+00	3377	CCB42 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
1823	2019-01-18 20:37:30.472658+00	3378	CCB42 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
1824	2019-01-18 20:37:30.47844+00	3379	CCB42 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
1825	2019-01-18 20:37:30.484553+00	3380	CCB42 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
1826	2019-01-18 20:37:30.490363+00	3381	CCB42 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
1827	2019-01-18 20:37:30.496694+00	3382	CCB42 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
1828	2019-01-18 20:37:30.504433+00	3383	CCB42 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
1829	2019-01-18 20:37:30.515222+00	3384	CCB42 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
1830	2019-01-18 20:37:30.523993+00	3385	CCB42 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
1831	2019-01-18 20:37:30.531484+00	3386	CCB42 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
1832	2019-01-18 20:37:30.538049+00	3387	CCB42 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
1833	2019-01-18 20:37:30.544437+00	3388	CCB42 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
1834	2019-01-18 20:37:30.551606+00	3389	CCB42 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
1835	2019-01-18 20:37:30.559838+00	3390	CCB42 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
1836	2019-01-18 20:37:30.567242+00	3391	CCB42 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
1837	2019-01-18 20:37:30.575537+00	3392	CCB42 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
1838	2019-01-18 20:37:30.582982+00	3393	CCB42 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
1839	2019-01-18 20:37:30.590621+00	3394	CCB42 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
1840	2019-01-18 20:37:30.597101+00	3395	CCB42 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
1841	2019-01-18 20:37:30.604429+00	3396	CCB42 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
1842	2019-01-18 20:37:30.612955+00	3397	CCB42 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
1843	2019-01-18 20:37:30.620151+00	3398	CCB42 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
1844	2019-01-18 20:37:30.626837+00	3399	CCB42 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
1845	2019-01-18 20:37:30.633667+00	3400	CCB42 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
1846	2019-01-18 20:37:30.640092+00	3401	CCB42 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
1847	2019-01-18 20:37:30.64677+00	3402	CCB42 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
1848	2019-01-18 20:37:30.653584+00	3403	CCB42 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
1849	2019-01-18 20:37:30.660044+00	3404	CCB42 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
1850	2019-01-18 20:39:03.178832+00	3479	BB45 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
1851	2019-01-18 20:39:03.185089+00	3480	BB45 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
1852	2019-01-18 20:39:03.191275+00	3481	BB45 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
1853	2019-01-18 20:39:03.196951+00	3482	BB45 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
1854	2019-01-18 20:39:03.204058+00	3483	BB45 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
1855	2019-01-18 20:39:03.211094+00	3484	BB45 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
1856	2019-01-18 20:39:03.21726+00	3485	BB45 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
1857	2019-01-18 20:39:03.223307+00	3486	BB45 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
1858	2019-01-18 20:39:03.228808+00	3487	BB45 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
1859	2019-01-18 20:39:03.23472+00	3488	BB45 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
1860	2019-01-18 20:39:03.241603+00	3489	BB45 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
1861	2019-01-18 20:39:03.247394+00	3490	BB45 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
1862	2019-01-18 20:39:03.253859+00	3491	BB45 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
1863	2019-01-18 20:39:03.265169+00	3492	BB45 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
1864	2019-01-18 20:39:03.275002+00	3493	BB45 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
1865	2019-01-18 20:39:03.281912+00	3494	BB45 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
1866	2019-01-18 20:39:03.28802+00	3495	BB45 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
1867	2019-01-18 20:39:03.294432+00	3496	BB45 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
1868	2019-01-18 20:39:03.300229+00	3497	BB45 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
1869	2019-01-18 20:39:03.31089+00	3498	BB45 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
1870	2019-01-18 20:39:03.317727+00	3499	BB45 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
1871	2019-01-18 20:39:03.32678+00	3500	BB45 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
1872	2019-01-18 20:39:03.33338+00	3501	BB45 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
1873	2019-01-18 20:39:03.340379+00	3502	BB45 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
1874	2019-01-18 20:39:03.346583+00	3503	BB45 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
1875	2019-01-18 20:39:03.355828+00	3504	BB45 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
1876	2019-01-18 20:39:03.365577+00	3505	BB45 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
1877	2019-01-18 20:39:03.372619+00	3506	BB45 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
1878	2019-01-18 20:39:03.379158+00	3507	BB45 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
1879	2019-01-18 20:39:03.385246+00	3508	BB45 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
1880	2019-01-18 20:39:03.391901+00	3509	BB45 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
1881	2019-01-18 20:39:03.398083+00	3510	BB45 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
1882	2019-01-18 20:39:03.40467+00	3511	BB45 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
1883	2019-01-18 20:39:03.413804+00	3512	BB45 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
1884	2019-01-18 20:39:03.421248+00	3513	BB45 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
1885	2019-01-18 20:39:03.428238+00	3514	BB45 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
1886	2019-01-18 20:39:03.43452+00	3515	BB45 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
1887	2019-01-18 20:39:03.440984+00	3516	BB45 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
1888	2019-01-18 20:39:03.447248+00	3517	BB45 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
1889	2019-01-18 20:39:03.45464+00	3518	BB45 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
1890	2019-01-18 20:39:03.463047+00	3519	BB45 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
1891	2019-01-18 20:39:03.469859+00	3520	BB45 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
1892	2019-01-18 20:39:03.476698+00	3521	BB45 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
1893	2019-01-18 20:39:03.483541+00	3522	BB45 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
1894	2019-01-18 20:39:03.490146+00	3523	BB45 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
1895	2019-01-18 20:39:03.496129+00	3524	BB45 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
1896	2019-01-18 20:39:03.501969+00	3525	BB45 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
1897	2019-01-18 20:39:03.508437+00	3526	BB45 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
1898	2019-01-18 20:39:03.514452+00	3527	BB45 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
1899	2019-01-18 20:39:03.520014+00	3528	BB45 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
1900	2019-01-18 20:39:03.526058+00	3529	BB45 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
1901	2019-01-18 20:39:03.531834+00	3530	BB45 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
1902	2019-01-18 20:39:03.537737+00	3531	BB45 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
1903	2019-01-18 20:39:03.544616+00	3532	BB45 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
1904	2019-01-18 20:39:03.550485+00	3533	BB45 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
1905	2019-01-18 20:39:03.557473+00	3534	BB45 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
1906	2019-01-18 20:39:03.564349+00	3535	BB45 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
1907	2019-01-18 20:39:03.570899+00	3536	BB45 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
1908	2019-01-18 20:39:03.578098+00	3537	BB45 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
1909	2019-01-18 20:39:03.584289+00	3538	BB45 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
1910	2019-01-18 20:39:03.590153+00	3539	BB45 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
1911	2019-01-18 20:39:03.595936+00	3540	BB45 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
1912	2019-01-18 20:39:03.601639+00	3541	BB45 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
1913	2019-01-18 20:39:03.607266+00	3542	BB45 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
1914	2019-01-18 20:39:03.613791+00	3543	BB45 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
1915	2019-01-18 20:39:03.620078+00	3544	BB45 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
1916	2019-01-18 20:39:03.627189+00	3545	BB45 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
1917	2019-01-18 20:39:03.633975+00	3546	BB45 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
1918	2019-01-18 20:39:03.640716+00	3547	BB45 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
1919	2019-01-18 20:39:03.647065+00	3548	BB45 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
1920	2019-01-18 20:39:03.655418+00	3549	BB45 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
1921	2019-01-18 20:39:03.667061+00	3550	BB45 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
1922	2019-01-18 20:39:03.676205+00	3551	BB45 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
1923	2019-01-18 20:39:03.682721+00	3552	BB45 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
1924	2019-01-18 20:45:27.863997+00	3627	OC3 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
1925	2019-01-18 20:45:27.871357+00	3628	OC3 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
1926	2019-01-18 20:45:27.878174+00	3629	OC3 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
1927	2019-01-18 20:45:27.884425+00	3630	OC3 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
1928	2019-01-18 20:45:27.890514+00	3631	OC3 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
1929	2019-01-18 20:45:27.897187+00	3632	OC3 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
1930	2019-01-18 20:45:27.904669+00	3633	OC3 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
1931	2019-01-18 20:45:27.911183+00	3634	OC3 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
1932	2019-01-18 20:45:27.917457+00	3635	OC3 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
1933	2019-01-18 20:45:27.923417+00	3636	OC3 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
1934	2019-01-18 20:45:27.930327+00	3637	OC3 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
1935	2019-01-18 20:45:27.936994+00	3638	OC3 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
1936	2019-01-18 20:45:27.943126+00	3639	OC3 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
1937	2019-01-18 20:45:27.949614+00	3640	OC3 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
1938	2019-01-18 20:45:27.955365+00	3641	OC3 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
1939	2019-01-18 20:45:27.961258+00	3642	OC3 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
1940	2019-01-18 20:45:27.967857+00	3643	OC3 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
1941	2019-01-18 20:45:27.973778+00	3644	OC3 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
1942	2019-01-18 20:45:27.979692+00	3645	OC3 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
1943	2019-01-18 20:45:27.98541+00	3646	OC3 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
1944	2019-01-18 20:45:27.991049+00	3647	OC3 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
1945	2019-01-18 20:45:27.996752+00	3648	OC3 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
1946	2019-01-18 20:45:28.002882+00	3649	OC3 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
1947	2019-01-18 20:45:28.008954+00	3650	OC3 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
1948	2019-01-18 20:45:28.016125+00	3651	OC3 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
1949	2019-01-18 20:45:28.022421+00	3652	OC3 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
1950	2019-01-18 20:45:28.029376+00	3653	OC3 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
1951	2019-01-18 20:45:28.035405+00	3654	OC3 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
1952	2019-01-18 20:45:28.041157+00	3655	OC3 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
1953	2019-01-18 20:45:28.046944+00	3656	OC3 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
1954	2019-01-18 20:45:28.052694+00	3657	OC3 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
1955	2019-01-18 20:45:28.058143+00	3658	OC3 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
1956	2019-01-18 20:45:28.063711+00	3659	OC3 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
1957	2019-01-18 20:45:28.069714+00	3660	OC3 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
1958	2019-01-18 20:45:28.075476+00	3661	OC3 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
1959	2019-01-18 20:45:28.081629+00	3662	OC3 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
1960	2019-01-18 20:45:28.08803+00	3663	OC3 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
1961	2019-01-18 20:45:28.094663+00	3664	OC3 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
1962	2019-01-18 20:45:28.102601+00	3665	OC3 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
1963	2019-01-18 20:45:28.11221+00	3666	OC3 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
1964	2019-01-18 20:45:28.120207+00	3667	OC3 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
1965	2019-01-18 20:45:28.127325+00	3668	OC3 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
1966	2019-01-18 20:45:28.136387+00	3669	OC3 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
1967	2019-01-18 20:45:28.145695+00	3670	OC3 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
1968	2019-01-18 20:45:28.156598+00	3671	OC3 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
1969	2019-01-18 20:45:28.163897+00	3672	OC3 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
1970	2019-01-18 20:45:28.170545+00	3673	OC3 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
1971	2019-01-18 20:45:28.189113+00	3674	OC3 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
1972	2019-01-18 20:45:28.207815+00	3675	OC3 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
1973	2019-01-18 20:45:28.223933+00	3676	OC3 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
1974	2019-01-18 20:45:28.258634+00	3677	OC3 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
1975	2019-01-18 20:45:28.264799+00	3678	OC3 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
1976	2019-01-18 20:45:28.270817+00	3679	OC3 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
1977	2019-01-18 20:45:28.276819+00	3680	OC3 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
1978	2019-01-18 20:45:28.283075+00	3681	OC3 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
1979	2019-01-18 20:45:28.289455+00	3682	OC3 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
1980	2019-01-18 20:45:28.295515+00	3683	OC3 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
1981	2019-01-18 20:45:28.301758+00	3684	OC3 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
1982	2019-01-18 20:45:28.308383+00	3685	OC3 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
1983	2019-01-18 20:45:28.316167+00	3686	OC3 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
1984	2019-01-18 20:45:28.323067+00	3687	OC3 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
1985	2019-01-18 20:45:28.330496+00	3688	OC3 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
1986	2019-01-18 20:45:28.337776+00	3689	OC3 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
1987	2019-01-18 20:45:28.343903+00	3690	OC3 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
1988	2019-01-18 20:45:28.349933+00	3691	OC3 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
1989	2019-01-18 20:45:28.357284+00	3692	OC3 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
1990	2019-01-18 20:45:28.365069+00	3693	OC3 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
1991	2019-01-18 20:45:28.37211+00	3694	OC3 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
1992	2019-01-18 20:45:28.378882+00	3695	OC3 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
1993	2019-01-18 20:45:28.385422+00	3696	OC3 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
1994	2019-01-18 20:45:28.391616+00	3697	OC3 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
1995	2019-01-18 20:45:28.398515+00	3698	OC3 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
1996	2019-01-18 20:45:28.405405+00	3699	OC3 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
1997	2019-01-18 20:45:28.411987+00	3700	OC3 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
1998	2019-01-18 20:53:33.225806+00	46	ESP-2 - 2014-03-31 00:00:00-04:00	1	new through import_export	50	1
1999	2019-01-18 20:53:33.232117+00	47	ESP-2 - 2014-04-07 00:00:00-04:00	1	new through import_export	50	1
2000	2019-01-18 20:53:33.238381+00	48	ESP-2 - 2014-04-14 00:00:00-04:00	1	new through import_export	50	1
2001	2019-01-18 20:53:33.243954+00	49	ESP-2 - 2014-04-21 00:00:00-04:00	1	new through import_export	50	1
2002	2019-01-18 20:53:33.249701+00	50	ESP-2 - 2014-04-28 00:00:00-04:00	1	new through import_export	50	1
2003	2019-01-18 20:53:33.256165+00	51	ESP-2 - 2014-05-02 00:00:00-04:00	1	new through import_export	50	1
2004	2019-01-18 20:53:33.262441+00	52	ESP-2 - 2014-05-03 00:00:00-04:00	1	new through import_export	50	1
2005	2019-01-18 20:53:33.268281+00	53	ESP-2 - 2014-05-04 00:00:00-04:00	1	new through import_export	50	1
2006	2019-01-18 20:53:33.274141+00	54	ESP-2 - 2014-05-05 00:00:00-04:00	1	new through import_export	50	1
2007	2019-01-18 20:53:33.279604+00	55	ESP-2 - 2014-05-06 00:00:00-04:00	1	new through import_export	50	1
2008	2019-01-18 20:53:33.286675+00	56	ESP-2 - 2014-05-07 00:00:00-04:00	1	new through import_export	50	1
2009	2019-01-18 20:53:33.295324+00	57	ESP-2 - 2014-05-08 00:00:00-04:00	1	new through import_export	50	1
2010	2019-01-18 20:53:33.301483+00	58	ESP-2 - 2014-05-09 00:00:00-04:00	1	new through import_export	50	1
2011	2019-01-18 20:53:33.310636+00	59	ESP-2 - 2014-05-12 00:00:00-04:00	1	new through import_export	50	1
2012	2019-01-18 20:53:33.318064+00	60	ESP-2 - 2014-05-13 00:00:00-04:00	1	new through import_export	50	1
2013	2019-01-18 20:53:33.326094+00	61	ESP-2 - 2014-05-14 00:00:00-04:00	1	new through import_export	50	1
2014	2019-01-18 20:53:33.334628+00	62	ESP-2 - 2014-05-15 00:00:00-04:00	1	new through import_export	50	1
2015	2019-01-18 20:53:33.341004+00	63	ESP-2 - 2014-05-16 00:00:00-04:00	1	new through import_export	50	1
2016	2019-01-18 20:53:33.347351+00	64	ESP-2 - 2014-05-19 00:00:00-04:00	1	new through import_export	50	1
2017	2019-01-18 20:53:33.354549+00	65	ESP-2 - 2014-05-20 00:00:00-04:00	1	new through import_export	50	1
2018	2019-01-18 20:53:33.36105+00	66	ESP-2 - 2014-05-21 00:00:00-04:00	1	new through import_export	50	1
2019	2019-01-18 20:53:33.367755+00	67	ESP-2 - 2014-05-22 00:00:00-04:00	1	new through import_export	50	1
2020	2019-01-18 20:53:33.374214+00	68	ESP-2 - 2014-05-23 00:00:00-04:00	1	new through import_export	50	1
2021	2019-01-18 20:53:33.380646+00	69	ESP-2 - 2014-05-26 00:00:00-04:00	1	new through import_export	50	1
2022	2019-01-18 20:53:33.38676+00	70	ESP-2 - 2014-05-27 00:00:00-04:00	1	new through import_export	50	1
2023	2019-01-18 20:53:33.392917+00	71	ESP-2 - 2014-05-28 00:00:00-04:00	1	new through import_export	50	1
2024	2019-01-18 20:53:33.399553+00	72	ESP-2 - 2014-05-29 00:00:00-04:00	1	new through import_export	50	1
2025	2019-01-18 20:53:33.40583+00	73	ESP-2 - 2014-05-30 00:00:00-04:00	1	new through import_export	50	1
2026	2019-01-18 20:53:33.41216+00	74	ESP-2 - 2014-06-02 00:00:00-04:00	1	new through import_export	50	1
2027	2019-01-18 20:53:33.418104+00	75	ESP-2 - 2014-06-03 00:00:00-04:00	1	new through import_export	50	1
2028	2019-01-18 20:53:33.424347+00	76	ESP-2 - 2014-06-04 00:00:00-04:00	1	new through import_export	50	1
2029	2019-01-18 20:53:33.430205+00	77	ESP-2 - 2014-06-05 00:00:00-04:00	1	new through import_export	50	1
2030	2019-01-18 20:53:33.436302+00	78	ESP-2 - 2014-06-06 00:00:00-04:00	1	new through import_export	50	1
2031	2019-01-18 20:53:33.44243+00	79	ESP-2 - 2014-06-09 00:00:00-04:00	1	new through import_export	50	1
2032	2019-01-18 20:53:33.448757+00	80	ESP-2 - 2014-06-10 00:00:00-04:00	1	new through import_export	50	1
2033	2019-01-18 20:53:33.455055+00	81	ESP-2 - 2014-06-11 00:00:00-04:00	1	new through import_export	50	1
2034	2019-01-18 20:53:33.460766+00	82	ESP-2 - 2014-06-12 00:00:00-04:00	1	new through import_export	50	1
2035	2019-01-18 20:53:33.466529+00	83	ESP-2 - 2014-06-13 00:00:00-04:00	1	new through import_export	50	1
2036	2019-01-18 20:53:33.472379+00	84	ESP-2 - 2014-06-16 00:00:00-04:00	1	new through import_export	50	1
2037	2019-01-18 20:53:33.478799+00	85	ESP-2 - 2014-06-17 00:00:00-04:00	1	new through import_export	50	1
2038	2019-01-18 20:53:33.484832+00	86	ESP-2 - 2014-06-18 00:00:00-04:00	1	new through import_export	50	1
2039	2019-01-18 20:53:33.490874+00	87	ESP-2 - 2014-06-19 00:00:00-04:00	1	new through import_export	50	1
2040	2019-01-18 20:53:33.496899+00	88	ESP-2 - 2014-06-20 00:00:00-04:00	1	new through import_export	50	1
2041	2019-01-18 20:53:33.504117+00	89	ESP-2 - 2014-06-23 00:00:00-04:00	1	new through import_export	50	1
2042	2019-01-18 20:53:33.512938+00	90	ESP-2 - 2014-06-30 00:00:00-04:00	1	new through import_export	50	1
2043	2019-01-18 20:58:53.582259+00	136	ESP-1 - 2014-03-31 00:00:00-04:00	1	new through import_export	50	1
2044	2019-01-18 20:58:53.589342+00	137	ESP-1 - 2014-04-07 00:00:00-04:00	1	new through import_export	50	1
2045	2019-01-18 20:58:53.596151+00	138	ESP-1 - 2014-04-14 00:00:00-04:00	1	new through import_export	50	1
2046	2019-01-18 20:58:53.602495+00	139	ESP-1 - 2014-04-21 00:00:00-04:00	1	new through import_export	50	1
2047	2019-01-18 20:58:53.60927+00	140	ESP-1 - 2014-04-28 00:00:00-04:00	1	new through import_export	50	1
2048	2019-01-18 20:58:53.616628+00	141	ESP-1 - 2014-05-02 00:00:00-04:00	1	new through import_export	50	1
2049	2019-01-18 20:58:53.623934+00	142	ESP-1 - 2014-05-03 00:00:00-04:00	1	new through import_export	50	1
2050	2019-01-18 20:58:53.630894+00	143	ESP-1 - 2014-05-04 00:00:00-04:00	1	new through import_export	50	1
2051	2019-01-18 20:58:53.637653+00	144	ESP-1 - 2014-05-05 00:00:00-04:00	1	new through import_export	50	1
2052	2019-01-18 20:58:53.644396+00	145	ESP-1 - 2014-05-06 00:00:00-04:00	1	new through import_export	50	1
2053	2019-01-18 20:58:53.651198+00	146	ESP-1 - 2014-05-07 00:00:00-04:00	1	new through import_export	50	1
2054	2019-01-18 20:58:53.658135+00	147	ESP-1 - 2014-05-08 00:00:00-04:00	1	new through import_export	50	1
2055	2019-01-18 20:58:53.664776+00	148	ESP-1 - 2014-05-09 00:00:00-04:00	1	new through import_export	50	1
2056	2019-01-18 20:58:53.671297+00	149	ESP-1 - 2014-05-12 00:00:00-04:00	1	new through import_export	50	1
2057	2019-01-18 20:58:53.677695+00	150	ESP-1 - 2014-05-13 00:00:00-04:00	1	new through import_export	50	1
2058	2019-01-18 20:58:53.684727+00	151	ESP-1 - 2014-05-14 00:00:00-04:00	1	new through import_export	50	1
2059	2019-01-18 20:58:53.69114+00	152	ESP-1 - 2014-05-15 00:00:00-04:00	1	new through import_export	50	1
2060	2019-01-18 20:58:53.697461+00	153	ESP-1 - 2014-05-16 00:00:00-04:00	1	new through import_export	50	1
2061	2019-01-18 20:58:53.703931+00	154	ESP-1 - 2014-05-19 00:00:00-04:00	1	new through import_export	50	1
2062	2019-01-18 20:58:53.710404+00	155	ESP-1 - 2014-05-20 00:00:00-04:00	1	new through import_export	50	1
2063	2019-01-18 20:58:53.717083+00	156	ESP-1 - 2014-05-21 00:00:00-04:00	1	new through import_export	50	1
2064	2019-01-18 20:58:53.723721+00	157	ESP-1 - 2014-05-22 00:00:00-04:00	1	new through import_export	50	1
2065	2019-01-18 20:58:53.730603+00	158	ESP-1 - 2014-05-23 00:00:00-04:00	1	new through import_export	50	1
2066	2019-01-18 20:58:53.737051+00	159	ESP-1 - 2014-05-26 00:00:00-04:00	1	new through import_export	50	1
2067	2019-01-18 20:58:53.743357+00	160	ESP-1 - 2014-05-27 00:00:00-04:00	1	new through import_export	50	1
2068	2019-01-18 20:58:53.749889+00	161	ESP-1 - 2014-05-28 00:00:00-04:00	1	new through import_export	50	1
2069	2019-01-18 20:58:53.756336+00	162	ESP-1 - 2014-05-29 00:00:00-04:00	1	new through import_export	50	1
2070	2019-01-18 20:58:53.762748+00	163	ESP-1 - 2014-05-30 00:00:00-04:00	1	new through import_export	50	1
2071	2019-01-18 20:58:53.768846+00	164	ESP-1 - 2014-06-02 00:00:00-04:00	1	new through import_export	50	1
2072	2019-01-18 20:58:53.77539+00	165	ESP-1 - 2014-06-03 00:00:00-04:00	1	new through import_export	50	1
2073	2019-01-18 20:58:53.782356+00	166	ESP-1 - 2014-06-04 00:00:00-04:00	1	new through import_export	50	1
2074	2019-01-18 20:58:53.788906+00	167	ESP-1 - 2014-06-05 00:00:00-04:00	1	new through import_export	50	1
2075	2019-01-18 20:58:53.795906+00	168	ESP-1 - 2014-06-06 00:00:00-04:00	1	new through import_export	50	1
2076	2019-01-18 20:58:53.802016+00	169	ESP-1 - 2014-06-09 00:00:00-04:00	1	new through import_export	50	1
2077	2019-01-18 20:58:53.808912+00	170	ESP-1 - 2014-06-10 00:00:00-04:00	1	new through import_export	50	1
2078	2019-01-18 20:58:53.815712+00	171	ESP-1 - 2014-06-11 00:00:00-04:00	1	new through import_export	50	1
2079	2019-01-18 20:58:53.821862+00	172	ESP-1 - 2014-06-12 00:00:00-04:00	1	new through import_export	50	1
2080	2019-01-18 20:58:53.828783+00	173	ESP-1 - 2014-06-13 00:00:00-04:00	1	new through import_export	50	1
2081	2019-01-18 20:58:53.834978+00	174	ESP-1 - 2014-06-16 00:00:00-04:00	1	new through import_export	50	1
2082	2019-01-18 20:58:53.841433+00	175	ESP-1 - 2014-06-17 00:00:00-04:00	1	new through import_export	50	1
2083	2019-01-18 20:58:53.847962+00	176	ESP-1 - 2014-06-18 00:00:00-04:00	1	new through import_export	50	1
2084	2019-01-18 20:58:53.85599+00	177	ESP-1 - 2014-06-19 00:00:00-04:00	1	new through import_export	50	1
2085	2019-01-18 20:58:53.863367+00	178	ESP-1 - 2014-06-20 00:00:00-04:00	1	new through import_export	50	1
2086	2019-01-18 20:58:53.871546+00	179	ESP-1 - 2014-06-23 00:00:00-04:00	1	new through import_export	50	1
2087	2019-01-18 20:58:53.879161+00	180	ESP-1 - 2014-06-30 00:00:00-04:00	1	new through import_export	50	1
2088	2019-01-18 21:00:02.282428+00	226	ESP-3 - 2014-03-31 00:00:00-04:00	1	new through import_export	50	1
2089	2019-01-18 21:00:02.288807+00	227	ESP-3 - 2014-04-07 00:00:00-04:00	1	new through import_export	50	1
2090	2019-01-18 21:00:02.296269+00	228	ESP-3 - 2014-04-14 00:00:00-04:00	1	new through import_export	50	1
2091	2019-01-18 21:00:02.303059+00	229	ESP-3 - 2014-04-21 00:00:00-04:00	1	new through import_export	50	1
2092	2019-01-18 21:00:02.309831+00	230	ESP-3 - 2014-04-28 00:00:00-04:00	1	new through import_export	50	1
2093	2019-01-18 21:00:02.316175+00	231	ESP-3 - 2014-05-02 00:00:00-04:00	1	new through import_export	50	1
2094	2019-01-18 21:00:02.322985+00	232	ESP-3 - 2014-05-03 00:00:00-04:00	1	new through import_export	50	1
2095	2019-01-18 21:00:02.330107+00	233	ESP-3 - 2014-05-04 00:00:00-04:00	1	new through import_export	50	1
2096	2019-01-18 21:00:02.336408+00	234	ESP-3 - 2014-05-05 00:00:00-04:00	1	new through import_export	50	1
2097	2019-01-18 21:00:02.343201+00	235	ESP-3 - 2014-05-06 00:00:00-04:00	1	new through import_export	50	1
2098	2019-01-18 21:00:02.34956+00	236	ESP-3 - 2014-05-07 00:00:00-04:00	1	new through import_export	50	1
2099	2019-01-18 21:00:02.356466+00	237	ESP-3 - 2014-05-08 00:00:00-04:00	1	new through import_export	50	1
2100	2019-01-18 21:00:02.363858+00	238	ESP-3 - 2014-05-09 00:00:00-04:00	1	new through import_export	50	1
2101	2019-01-18 21:00:02.370106+00	239	ESP-3 - 2014-05-12 00:00:00-04:00	1	new through import_export	50	1
2102	2019-01-18 21:00:02.377067+00	240	ESP-3 - 2014-05-13 00:00:00-04:00	1	new through import_export	50	1
2103	2019-01-18 21:00:02.383776+00	241	ESP-3 - 2014-05-14 00:00:00-04:00	1	new through import_export	50	1
2104	2019-01-18 21:00:02.390793+00	242	ESP-3 - 2014-05-15 00:00:00-04:00	1	new through import_export	50	1
2105	2019-01-18 21:00:02.398245+00	243	ESP-3 - 2014-05-16 00:00:00-04:00	1	new through import_export	50	1
2106	2019-01-18 21:00:02.407135+00	244	ESP-3 - 2014-05-19 00:00:00-04:00	1	new through import_export	50	1
2107	2019-01-18 21:00:02.413909+00	245	ESP-3 - 2014-05-20 00:00:00-04:00	1	new through import_export	50	1
2108	2019-01-18 21:00:02.42136+00	246	ESP-3 - 2014-05-21 00:00:00-04:00	1	new through import_export	50	1
2109	2019-01-18 21:00:02.429394+00	247	ESP-3 - 2014-05-22 00:00:00-04:00	1	new through import_export	50	1
2110	2019-01-18 21:00:02.436325+00	248	ESP-3 - 2014-05-23 00:00:00-04:00	1	new through import_export	50	1
2111	2019-01-18 21:00:02.443392+00	249	ESP-3 - 2014-05-26 00:00:00-04:00	1	new through import_export	50	1
2112	2019-01-18 21:00:02.450105+00	250	ESP-3 - 2014-05-27 00:00:00-04:00	1	new through import_export	50	1
2113	2019-01-18 21:00:02.456894+00	251	ESP-3 - 2014-05-28 00:00:00-04:00	1	new through import_export	50	1
2114	2019-01-18 21:00:02.463967+00	252	ESP-3 - 2014-05-29 00:00:00-04:00	1	new through import_export	50	1
2115	2019-01-18 21:00:02.470258+00	253	ESP-3 - 2014-05-30 00:00:00-04:00	1	new through import_export	50	1
2116	2019-01-18 21:00:02.476986+00	254	ESP-3 - 2014-06-02 00:00:00-04:00	1	new through import_export	50	1
2117	2019-01-18 21:00:02.48381+00	255	ESP-3 - 2014-06-03 00:00:00-04:00	1	new through import_export	50	1
2118	2019-01-18 21:00:02.490563+00	256	ESP-3 - 2014-06-04 00:00:00-04:00	1	new through import_export	50	1
2119	2019-01-18 21:00:02.497487+00	257	ESP-3 - 2014-06-05 00:00:00-04:00	1	new through import_export	50	1
2120	2019-01-18 21:00:02.503974+00	258	ESP-3 - 2014-06-06 00:00:00-04:00	1	new through import_export	50	1
2121	2019-01-18 21:00:02.510918+00	259	ESP-3 - 2014-06-09 00:00:00-04:00	1	new through import_export	50	1
2122	2019-01-18 21:00:02.519793+00	260	ESP-3 - 2014-06-10 00:00:00-04:00	1	new through import_export	50	1
2123	2019-01-18 21:00:02.528833+00	261	ESP-3 - 2014-06-11 00:00:00-04:00	1	new through import_export	50	1
2124	2019-01-18 21:00:02.536634+00	262	ESP-3 - 2014-06-12 00:00:00-04:00	1	new through import_export	50	1
2125	2019-01-18 21:00:02.543462+00	263	ESP-3 - 2014-06-13 00:00:00-04:00	1	new through import_export	50	1
2126	2019-01-18 21:00:02.549992+00	264	ESP-3 - 2014-06-16 00:00:00-04:00	1	new through import_export	50	1
2127	2019-01-18 21:00:02.557064+00	265	ESP-3 - 2014-06-17 00:00:00-04:00	1	new through import_export	50	1
2128	2019-01-18 21:00:02.566022+00	266	ESP-3 - 2014-06-18 00:00:00-04:00	1	new through import_export	50	1
2129	2019-01-18 21:00:02.57478+00	267	ESP-3 - 2014-06-19 00:00:00-04:00	1	new through import_export	50	1
2130	2019-01-18 21:00:02.582811+00	268	ESP-3 - 2014-06-20 00:00:00-04:00	1	new through import_export	50	1
2131	2019-01-18 21:00:02.589474+00	269	ESP-3 - 2014-06-23 00:00:00-04:00	1	new through import_export	50	1
2132	2019-01-18 21:00:02.596318+00	270	ESP-3 - 2014-06-30 00:00:00-04:00	1	new through import_export	50	1
2133	2019-01-18 21:05:39.436796+00	387	ESP-3 - 2015-04-07 00:00:00-04:00	1	new through import_export	50	1
2134	2019-01-18 21:05:39.442784+00	388	ESP-3 - 2015-04-13 00:00:00-04:00	1	new through import_export	50	1
2135	2019-01-18 21:05:39.448947+00	389	ESP-3 - 2015-04-14 00:00:00-04:00	1	new through import_export	50	1
2136	2019-01-18 21:05:39.455086+00	390	ESP-3 - 2015-04-15 00:00:00-04:00	1	new through import_export	50	1
2137	2019-01-18 21:05:39.461849+00	391	ESP-3 - 2015-04-20 00:00:00-04:00	1	new through import_export	50	1
2138	2019-01-18 21:05:39.468188+00	392	ESP-3 - 2015-04-21 00:00:00-04:00	1	new through import_export	50	1
2139	2019-01-18 21:05:39.474207+00	393	ESP-3 - 2015-04-22 00:00:00-04:00	1	new through import_export	50	1
2140	2019-01-18 21:05:39.480944+00	394	ESP-3 - 2015-04-26 00:00:00-04:00	1	new through import_export	50	1
2141	2019-01-18 21:05:39.487042+00	395	ESP-3 - 2015-04-27 00:00:00-04:00	1	new through import_export	50	1
2142	2019-01-18 21:05:39.493162+00	396	ESP-3 - 2015-04-29 00:00:00-04:00	1	new through import_export	50	1
2143	2019-01-18 21:05:39.500142+00	397	ESP-3 - 2015-05-03 00:00:00-04:00	1	new through import_export	50	1
2144	2019-01-18 21:05:39.506382+00	398	ESP-3 - 2015-05-04 00:00:00-04:00	1	new through import_export	50	1
2145	2019-01-18 21:05:39.512899+00	399	ESP-3 - 2015-05-05 00:00:00-04:00	1	new through import_export	50	1
2146	2019-01-18 21:05:39.5191+00	400	ESP-3 - 2015-05-06 00:00:00-04:00	1	new through import_export	50	1
2147	2019-01-18 21:05:39.524803+00	401	ESP-3 - 2015-05-07 00:00:00-04:00	1	new through import_export	50	1
2148	2019-01-18 21:05:39.531005+00	402	ESP-3 - 2015-05-08 00:00:00-04:00	1	new through import_export	50	1
2149	2019-01-18 21:05:39.5372+00	403	ESP-3 - 2015-05-09 00:00:00-04:00	1	new through import_export	50	1
2150	2019-01-18 21:05:39.542942+00	404	ESP-3 - 2015-05-10 00:00:00-04:00	1	new through import_export	50	1
2151	2019-01-18 21:05:39.549124+00	405	ESP-3 - 2015-05-11 00:00:00-04:00	1	new through import_export	50	1
2152	2019-01-18 21:05:39.554897+00	406	ESP-3 - 2015-05-12 00:00:00-04:00	1	new through import_export	50	1
2153	2019-01-18 21:05:39.561456+00	407	ESP-3 - 2015-05-13 00:00:00-04:00	1	new through import_export	50	1
2154	2019-01-18 21:05:39.567411+00	408	ESP-3 - 2015-05-14 00:00:00-04:00	1	new through import_export	50	1
2155	2019-01-18 21:05:39.573043+00	409	ESP-3 - 2015-05-15 00:00:00-04:00	1	new through import_export	50	1
2156	2019-01-18 21:05:39.578875+00	410	ESP-3 - 2015-05-17 00:00:00-04:00	1	new through import_export	50	1
2157	2019-01-18 21:05:39.584393+00	411	ESP-3 - 2015-05-18 00:00:00-04:00	1	new through import_export	50	1
2158	2019-01-18 21:05:39.590079+00	412	ESP-3 - 2015-05-19 00:00:00-04:00	1	new through import_export	50	1
2159	2019-01-18 21:05:39.596323+00	413	ESP-3 - 2015-05-20 00:00:00-04:00	1	new through import_export	50	1
2160	2019-01-18 21:05:39.603079+00	414	ESP-3 - 2015-05-21 00:00:00-04:00	1	new through import_export	50	1
2161	2019-01-18 21:05:39.608996+00	415	ESP-3 - 2015-05-22 00:00:00-04:00	1	new through import_export	50	1
2162	2019-01-18 21:05:39.614874+00	416	ESP-3 - 2015-05-24 00:00:00-04:00	1	new through import_export	50	1
2163	2019-01-18 21:05:39.620945+00	417	ESP-3 - 2015-05-25 00:00:00-04:00	1	new through import_export	50	1
2164	2019-01-18 21:05:39.627385+00	418	ESP-3 - 2015-05-26 00:00:00-04:00	1	new through import_export	50	1
2165	2019-01-18 21:05:39.633155+00	419	ESP-3 - 2015-05-27 00:00:00-04:00	1	new through import_export	50	1
2166	2019-01-18 21:05:39.638932+00	420	ESP-3 - 2015-05-28 00:00:00-04:00	1	new through import_export	50	1
2167	2019-01-18 21:05:39.644556+00	421	ESP-3 - 2015-05-29 00:00:00-04:00	1	new through import_export	50	1
2168	2019-01-18 21:05:39.650926+00	422	ESP-3 - 2015-05-31 00:00:00-04:00	1	new through import_export	50	1
2169	2019-01-18 21:05:39.657158+00	423	ESP-3 - 2015-06-01 00:00:00-04:00	1	new through import_export	50	1
2170	2019-01-18 21:05:39.66312+00	424	ESP-3 - 2015-06-02 00:00:00-04:00	1	new through import_export	50	1
2171	2019-01-18 21:05:39.668951+00	425	ESP-3 - 2015-06-03 00:00:00-04:00	1	new through import_export	50	1
2172	2019-01-18 21:05:39.675735+00	426	ESP-3 - 2015-06-04 00:00:00-04:00	1	new through import_export	50	1
2173	2019-01-18 21:05:39.685711+00	427	ESP-3 - 2015-06-05 00:00:00-04:00	1	new through import_export	50	1
2174	2019-01-18 21:05:39.691857+00	428	ESP-3 - 2015-06-07 00:00:00-04:00	1	new through import_export	50	1
2175	2019-01-18 21:05:39.69806+00	429	ESP-3 - 2015-06-08 00:00:00-04:00	1	new through import_export	50	1
2176	2019-01-18 21:05:39.704087+00	430	ESP-3 - 2015-06-09 00:00:00-04:00	1	new through import_export	50	1
2177	2019-01-18 21:05:39.712178+00	431	ESP-3 - 2015-06-10 00:00:00-04:00	1	new through import_export	50	1
2178	2019-01-18 21:05:39.719996+00	432	ESP-3 - 2015-06-11 00:00:00-04:00	1	new through import_export	50	1
2179	2019-01-18 21:05:39.726178+00	433	ESP-3 - 2015-06-12 00:00:00-04:00	1	new through import_export	50	1
2180	2019-01-18 21:05:39.732739+00	434	ESP-3 - 2015-06-14 00:00:00-04:00	1	new through import_export	50	1
2181	2019-01-18 21:05:39.738572+00	435	ESP-3 - 2015-06-15 00:00:00-04:00	1	new through import_export	50	1
2182	2019-01-18 21:05:39.74464+00	436	ESP-3 - 2015-06-16 00:00:00-04:00	1	new through import_export	50	1
2183	2019-01-18 21:05:39.751295+00	437	ESP-3 - 2015-06-17 00:00:00-04:00	1	new through import_export	50	1
2184	2019-01-18 21:05:39.757262+00	438	ESP-3 - 2015-06-18 00:00:00-04:00	1	new through import_export	50	1
2185	2019-01-18 21:05:39.763261+00	439	ESP-3 - 2015-06-19 00:00:00-04:00	1	new through import_export	50	1
2186	2019-01-18 21:05:39.769127+00	440	ESP-3 - 2015-06-20 00:00:00-04:00	1	new through import_export	50	1
2187	2019-01-18 21:05:39.774718+00	441	ESP-3 - 2015-06-21 00:00:00-04:00	1	new through import_export	50	1
2188	2019-01-18 21:05:39.7804+00	442	ESP-3 - 2015-06-22 00:00:00-04:00	1	new through import_export	50	1
2189	2019-01-18 21:05:39.787043+00	443	ESP-3 - 2015-06-23 00:00:00-04:00	1	new through import_export	50	1
2190	2019-01-18 21:05:39.79481+00	444	ESP-3 - 2015-06-24 00:00:00-04:00	1	new through import_export	50	1
2191	2019-01-18 21:05:39.801912+00	445	ESP-3 - 2015-06-25 00:00:00-04:00	1	new through import_export	50	1
2192	2019-01-18 21:05:39.808801+00	446	ESP-3 - 2015-06-26 00:00:00-04:00	1	new through import_export	50	1
2193	2019-01-18 21:05:39.814969+00	447	ESP-3 - 2015-06-27 00:00:00-04:00	1	new through import_export	50	1
2194	2019-01-18 21:05:39.821101+00	448	ESP-3 - 2015-06-28 00:00:00-04:00	1	new through import_export	50	1
2195	2019-01-18 21:05:39.827037+00	449	ESP-3 - 2015-06-29 00:00:00-04:00	1	new through import_export	50	1
2196	2019-01-18 21:05:39.833456+00	450	ESP-3 - 2015-06-30 00:00:00-04:00	1	new through import_export	50	1
2197	2019-01-18 21:05:39.839428+00	451	ESP-3 - 2015-07-01 00:00:00-04:00	1	new through import_export	50	1
2198	2019-01-18 21:05:39.845409+00	452	ESP-3 - 2015-07-02 00:00:00-04:00	1	new through import_export	50	1
2199	2019-01-18 21:05:39.851166+00	453	ESP-3 - 2015-07-05 00:00:00-04:00	1	new through import_export	50	1
2200	2019-01-18 21:05:39.85671+00	454	ESP-3 - 2015-07-06 00:00:00-04:00	1	new through import_export	50	1
2201	2019-01-18 21:05:39.862344+00	455	ESP-3 - 2015-07-07 00:00:00-04:00	1	new through import_export	50	1
2202	2019-01-18 21:05:39.868515+00	456	ESP-3 - 2015-07-08 00:00:00-04:00	1	new through import_export	50	1
2203	2019-01-18 21:05:39.874667+00	457	ESP-3 - 2015-07-09 00:00:00-04:00	1	new through import_export	50	1
2204	2019-01-18 21:05:39.884148+00	458	ESP-3 - 2015-07-10 00:00:00-04:00	1	new through import_export	50	1
2205	2019-01-18 21:05:39.890945+00	459	ESP-3 - 2015-07-11 00:00:00-04:00	1	new through import_export	50	1
2206	2019-01-18 21:05:39.897922+00	460	ESP-3 - 2015-07-13 00:00:00-04:00	1	new through import_export	50	1
2207	2019-01-18 21:05:39.905723+00	461	ESP-3 - 2015-07-14 00:00:00-04:00	1	new through import_export	50	1
2208	2019-01-18 21:05:39.913696+00	462	ESP-3 - 2015-07-15 00:00:00-04:00	1	new through import_export	50	1
2209	2019-01-18 21:05:39.920741+00	463	ESP-3 - 2015-07-16 00:00:00-04:00	1	new through import_export	50	1
2210	2019-01-18 21:05:39.927666+00	464	ESP-3 - 2015-07-17 00:00:00-04:00	1	new through import_export	50	1
2211	2019-01-18 21:05:39.933751+00	465	ESP-3 - 2015-07-18 00:00:00-04:00	1	new through import_export	50	1
2212	2019-01-18 21:05:39.939837+00	466	ESP-3 - 2015-07-19 00:00:00-04:00	1	new through import_export	50	1
2213	2019-01-18 21:05:39.946281+00	467	ESP-3 - 2015-07-20 00:00:00-04:00	1	new through import_export	50	1
2214	2019-01-18 21:05:39.952407+00	468	ESP-3 - 2015-07-21 00:00:00-04:00	1	new through import_export	50	1
2215	2019-01-18 21:05:39.959223+00	469	ESP-3 - 2015-07-22 00:00:00-04:00	1	new through import_export	50	1
2216	2019-01-18 21:05:39.965623+00	470	ESP-3 - 2015-07-23 00:00:00-04:00	1	new through import_export	50	1
2217	2019-01-18 21:05:39.971393+00	471	ESP-3 - 2015-07-24 00:00:00-04:00	1	new through import_export	50	1
2218	2019-01-18 21:05:39.977346+00	472	ESP-3 - 2015-07-25 00:00:00-04:00	1	new through import_export	50	1
2219	2019-01-18 21:05:39.983035+00	473	ESP-3 - 2015-07-26 00:00:00-04:00	1	new through import_export	50	1
2220	2019-01-18 21:05:39.988959+00	474	ESP-3 - 2015-07-27 00:00:00-04:00	1	new through import_export	50	1
2221	2019-01-18 21:05:39.995228+00	475	ESP-3 - 2015-07-28 00:00:00-04:00	1	new through import_export	50	1
2222	2019-01-18 21:05:40.00169+00	476	ESP-3 - 2015-07-29 00:00:00-04:00	1	new through import_export	50	1
2223	2019-01-18 21:05:40.008018+00	477	ESP-3 - 2015-07-30 00:00:00-04:00	1	new through import_export	50	1
2224	2019-01-18 21:05:40.015258+00	478	ESP-3 - 2015-07-31 00:00:00-04:00	1	new through import_export	50	1
2225	2019-01-18 21:05:40.021765+00	479	ESP-3 - 2015-08-02 00:00:00-04:00	1	new through import_export	50	1
2226	2019-01-18 21:05:40.028515+00	480	ESP-3 - 2015-08-03 00:00:00-04:00	1	new through import_export	50	1
2227	2019-01-18 21:05:40.034275+00	481	ESP-3 - 2015-08-04 00:00:00-04:00	1	new through import_export	50	1
2228	2019-01-18 21:05:40.053171+00	482	ESP-3 - 2015-08-05 00:00:00-04:00	1	new through import_export	50	1
2229	2019-01-18 21:05:40.059397+00	483	ESP-3 - 2015-08-10 00:00:00-04:00	1	new through import_export	50	1
2230	2019-01-18 21:05:40.084299+00	484	ESP-3 - 2015-08-11 00:00:00-04:00	1	new through import_export	50	1
2231	2019-01-18 21:05:40.09093+00	485	ESP-3 - 2015-08-12 00:00:00-04:00	1	new through import_export	50	1
2232	2019-01-18 21:05:40.12856+00	486	ESP-3 - 2015-08-16 00:00:00-04:00	1	new through import_export	50	1
2233	2019-01-18 21:05:40.134847+00	487	ESP-3 - 2015-08-17 00:00:00-04:00	1	new through import_export	50	1
2234	2019-01-18 21:05:40.140703+00	488	ESP-3 - 2015-08-18 00:00:00-04:00	1	new through import_export	50	1
2235	2019-01-18 21:05:40.146273+00	489	ESP-3 - 2015-08-19 00:00:00-04:00	1	new through import_export	50	1
2236	2019-01-18 21:05:40.152336+00	490	ESP-3 - 2015-08-23 00:00:00-04:00	1	new through import_export	50	1
2237	2019-01-18 21:05:40.158136+00	491	ESP-3 - 2015-08-24 00:00:00-04:00	1	new through import_export	50	1
2238	2019-01-18 21:05:40.164045+00	492	ESP-3 - 2015-08-25 00:00:00-04:00	1	new through import_export	50	1
2239	2019-01-18 21:05:40.170352+00	493	ESP-3 - 2015-08-26 00:00:00-04:00	1	new through import_export	50	1
2240	2019-01-18 21:05:40.176417+00	494	ESP-3 - 2015-08-27 00:00:00-04:00	1	new through import_export	50	1
2241	2019-01-18 21:05:40.182337+00	495	ESP-3 - 2015-08-31 00:00:00-04:00	1	new through import_export	50	1
2242	2019-01-18 21:05:40.188353+00	496	ESP-3 - 2015-09-01 00:00:00-04:00	1	new through import_export	50	1
2243	2019-01-18 21:05:40.193922+00	497	ESP-3 - 2015-09-02 00:00:00-04:00	1	new through import_export	50	1
2244	2019-01-18 21:05:40.200213+00	498	ESP-3 - 2015-09-03 00:00:00-04:00	1	new through import_export	50	1
2245	2019-01-18 21:05:40.206245+00	499	ESP-3 - 2015-09-06 00:00:00-04:00	1	new through import_export	50	1
2246	2019-01-18 21:05:40.213845+00	500	ESP-3 - 2015-09-07 00:00:00-04:00	1	new through import_export	50	1
2247	2019-01-18 21:05:40.219865+00	501	ESP-3 - 2015-09-08 00:00:00-04:00	1	new through import_export	50	1
2248	2019-01-18 21:05:40.225453+00	502	ESP-3 - 2015-09-09 00:00:00-04:00	1	new through import_export	50	1
2249	2019-01-18 21:07:08.59252+00	619	ESP-1 - 2015-04-07 00:00:00-04:00	1	new through import_export	50	1
2250	2019-01-18 21:07:08.59923+00	620	ESP-1 - 2015-04-13 00:00:00-04:00	1	new through import_export	50	1
2251	2019-01-18 21:07:08.605553+00	621	ESP-1 - 2015-04-14 00:00:00-04:00	1	new through import_export	50	1
2252	2019-01-18 21:07:08.612049+00	622	ESP-1 - 2015-04-15 00:00:00-04:00	1	new through import_export	50	1
2253	2019-01-18 21:07:08.618433+00	623	ESP-1 - 2015-04-20 00:00:00-04:00	1	new through import_export	50	1
2254	2019-01-18 21:07:08.624675+00	624	ESP-1 - 2015-04-21 00:00:00-04:00	1	new through import_export	50	1
2255	2019-01-18 21:07:08.630564+00	625	ESP-1 - 2015-04-22 00:00:00-04:00	1	new through import_export	50	1
2256	2019-01-18 21:07:08.637065+00	626	ESP-1 - 2015-04-26 00:00:00-04:00	1	new through import_export	50	1
2257	2019-01-18 21:07:08.643273+00	627	ESP-1 - 2015-04-27 00:00:00-04:00	1	new through import_export	50	1
2258	2019-01-18 21:07:08.649839+00	628	ESP-1 - 2015-04-29 00:00:00-04:00	1	new through import_export	50	1
2259	2019-01-18 21:07:08.656562+00	629	ESP-1 - 2015-05-03 00:00:00-04:00	1	new through import_export	50	1
2260	2019-01-18 21:07:08.663154+00	630	ESP-1 - 2015-05-04 00:00:00-04:00	1	new through import_export	50	1
2261	2019-01-18 21:07:08.669755+00	631	ESP-1 - 2015-05-05 00:00:00-04:00	1	new through import_export	50	1
2262	2019-01-18 21:07:08.675583+00	632	ESP-1 - 2015-05-06 00:00:00-04:00	1	new through import_export	50	1
2263	2019-01-18 21:07:08.682761+00	633	ESP-1 - 2015-05-07 00:00:00-04:00	1	new through import_export	50	1
2264	2019-01-18 21:07:08.690098+00	634	ESP-1 - 2015-05-08 00:00:00-04:00	1	new through import_export	50	1
2265	2019-01-18 21:07:08.696542+00	635	ESP-1 - 2015-05-09 00:00:00-04:00	1	new through import_export	50	1
2266	2019-01-18 21:07:08.702826+00	636	ESP-1 - 2015-05-10 00:00:00-04:00	1	new through import_export	50	1
2267	2019-01-18 21:07:08.708806+00	637	ESP-1 - 2015-05-11 00:00:00-04:00	1	new through import_export	50	1
2268	2019-01-18 21:07:08.715192+00	638	ESP-1 - 2015-05-12 00:00:00-04:00	1	new through import_export	50	1
2269	2019-01-18 21:07:08.721136+00	639	ESP-1 - 2015-05-13 00:00:00-04:00	1	new through import_export	50	1
2270	2019-01-18 21:07:08.727982+00	640	ESP-1 - 2015-05-14 00:00:00-04:00	1	new through import_export	50	1
2271	2019-01-18 21:07:08.734125+00	641	ESP-1 - 2015-05-15 00:00:00-04:00	1	new through import_export	50	1
2272	2019-01-18 21:07:08.740353+00	642	ESP-1 - 2015-05-17 00:00:00-04:00	1	new through import_export	50	1
2273	2019-01-18 21:07:08.746467+00	643	ESP-1 - 2015-05-18 00:00:00-04:00	1	new through import_export	50	1
2274	2019-01-18 21:07:08.753088+00	644	ESP-1 - 2015-05-19 00:00:00-04:00	1	new through import_export	50	1
2275	2019-01-18 21:07:08.759237+00	645	ESP-1 - 2015-05-20 00:00:00-04:00	1	new through import_export	50	1
2276	2019-01-18 21:07:08.766862+00	646	ESP-1 - 2015-05-21 00:00:00-04:00	1	new through import_export	50	1
2277	2019-01-18 21:07:08.777088+00	647	ESP-1 - 2015-05-22 00:00:00-04:00	1	new through import_export	50	1
2278	2019-01-18 21:07:08.78446+00	648	ESP-1 - 2015-05-24 00:00:00-04:00	1	new through import_export	50	1
2279	2019-01-18 21:07:08.79109+00	649	ESP-1 - 2015-05-25 00:00:00-04:00	1	new through import_export	50	1
2280	2019-01-18 21:07:08.797219+00	650	ESP-1 - 2015-05-26 00:00:00-04:00	1	new through import_export	50	1
2281	2019-01-18 21:07:08.803983+00	651	ESP-1 - 2015-05-27 00:00:00-04:00	1	new through import_export	50	1
2282	2019-01-18 21:07:08.813544+00	652	ESP-1 - 2015-05-28 00:00:00-04:00	1	new through import_export	50	1
2283	2019-01-18 21:07:08.822066+00	653	ESP-1 - 2015-05-29 00:00:00-04:00	1	new through import_export	50	1
2284	2019-01-18 21:07:08.829025+00	654	ESP-1 - 2015-05-31 00:00:00-04:00	1	new through import_export	50	1
2285	2019-01-18 21:07:08.836159+00	655	ESP-1 - 2015-06-01 00:00:00-04:00	1	new through import_export	50	1
2286	2019-01-18 21:07:08.842219+00	656	ESP-1 - 2015-06-02 00:00:00-04:00	1	new through import_export	50	1
2287	2019-01-18 21:07:08.848509+00	657	ESP-1 - 2015-06-03 00:00:00-04:00	1	new through import_export	50	1
2288	2019-01-18 21:07:08.855435+00	658	ESP-1 - 2015-06-04 00:00:00-04:00	1	new through import_export	50	1
2289	2019-01-18 21:07:08.863873+00	659	ESP-1 - 2015-06-05 00:00:00-04:00	1	new through import_export	50	1
2290	2019-01-18 21:07:08.871765+00	660	ESP-1 - 2015-06-07 00:00:00-04:00	1	new through import_export	50	1
2291	2019-01-18 21:07:08.878485+00	661	ESP-1 - 2015-06-08 00:00:00-04:00	1	new through import_export	50	1
2292	2019-01-18 21:07:08.885429+00	662	ESP-1 - 2015-06-09 00:00:00-04:00	1	new through import_export	50	1
2293	2019-01-18 21:07:08.891877+00	663	ESP-1 - 2015-06-10 00:00:00-04:00	1	new through import_export	50	1
2294	2019-01-18 21:07:08.898431+00	664	ESP-1 - 2015-06-11 00:00:00-04:00	1	new through import_export	50	1
2295	2019-01-18 21:07:08.904417+00	665	ESP-1 - 2015-06-12 00:00:00-04:00	1	new through import_export	50	1
2296	2019-01-18 21:07:08.911183+00	666	ESP-1 - 2015-06-14 00:00:00-04:00	1	new through import_export	50	1
2297	2019-01-18 21:07:08.917982+00	667	ESP-1 - 2015-06-15 00:00:00-04:00	1	new through import_export	50	1
2298	2019-01-18 21:07:08.924926+00	668	ESP-1 - 2015-06-16 00:00:00-04:00	1	new through import_export	50	1
2299	2019-01-18 21:07:08.931677+00	669	ESP-1 - 2015-06-17 00:00:00-04:00	1	new through import_export	50	1
2300	2019-01-18 21:07:08.938227+00	670	ESP-1 - 2015-06-18 00:00:00-04:00	1	new through import_export	50	1
2301	2019-01-18 21:07:08.944099+00	671	ESP-1 - 2015-06-19 00:00:00-04:00	1	new through import_export	50	1
2302	2019-01-18 21:07:08.951424+00	672	ESP-1 - 2015-06-20 00:00:00-04:00	1	new through import_export	50	1
2303	2019-01-18 21:07:08.958775+00	673	ESP-1 - 2015-06-21 00:00:00-04:00	1	new through import_export	50	1
2304	2019-01-18 21:07:08.967352+00	674	ESP-1 - 2015-06-22 00:00:00-04:00	1	new through import_export	50	1
2305	2019-01-18 21:07:08.974397+00	675	ESP-1 - 2015-06-23 00:00:00-04:00	1	new through import_export	50	1
2306	2019-01-18 21:07:08.982163+00	676	ESP-1 - 2015-06-24 00:00:00-04:00	1	new through import_export	50	1
2307	2019-01-18 21:07:08.989414+00	677	ESP-1 - 2015-06-25 00:00:00-04:00	1	new through import_export	50	1
2308	2019-01-18 21:07:08.995795+00	678	ESP-1 - 2015-06-26 00:00:00-04:00	1	new through import_export	50	1
2309	2019-01-18 21:07:09.003014+00	679	ESP-1 - 2015-06-27 00:00:00-04:00	1	new through import_export	50	1
2310	2019-01-18 21:07:09.010551+00	680	ESP-1 - 2015-06-28 00:00:00-04:00	1	new through import_export	50	1
2311	2019-01-18 21:07:09.018438+00	681	ESP-1 - 2015-06-29 00:00:00-04:00	1	new through import_export	50	1
2312	2019-01-18 21:07:09.027596+00	682	ESP-1 - 2015-06-30 00:00:00-04:00	1	new through import_export	50	1
2313	2019-01-18 21:07:09.035922+00	683	ESP-1 - 2015-07-01 00:00:00-04:00	1	new through import_export	50	1
2314	2019-01-18 21:07:09.042424+00	684	ESP-1 - 2015-07-02 00:00:00-04:00	1	new through import_export	50	1
2315	2019-01-18 21:07:09.04857+00	685	ESP-1 - 2015-07-05 00:00:00-04:00	1	new through import_export	50	1
2316	2019-01-18 21:07:09.054821+00	686	ESP-1 - 2015-07-06 00:00:00-04:00	1	new through import_export	50	1
2317	2019-01-18 21:07:09.063098+00	687	ESP-1 - 2015-07-07 00:00:00-04:00	1	new through import_export	50	1
2318	2019-01-18 21:07:09.07+00	688	ESP-1 - 2015-07-08 00:00:00-04:00	1	new through import_export	50	1
2319	2019-01-18 21:07:09.076852+00	689	ESP-1 - 2015-07-09 00:00:00-04:00	1	new through import_export	50	1
2320	2019-01-18 21:07:09.084214+00	690	ESP-1 - 2015-07-10 00:00:00-04:00	1	new through import_export	50	1
2321	2019-01-18 21:07:09.090926+00	691	ESP-1 - 2015-07-11 00:00:00-04:00	1	new through import_export	50	1
2322	2019-01-18 21:07:09.097628+00	692	ESP-1 - 2015-07-13 00:00:00-04:00	1	new through import_export	50	1
2323	2019-01-18 21:07:09.103414+00	693	ESP-1 - 2015-07-14 00:00:00-04:00	1	new through import_export	50	1
2324	2019-01-18 21:07:09.110978+00	694	ESP-1 - 2015-07-15 00:00:00-04:00	1	new through import_export	50	1
2325	2019-01-18 21:07:09.117993+00	695	ESP-1 - 2015-07-16 00:00:00-04:00	1	new through import_export	50	1
2326	2019-01-18 21:07:09.124483+00	696	ESP-1 - 2015-07-17 00:00:00-04:00	1	new through import_export	50	1
2327	2019-01-18 21:07:09.131559+00	697	ESP-1 - 2015-07-18 00:00:00-04:00	1	new through import_export	50	1
2328	2019-01-18 21:07:09.137978+00	698	ESP-1 - 2015-07-19 00:00:00-04:00	1	new through import_export	50	1
2329	2019-01-18 21:07:09.144141+00	699	ESP-1 - 2015-07-20 00:00:00-04:00	1	new through import_export	50	1
2330	2019-01-18 21:07:09.150899+00	700	ESP-1 - 2015-07-21 00:00:00-04:00	1	new through import_export	50	1
2331	2019-01-18 21:07:09.157044+00	701	ESP-1 - 2015-07-22 00:00:00-04:00	1	new through import_export	50	1
2332	2019-01-18 21:07:09.162896+00	702	ESP-1 - 2015-07-23 00:00:00-04:00	1	new through import_export	50	1
2333	2019-01-18 21:07:09.17008+00	703	ESP-1 - 2015-07-24 00:00:00-04:00	1	new through import_export	50	1
2334	2019-01-18 21:07:09.176995+00	704	ESP-1 - 2015-07-25 00:00:00-04:00	1	new through import_export	50	1
2335	2019-01-18 21:07:09.185416+00	705	ESP-1 - 2015-07-26 00:00:00-04:00	1	new through import_export	50	1
2336	2019-01-18 21:07:09.19156+00	706	ESP-1 - 2015-07-27 00:00:00-04:00	1	new through import_export	50	1
2337	2019-01-18 21:07:09.198173+00	707	ESP-1 - 2015-07-28 00:00:00-04:00	1	new through import_export	50	1
2338	2019-01-18 21:07:09.20479+00	708	ESP-1 - 2015-07-29 00:00:00-04:00	1	new through import_export	50	1
2339	2019-01-18 21:07:09.221741+00	709	ESP-1 - 2015-07-30 00:00:00-04:00	1	new through import_export	50	1
2340	2019-01-18 21:07:09.234088+00	710	ESP-1 - 2015-07-31 00:00:00-04:00	1	new through import_export	50	1
2341	2019-01-18 21:07:09.252054+00	711	ESP-1 - 2015-08-02 00:00:00-04:00	1	new through import_export	50	1
2342	2019-01-18 21:07:09.287938+00	712	ESP-1 - 2015-08-03 00:00:00-04:00	1	new through import_export	50	1
2343	2019-01-18 21:07:09.30856+00	713	ESP-1 - 2015-08-04 00:00:00-04:00	1	new through import_export	50	1
2344	2019-01-18 21:07:09.315262+00	714	ESP-1 - 2015-08-05 00:00:00-04:00	1	new through import_export	50	1
2345	2019-01-18 21:07:09.321815+00	715	ESP-1 - 2015-08-10 00:00:00-04:00	1	new through import_export	50	1
2346	2019-01-18 21:07:09.328174+00	716	ESP-1 - 2015-08-11 00:00:00-04:00	1	new through import_export	50	1
2347	2019-01-18 21:07:09.335074+00	717	ESP-1 - 2015-08-12 00:00:00-04:00	1	new through import_export	50	1
2348	2019-01-18 21:07:09.341431+00	718	ESP-1 - 2015-08-16 00:00:00-04:00	1	new through import_export	50	1
2349	2019-01-18 21:07:09.347378+00	719	ESP-1 - 2015-08-17 00:00:00-04:00	1	new through import_export	50	1
2350	2019-01-18 21:07:09.35397+00	720	ESP-1 - 2015-08-18 00:00:00-04:00	1	new through import_export	50	1
2351	2019-01-18 21:07:09.361072+00	721	ESP-1 - 2015-08-19 00:00:00-04:00	1	new through import_export	50	1
2352	2019-01-18 21:07:09.368644+00	722	ESP-1 - 2015-08-23 00:00:00-04:00	1	new through import_export	50	1
2353	2019-01-18 21:07:09.375391+00	723	ESP-1 - 2015-08-24 00:00:00-04:00	1	new through import_export	50	1
2354	2019-01-18 21:07:09.381991+00	724	ESP-1 - 2015-08-25 00:00:00-04:00	1	new through import_export	50	1
2355	2019-01-18 21:07:09.389918+00	725	ESP-1 - 2015-08-26 00:00:00-04:00	1	new through import_export	50	1
2356	2019-01-18 21:07:09.396661+00	726	ESP-1 - 2015-08-27 00:00:00-04:00	1	new through import_export	50	1
2357	2019-01-18 21:07:09.402668+00	727	ESP-1 - 2015-08-31 00:00:00-04:00	1	new through import_export	50	1
2358	2019-01-18 21:07:09.411219+00	728	ESP-1 - 2015-09-01 00:00:00-04:00	1	new through import_export	50	1
2359	2019-01-18 21:07:09.419601+00	729	ESP-1 - 2015-09-02 00:00:00-04:00	1	new through import_export	50	1
2360	2019-01-18 21:07:09.426491+00	730	ESP-1 - 2015-09-03 00:00:00-04:00	1	new through import_export	50	1
2361	2019-01-18 21:07:09.433883+00	731	ESP-1 - 2015-09-06 00:00:00-04:00	1	new through import_export	50	1
2362	2019-01-18 21:07:09.440187+00	732	ESP-1 - 2015-09-07 00:00:00-04:00	1	new through import_export	50	1
2363	2019-01-18 21:07:09.446256+00	733	ESP-1 - 2015-09-08 00:00:00-04:00	1	new through import_export	50	1
2364	2019-01-18 21:07:09.453188+00	734	ESP-1 - 2015-09-09 00:00:00-04:00	1	new through import_export	50	1
2365	2019-01-18 21:10:15.857872+00	851	ESP-2 - 2015-04-07 00:00:00-04:00	1	new through import_export	50	1
2366	2019-01-18 21:10:15.865439+00	852	ESP-2 - 2015-04-13 00:00:00-04:00	1	new through import_export	50	1
2367	2019-01-18 21:10:15.872192+00	853	ESP-2 - 2015-04-14 00:00:00-04:00	1	new through import_export	50	1
2368	2019-01-18 21:10:15.879224+00	854	ESP-2 - 2015-04-15 00:00:00-04:00	1	new through import_export	50	1
2369	2019-01-18 21:10:15.886327+00	855	ESP-2 - 2015-04-20 00:00:00-04:00	1	new through import_export	50	1
2370	2019-01-18 21:10:15.892516+00	856	ESP-2 - 2015-04-21 00:00:00-04:00	1	new through import_export	50	1
2371	2019-01-18 21:10:15.898599+00	857	ESP-2 - 2015-04-22 00:00:00-04:00	1	new through import_export	50	1
2372	2019-01-18 21:10:15.90495+00	858	ESP-2 - 2015-04-26 00:00:00-04:00	1	new through import_export	50	1
2373	2019-01-18 21:10:15.912091+00	859	ESP-2 - 2015-04-27 00:00:00-04:00	1	new through import_export	50	1
2374	2019-01-18 21:10:15.918242+00	860	ESP-2 - 2015-04-29 00:00:00-04:00	1	new through import_export	50	1
2375	2019-01-18 21:10:15.924219+00	861	ESP-2 - 2015-05-03 00:00:00-04:00	1	new through import_export	50	1
2376	2019-01-18 21:10:15.930179+00	862	ESP-2 - 2015-05-04 00:00:00-04:00	1	new through import_export	50	1
2377	2019-01-18 21:10:15.936377+00	863	ESP-2 - 2015-05-05 00:00:00-04:00	1	new through import_export	50	1
2378	2019-01-18 21:10:15.942792+00	864	ESP-2 - 2015-05-06 00:00:00-04:00	1	new through import_export	50	1
2379	2019-01-18 21:10:15.948872+00	865	ESP-2 - 2015-05-07 00:00:00-04:00	1	new through import_export	50	1
2380	2019-01-18 21:10:15.954906+00	866	ESP-2 - 2015-05-08 00:00:00-04:00	1	new through import_export	50	1
2381	2019-01-18 21:10:15.960978+00	867	ESP-2 - 2015-05-09 00:00:00-04:00	1	new through import_export	50	1
2382	2019-01-18 21:10:15.967109+00	868	ESP-2 - 2015-05-10 00:00:00-04:00	1	new through import_export	50	1
2383	2019-01-18 21:10:15.973185+00	869	ESP-2 - 2015-05-11 00:00:00-04:00	1	new through import_export	50	1
2384	2019-01-18 21:10:15.979289+00	870	ESP-2 - 2015-05-12 00:00:00-04:00	1	new through import_export	50	1
2385	2019-01-18 21:10:15.985251+00	871	ESP-2 - 2015-05-13 00:00:00-04:00	1	new through import_export	50	1
2386	2019-01-18 21:10:15.99117+00	872	ESP-2 - 2015-05-14 00:00:00-04:00	1	new through import_export	50	1
2387	2019-01-18 21:10:15.997715+00	873	ESP-2 - 2015-05-15 00:00:00-04:00	1	new through import_export	50	1
2388	2019-01-18 21:10:16.004914+00	874	ESP-2 - 2015-05-17 00:00:00-04:00	1	new through import_export	50	1
2389	2019-01-18 21:10:16.014781+00	875	ESP-2 - 2015-05-18 00:00:00-04:00	1	new through import_export	50	1
2390	2019-01-18 21:10:16.021673+00	876	ESP-2 - 2015-05-19 00:00:00-04:00	1	new through import_export	50	1
2391	2019-01-18 21:10:16.02869+00	877	ESP-2 - 2015-05-20 00:00:00-04:00	1	new through import_export	50	1
2392	2019-01-18 21:10:16.03784+00	878	ESP-2 - 2015-05-21 00:00:00-04:00	1	new through import_export	50	1
2393	2019-01-18 21:10:16.045229+00	879	ESP-2 - 2015-05-22 00:00:00-04:00	1	new through import_export	50	1
2394	2019-01-18 21:10:16.051624+00	880	ESP-2 - 2015-05-24 00:00:00-04:00	1	new through import_export	50	1
2395	2019-01-18 21:10:16.059218+00	881	ESP-2 - 2015-05-25 00:00:00-04:00	1	new through import_export	50	1
2396	2019-01-18 21:10:16.066499+00	882	ESP-2 - 2015-05-26 00:00:00-04:00	1	new through import_export	50	1
2397	2019-01-18 21:10:16.07408+00	883	ESP-2 - 2015-05-27 00:00:00-04:00	1	new through import_export	50	1
2398	2019-01-18 21:10:16.081352+00	884	ESP-2 - 2015-05-28 00:00:00-04:00	1	new through import_export	50	1
2399	2019-01-18 21:10:16.087759+00	885	ESP-2 - 2015-05-29 00:00:00-04:00	1	new through import_export	50	1
2400	2019-01-18 21:10:16.094079+00	886	ESP-2 - 2015-05-31 00:00:00-04:00	1	new through import_export	50	1
2401	2019-01-18 21:10:16.100386+00	887	ESP-2 - 2015-06-01 00:00:00-04:00	1	new through import_export	50	1
2402	2019-01-18 21:10:16.107469+00	888	ESP-2 - 2015-06-02 00:00:00-04:00	1	new through import_export	50	1
2403	2019-01-18 21:10:16.114821+00	889	ESP-2 - 2015-06-03 00:00:00-04:00	1	new through import_export	50	1
2404	2019-01-18 21:10:16.121478+00	890	ESP-2 - 2015-06-04 00:00:00-04:00	1	new through import_export	50	1
2405	2019-01-18 21:10:16.128433+00	891	ESP-2 - 2015-06-05 00:00:00-04:00	1	new through import_export	50	1
2406	2019-01-18 21:10:16.134974+00	892	ESP-2 - 2015-06-07 00:00:00-04:00	1	new through import_export	50	1
2407	2019-01-18 21:10:16.141515+00	893	ESP-2 - 2015-06-08 00:00:00-04:00	1	new through import_export	50	1
2408	2019-01-18 21:10:16.14805+00	894	ESP-2 - 2015-06-09 00:00:00-04:00	1	new through import_export	50	1
2409	2019-01-18 21:10:16.154353+00	895	ESP-2 - 2015-06-10 00:00:00-04:00	1	new through import_export	50	1
2410	2019-01-18 21:10:16.160913+00	896	ESP-2 - 2015-06-11 00:00:00-04:00	1	new through import_export	50	1
2411	2019-01-18 21:10:16.167473+00	897	ESP-2 - 2015-06-12 00:00:00-04:00	1	new through import_export	50	1
2412	2019-01-18 21:10:16.173531+00	898	ESP-2 - 2015-06-14 00:00:00-04:00	1	new through import_export	50	1
2413	2019-01-18 21:10:16.17954+00	899	ESP-2 - 2015-06-15 00:00:00-04:00	1	new through import_export	50	1
2414	2019-01-18 21:10:16.185881+00	900	ESP-2 - 2015-06-16 00:00:00-04:00	1	new through import_export	50	1
2415	2019-01-18 21:10:16.19182+00	901	ESP-2 - 2015-06-17 00:00:00-04:00	1	new through import_export	50	1
2416	2019-01-18 21:10:16.198595+00	902	ESP-2 - 2015-06-18 00:00:00-04:00	1	new through import_export	50	1
2417	2019-01-18 21:10:16.206285+00	903	ESP-2 - 2015-06-19 00:00:00-04:00	1	new through import_export	50	1
2418	2019-01-18 21:10:16.214158+00	904	ESP-2 - 2015-06-20 00:00:00-04:00	1	new through import_export	50	1
2419	2019-01-18 21:10:16.221377+00	905	ESP-2 - 2015-06-21 00:00:00-04:00	1	new through import_export	50	1
2420	2019-01-18 21:10:16.228476+00	906	ESP-2 - 2015-06-22 00:00:00-04:00	1	new through import_export	50	1
2421	2019-01-18 21:10:16.235829+00	907	ESP-2 - 2015-06-23 00:00:00-04:00	1	new through import_export	50	1
2422	2019-01-18 21:10:16.243037+00	908	ESP-2 - 2015-06-24 00:00:00-04:00	1	new through import_export	50	1
2423	2019-01-18 21:10:16.249733+00	909	ESP-2 - 2015-06-25 00:00:00-04:00	1	new through import_export	50	1
2424	2019-01-18 21:10:16.256646+00	910	ESP-2 - 2015-06-26 00:00:00-04:00	1	new through import_export	50	1
2425	2019-01-18 21:10:16.263526+00	911	ESP-2 - 2015-06-27 00:00:00-04:00	1	new through import_export	50	1
2426	2019-01-18 21:10:16.270361+00	912	ESP-2 - 2015-06-28 00:00:00-04:00	1	new through import_export	50	1
2427	2019-01-18 21:10:16.277359+00	913	ESP-2 - 2015-06-29 00:00:00-04:00	1	new through import_export	50	1
2428	2019-01-18 21:10:16.283954+00	914	ESP-2 - 2015-06-30 00:00:00-04:00	1	new through import_export	50	1
2429	2019-01-18 21:10:16.290594+00	915	ESP-2 - 2015-07-01 00:00:00-04:00	1	new through import_export	50	1
2430	2019-01-18 21:10:16.29748+00	916	ESP-2 - 2015-07-02 00:00:00-04:00	1	new through import_export	50	1
2431	2019-01-18 21:10:16.303769+00	917	ESP-2 - 2015-07-05 00:00:00-04:00	1	new through import_export	50	1
2432	2019-01-18 21:10:16.310422+00	918	ESP-2 - 2015-07-06 00:00:00-04:00	1	new through import_export	50	1
2433	2019-01-18 21:10:16.316624+00	919	ESP-2 - 2015-07-07 00:00:00-04:00	1	new through import_export	50	1
2434	2019-01-18 21:10:16.322808+00	920	ESP-2 - 2015-07-08 00:00:00-04:00	1	new through import_export	50	1
2435	2019-01-18 21:10:16.328997+00	921	ESP-2 - 2015-07-09 00:00:00-04:00	1	new through import_export	50	1
2436	2019-01-18 21:10:16.335041+00	922	ESP-2 - 2015-07-10 00:00:00-04:00	1	new through import_export	50	1
2437	2019-01-18 21:10:16.341067+00	923	ESP-2 - 2015-07-11 00:00:00-04:00	1	new through import_export	50	1
2438	2019-01-18 21:10:16.347178+00	924	ESP-2 - 2015-07-13 00:00:00-04:00	1	new through import_export	50	1
2439	2019-01-18 21:10:16.353416+00	925	ESP-2 - 2015-07-14 00:00:00-04:00	1	new through import_export	50	1
2440	2019-01-18 21:10:16.359463+00	926	ESP-2 - 2015-07-15 00:00:00-04:00	1	new through import_export	50	1
2441	2019-01-18 21:10:16.365624+00	927	ESP-2 - 2015-07-16 00:00:00-04:00	1	new through import_export	50	1
2442	2019-01-18 21:10:16.371567+00	928	ESP-2 - 2015-07-17 00:00:00-04:00	1	new through import_export	50	1
2443	2019-01-18 21:10:16.3777+00	929	ESP-2 - 2015-07-18 00:00:00-04:00	1	new through import_export	50	1
2444	2019-01-18 21:10:16.383385+00	930	ESP-2 - 2015-07-19 00:00:00-04:00	1	new through import_export	50	1
2445	2019-01-18 21:10:16.389589+00	931	ESP-2 - 2015-07-20 00:00:00-04:00	1	new through import_export	50	1
2446	2019-01-18 21:10:16.396207+00	932	ESP-2 - 2015-07-21 00:00:00-04:00	1	new through import_export	50	1
2447	2019-01-18 21:10:16.411261+00	933	ESP-2 - 2015-07-22 00:00:00-04:00	1	new through import_export	50	1
2448	2019-01-18 21:10:16.421517+00	934	ESP-2 - 2015-07-23 00:00:00-04:00	1	new through import_export	50	1
2449	2019-01-18 21:10:16.45162+00	935	ESP-2 - 2015-07-24 00:00:00-04:00	1	new through import_export	50	1
2450	2019-01-18 21:10:16.489364+00	936	ESP-2 - 2015-07-25 00:00:00-04:00	1	new through import_export	50	1
2451	2019-01-18 21:10:16.495225+00	937	ESP-2 - 2015-07-26 00:00:00-04:00	1	new through import_export	50	1
2452	2019-01-18 21:10:16.501787+00	938	ESP-2 - 2015-07-27 00:00:00-04:00	1	new through import_export	50	1
2453	2019-01-18 21:10:16.508375+00	939	ESP-2 - 2015-07-28 00:00:00-04:00	1	new through import_export	50	1
2454	2019-01-18 21:10:16.516276+00	940	ESP-2 - 2015-07-29 00:00:00-04:00	1	new through import_export	50	1
2455	2019-01-18 21:10:16.522591+00	941	ESP-2 - 2015-07-30 00:00:00-04:00	1	new through import_export	50	1
2456	2019-01-18 21:10:16.528952+00	942	ESP-2 - 2015-07-31 00:00:00-04:00	1	new through import_export	50	1
2457	2019-01-18 21:10:16.535642+00	943	ESP-2 - 2015-08-02 00:00:00-04:00	1	new through import_export	50	1
2458	2019-01-18 21:10:16.541894+00	944	ESP-2 - 2015-08-03 00:00:00-04:00	1	new through import_export	50	1
2459	2019-01-18 21:10:16.548996+00	945	ESP-2 - 2015-08-04 00:00:00-04:00	1	new through import_export	50	1
2460	2019-01-18 21:10:16.555059+00	946	ESP-2 - 2015-08-05 00:00:00-04:00	1	new through import_export	50	1
2461	2019-01-18 21:10:16.561102+00	947	ESP-2 - 2015-08-10 00:00:00-04:00	1	new through import_export	50	1
2462	2019-01-18 21:10:16.567095+00	948	ESP-2 - 2015-08-11 00:00:00-04:00	1	new through import_export	50	1
2463	2019-01-18 21:10:16.572778+00	949	ESP-2 - 2015-08-12 00:00:00-04:00	1	new through import_export	50	1
2464	2019-01-18 21:10:16.57857+00	950	ESP-2 - 2015-08-16 00:00:00-04:00	1	new through import_export	50	1
2465	2019-01-18 21:10:16.584793+00	951	ESP-2 - 2015-08-17 00:00:00-04:00	1	new through import_export	50	1
2466	2019-01-18 21:10:16.593515+00	952	ESP-2 - 2015-08-18 00:00:00-04:00	1	new through import_export	50	1
2467	2019-01-18 21:10:16.599936+00	953	ESP-2 - 2015-08-19 00:00:00-04:00	1	new through import_export	50	1
2468	2019-01-18 21:10:16.607064+00	954	ESP-2 - 2015-08-23 00:00:00-04:00	1	new through import_export	50	1
2469	2019-01-18 21:10:16.615419+00	955	ESP-2 - 2015-08-24 00:00:00-04:00	1	new through import_export	50	1
2470	2019-01-18 21:10:16.623571+00	956	ESP-2 - 2015-08-25 00:00:00-04:00	1	new through import_export	50	1
2471	2019-01-18 21:10:16.631899+00	957	ESP-2 - 2015-08-26 00:00:00-04:00	1	new through import_export	50	1
2472	2019-01-18 21:10:16.638898+00	958	ESP-2 - 2015-08-27 00:00:00-04:00	1	new through import_export	50	1
2473	2019-01-18 21:10:16.645513+00	959	ESP-2 - 2015-08-31 00:00:00-04:00	1	new through import_export	50	1
2474	2019-01-18 21:10:16.652114+00	960	ESP-2 - 2015-09-01 00:00:00-04:00	1	new through import_export	50	1
2475	2019-01-18 21:10:16.660628+00	961	ESP-2 - 2015-09-02 00:00:00-04:00	1	new through import_export	50	1
2476	2019-01-18 21:10:16.669023+00	962	ESP-2 - 2015-09-03 00:00:00-04:00	1	new through import_export	50	1
2477	2019-01-18 21:10:16.675734+00	963	ESP-2 - 2015-09-06 00:00:00-04:00	1	new through import_export	50	1
2478	2019-01-18 21:10:16.682767+00	964	ESP-2 - 2015-09-07 00:00:00-04:00	1	new through import_export	50	1
2479	2019-01-18 21:10:16.689232+00	965	ESP-2 - 2015-09-08 00:00:00-04:00	1	new through import_export	50	1
2480	2019-01-18 21:10:16.698234+00	966	ESP-2 - 2015-09-09 00:00:00-04:00	1	new through import_export	50	1
2481	2019-01-22 15:09:15.232841+00	1019	Bowdoin wetlab - 2016-03-14 00:00:00-04:00	1	new through import_export	50	1
2482	2019-01-22 15:09:15.241171+00	1020	Bowdoin wetlab - 2016-03-15 00:00:00-04:00	1	new through import_export	50	1
2483	2019-01-22 15:09:15.247787+00	1021	Bowdoin wetlab - 2016-03-28 00:00:00-04:00	1	new through import_export	50	1
2484	2019-01-22 15:09:15.254983+00	1022	Bowdoin wetlab - 2016-03-29 00:00:00-04:00	1	new through import_export	50	1
2485	2019-01-22 15:09:15.261854+00	1023	Bowdoin wetlab - 2016-04-11 00:00:00-04:00	1	new through import_export	50	1
2486	2019-01-22 15:09:15.268727+00	1024	Bowdoin wetlab - 2016-04-22 00:00:00-04:00	1	new through import_export	50	1
2487	2019-01-22 15:09:15.275729+00	1025	Bowdoin wetlab - 2016-04-25 00:00:00-04:00	1	new through import_export	50	1
2488	2019-01-22 15:09:15.282947+00	1026	Bowdoin wetlab - 2016-04-26 00:00:00-04:00	1	new through import_export	50	1
2489	2019-01-22 15:09:15.29121+00	1027	Bowdoin wetlab - 2016-04-28 00:00:00-04:00	1	new through import_export	50	1
2490	2019-01-22 15:09:15.299384+00	1028	Bowdoin wetlab - 2016-04-29 00:00:00-04:00	1	new through import_export	50	1
2491	2019-01-22 15:09:15.30747+00	1029	Bowdoin wetlab - 2016-05-02 00:00:00-04:00	1	new through import_export	50	1
2492	2019-01-22 15:09:15.315244+00	1030	Bowdoin wetlab - 2016-05-03 00:00:00-04:00	1	new through import_export	50	1
2493	2019-01-22 15:09:15.325019+00	1031	Bowdoin wetlab - 2016-05-05 00:00:00-04:00	1	new through import_export	50	1
2494	2019-01-22 15:09:15.335701+00	1032	Bowdoin wetlab - 2016-05-06 00:00:00-04:00	1	new through import_export	50	1
2495	2019-01-22 15:09:15.344253+00	1033	Bowdoin wetlab - 2016-05-09 00:00:00-04:00	1	new through import_export	50	1
2496	2019-01-22 15:09:15.352702+00	1034	Bowdoin wetlab - 2016-05-10 00:00:00-04:00	1	new through import_export	50	1
2497	2019-01-22 15:09:15.360666+00	1035	Bowdoin wetlab - 2016-05-11 00:00:00-04:00	1	new through import_export	50	1
2498	2019-01-22 15:09:15.368906+00	1036	Bowdoin wetlab - 2016-05-12 00:00:00-04:00	1	new through import_export	50	1
2499	2019-01-22 15:09:15.376931+00	1037	Bowdoin wetlab - 2016-05-13 00:00:00-04:00	1	new through import_export	50	1
2500	2019-01-22 15:09:15.384942+00	1038	Bowdoin wetlab - 2016-05-16 00:00:00-04:00	1	new through import_export	50	1
2501	2019-01-22 15:09:15.392457+00	1039	Bowdoin wetlab - 2016-05-17 00:00:00-04:00	1	new through import_export	50	1
2502	2019-01-22 15:09:15.399219+00	1040	Bowdoin wetlab - 2016-05-18 00:00:00-04:00	1	new through import_export	50	1
2503	2019-01-22 15:09:15.405909+00	1041	Bowdoin wetlab - 2016-05-19 00:00:00-04:00	1	new through import_export	50	1
2504	2019-01-22 15:09:15.412065+00	1042	Bowdoin wetlab - 2016-05-20 00:00:00-04:00	1	new through import_export	50	1
2505	2019-01-22 15:09:15.418129+00	1043	Bowdoin wetlab - 2016-05-23 00:00:00-04:00	1	new through import_export	50	1
2506	2019-01-22 15:09:15.424542+00	1044	Bowdoin wetlab - 2016-05-24 00:00:00-04:00	1	new through import_export	50	1
2507	2019-01-22 15:09:15.43087+00	1045	Bowdoin wetlab - 2016-05-25 00:00:00-04:00	1	new through import_export	50	1
2508	2019-01-22 15:09:15.437671+00	1046	Bowdoin wetlab - 2016-05-26 00:00:00-04:00	1	new through import_export	50	1
2509	2019-01-22 15:09:15.444737+00	1047	Bowdoin wetlab - 2016-05-27 00:00:00-04:00	1	new through import_export	50	1
2510	2019-01-22 15:09:15.451371+00	1048	Bowdoin wetlab - 2016-05-30 00:00:00-04:00	1	new through import_export	50	1
2511	2019-01-22 15:09:15.458081+00	1049	Bowdoin wetlab - 2016-05-31 00:00:00-04:00	1	new through import_export	50	1
2512	2019-01-22 15:09:15.464335+00	1050	Bowdoin wetlab - 2016-06-01 00:00:00-04:00	1	new through import_export	50	1
2513	2019-01-22 15:09:15.471603+00	1051	Bowdoin wetlab - 2016-06-02 00:00:00-04:00	1	new through import_export	50	1
2514	2019-01-22 15:09:15.477864+00	1052	Bowdoin wetlab - 2016-06-03 00:00:00-04:00	1	new through import_export	50	1
2515	2019-01-22 15:09:15.484323+00	1053	Bowdoin wetlab - 2016-06-06 00:00:00-04:00	1	new through import_export	50	1
2516	2019-01-22 15:09:15.490882+00	1054	Bowdoin wetlab - 2016-06-07 00:00:00-04:00	1	new through import_export	50	1
2517	2019-01-22 15:09:15.497289+00	1055	Bowdoin wetlab - 2016-06-08 00:00:00-04:00	1	new through import_export	50	1
2518	2019-01-22 15:09:15.503406+00	1056	Bowdoin wetlab - 2016-06-09 00:00:00-04:00	1	new through import_export	50	1
2519	2019-01-22 15:09:15.509571+00	1057	Bowdoin wetlab - 2016-06-10 00:00:00-04:00	1	new through import_export	50	1
2520	2019-01-22 15:09:15.516067+00	1058	Bowdoin wetlab - 2016-06-13 00:00:00-04:00	1	new through import_export	50	1
2521	2019-01-22 15:09:15.522421+00	1059	Bowdoin wetlab - 2016-06-14 00:00:00-04:00	1	new through import_export	50	1
2522	2019-01-22 15:09:15.528503+00	1060	Bowdoin wetlab - 2016-06-15 00:00:00-04:00	1	new through import_export	50	1
2523	2019-01-22 15:09:15.535354+00	1061	Bowdoin wetlab - 2016-06-16 00:00:00-04:00	1	new through import_export	50	1
2524	2019-01-22 15:09:15.541542+00	1062	Bowdoin wetlab - 2016-06-17 00:00:00-04:00	1	new through import_export	50	1
2525	2019-01-22 15:09:15.547761+00	1063	Bowdoin wetlab - 2016-06-20 00:00:00-04:00	1	new through import_export	50	1
2526	2019-01-22 15:09:15.554302+00	1064	Bowdoin wetlab - 2016-06-21 00:00:00-04:00	1	new through import_export	50	1
2527	2019-01-22 15:09:15.560701+00	1065	Bowdoin wetlab - 2016-06-22 00:00:00-04:00	1	new through import_export	50	1
2528	2019-01-22 15:09:15.566556+00	1066	Bowdoin wetlab - 2016-06-23 00:00:00-04:00	1	new through import_export	50	1
2529	2019-01-22 15:09:15.572325+00	1067	Bowdoin wetlab - 2016-06-24 00:00:00-04:00	1	new through import_export	50	1
2530	2019-01-22 15:09:15.597004+00	1068	Bowdoin wetlab - 2016-06-27 00:00:00-04:00	1	new through import_export	50	1
2531	2019-01-22 15:09:15.612117+00	1069	Bowdoin wetlab - 2016-07-04 00:00:00-04:00	1	new through import_export	50	1
2532	2019-01-22 15:09:15.63319+00	1070	Bowdoin wetlab - 2016-07-11 00:00:00-04:00	1	new through import_export	50	1
2533	2019-01-22 15:11:13.560661+00	1123	ESP-1 - 2016-03-14 00:00:00-04:00	1	new through import_export	50	1
2534	2019-01-22 15:11:13.566748+00	1124	ESP-1 - 2016-03-15 00:00:00-04:00	1	new through import_export	50	1
2535	2019-01-22 15:11:13.572759+00	1125	ESP-1 - 2016-03-28 00:00:00-04:00	1	new through import_export	50	1
2536	2019-01-22 15:11:13.578871+00	1126	ESP-1 - 2016-03-29 00:00:00-04:00	1	new through import_export	50	1
2537	2019-01-22 15:11:13.585565+00	1127	ESP-1 - 2016-04-11 00:00:00-04:00	1	new through import_export	50	1
2538	2019-01-22 15:11:13.591704+00	1128	ESP-1 - 2016-04-22 00:00:00-04:00	1	new through import_export	50	1
2539	2019-01-22 15:11:13.59874+00	1129	ESP-1 - 2016-04-25 00:00:00-04:00	1	new through import_export	50	1
2540	2019-01-22 15:11:13.605466+00	1130	ESP-1 - 2016-04-26 00:00:00-04:00	1	new through import_export	50	1
2541	2019-01-22 15:11:13.612347+00	1131	ESP-1 - 2016-04-28 00:00:00-04:00	1	new through import_export	50	1
2542	2019-01-22 15:11:13.618591+00	1132	ESP-1 - 2016-04-29 00:00:00-04:00	1	new through import_export	50	1
2543	2019-01-22 15:11:13.624675+00	1133	ESP-1 - 2016-05-02 00:00:00-04:00	1	new through import_export	50	1
2544	2019-01-22 15:11:13.63204+00	1134	ESP-1 - 2016-05-03 00:00:00-04:00	1	new through import_export	50	1
2545	2019-01-22 15:11:13.639551+00	1135	ESP-1 - 2016-05-05 00:00:00-04:00	1	new through import_export	50	1
2546	2019-01-22 15:11:13.64734+00	1136	ESP-1 - 2016-05-06 00:00:00-04:00	1	new through import_export	50	1
2547	2019-01-22 15:11:13.655345+00	1137	ESP-1 - 2016-05-09 00:00:00-04:00	1	new through import_export	50	1
2548	2019-01-22 15:11:13.662325+00	1138	ESP-1 - 2016-05-10 00:00:00-04:00	1	new through import_export	50	1
2549	2019-01-22 15:11:13.669621+00	1139	ESP-1 - 2016-05-11 00:00:00-04:00	1	new through import_export	50	1
2550	2019-01-22 15:11:13.676829+00	1140	ESP-1 - 2016-05-12 00:00:00-04:00	1	new through import_export	50	1
2551	2019-01-22 15:11:13.6842+00	1141	ESP-1 - 2016-05-13 00:00:00-04:00	1	new through import_export	50	1
2552	2019-01-22 15:11:13.691898+00	1142	ESP-1 - 2016-05-16 00:00:00-04:00	1	new through import_export	50	1
2553	2019-01-22 15:11:13.700216+00	1143	ESP-1 - 2016-05-17 00:00:00-04:00	1	new through import_export	50	1
2554	2019-01-22 15:11:13.708975+00	1144	ESP-1 - 2016-05-18 00:00:00-04:00	1	new through import_export	50	1
2555	2019-01-22 15:11:13.71636+00	1145	ESP-1 - 2016-05-19 00:00:00-04:00	1	new through import_export	50	1
2556	2019-01-22 15:11:13.727714+00	1146	ESP-1 - 2016-05-20 00:00:00-04:00	1	new through import_export	50	1
2557	2019-01-22 15:11:13.735881+00	1147	ESP-1 - 2016-05-23 00:00:00-04:00	1	new through import_export	50	1
2558	2019-01-22 15:11:13.745375+00	1148	ESP-1 - 2016-05-24 00:00:00-04:00	1	new through import_export	50	1
2559	2019-01-22 15:11:13.753216+00	1149	ESP-1 - 2016-05-25 00:00:00-04:00	1	new through import_export	50	1
2560	2019-01-22 15:11:13.76073+00	1150	ESP-1 - 2016-05-26 00:00:00-04:00	1	new through import_export	50	1
2561	2019-01-22 15:11:13.767384+00	1151	ESP-1 - 2016-05-27 00:00:00-04:00	1	new through import_export	50	1
2562	2019-01-22 15:11:13.774875+00	1152	ESP-1 - 2016-05-30 00:00:00-04:00	1	new through import_export	50	1
2563	2019-01-22 15:11:13.78156+00	1153	ESP-1 - 2016-05-31 00:00:00-04:00	1	new through import_export	50	1
2564	2019-01-22 15:11:13.789233+00	1154	ESP-1 - 2016-06-01 00:00:00-04:00	1	new through import_export	50	1
2565	2019-01-22 15:11:13.795929+00	1155	ESP-1 - 2016-06-02 00:00:00-04:00	1	new through import_export	50	1
2566	2019-01-22 15:11:13.802158+00	1156	ESP-1 - 2016-06-03 00:00:00-04:00	1	new through import_export	50	1
2567	2019-01-22 15:11:13.808196+00	1157	ESP-1 - 2016-06-06 00:00:00-04:00	1	new through import_export	50	1
2568	2019-01-22 15:11:13.814189+00	1158	ESP-1 - 2016-06-07 00:00:00-04:00	1	new through import_export	50	1
2569	2019-01-22 15:11:13.82071+00	1159	ESP-1 - 2016-06-08 00:00:00-04:00	1	new through import_export	50	1
2570	2019-01-22 15:11:13.82675+00	1160	ESP-1 - 2016-06-09 00:00:00-04:00	1	new through import_export	50	1
2571	2019-01-22 15:11:13.833295+00	1161	ESP-1 - 2016-06-10 00:00:00-04:00	1	new through import_export	50	1
2572	2019-01-22 15:11:13.839717+00	1162	ESP-1 - 2016-06-13 00:00:00-04:00	1	new through import_export	50	1
2573	2019-01-22 15:11:13.847564+00	1163	ESP-1 - 2016-06-14 00:00:00-04:00	1	new through import_export	50	1
2574	2019-01-22 15:11:13.853934+00	1164	ESP-1 - 2016-06-15 00:00:00-04:00	1	new through import_export	50	1
2575	2019-01-22 15:11:13.86075+00	1165	ESP-1 - 2016-06-16 00:00:00-04:00	1	new through import_export	50	1
2576	2019-01-22 15:11:13.869298+00	1166	ESP-1 - 2016-06-17 00:00:00-04:00	1	new through import_export	50	1
2577	2019-01-22 15:11:13.876358+00	1167	ESP-1 - 2016-06-20 00:00:00-04:00	1	new through import_export	50	1
2578	2019-01-22 15:11:13.883046+00	1168	ESP-1 - 2016-06-21 00:00:00-04:00	1	new through import_export	50	1
2579	2019-01-22 15:11:13.889744+00	1169	ESP-1 - 2016-06-22 00:00:00-04:00	1	new through import_export	50	1
2580	2019-01-22 15:11:13.896494+00	1170	ESP-1 - 2016-06-23 00:00:00-04:00	1	new through import_export	50	1
2581	2019-01-22 15:11:13.902908+00	1171	ESP-1 - 2016-06-24 00:00:00-04:00	1	new through import_export	50	1
2582	2019-01-22 15:11:13.909572+00	1172	ESP-1 - 2016-06-27 00:00:00-04:00	1	new through import_export	50	1
2583	2019-01-22 15:11:13.916203+00	1173	ESP-1 - 2016-07-04 00:00:00-04:00	1	new through import_export	50	1
2584	2019-01-22 15:11:13.923358+00	1174	ESP-1 - 2016-07-11 00:00:00-04:00	1	new through import_export	50	1
2585	2019-01-22 15:13:04.996608+00	1227	ESP-2 - 2016-03-14 00:00:00-04:00	1	new through import_export	50	1
2586	2019-01-22 15:13:05.003604+00	1228	ESP-2 - 2016-03-15 00:00:00-04:00	1	new through import_export	50	1
2587	2019-01-22 15:13:05.010098+00	1229	ESP-2 - 2016-03-28 00:00:00-04:00	1	new through import_export	50	1
2588	2019-01-22 15:13:05.018663+00	1230	ESP-2 - 2016-03-29 00:00:00-04:00	1	new through import_export	50	1
2589	2019-01-22 15:13:05.026466+00	1231	ESP-2 - 2016-04-11 00:00:00-04:00	1	new through import_export	50	1
2590	2019-01-22 15:13:05.033296+00	1232	ESP-2 - 2016-04-22 00:00:00-04:00	1	new through import_export	50	1
2591	2019-01-22 15:13:05.039343+00	1233	ESP-2 - 2016-04-25 00:00:00-04:00	1	new through import_export	50	1
2592	2019-01-22 15:13:05.045885+00	1234	ESP-2 - 2016-04-26 00:00:00-04:00	1	new through import_export	50	1
2593	2019-01-22 15:13:05.052465+00	1235	ESP-2 - 2016-04-28 00:00:00-04:00	1	new through import_export	50	1
2594	2019-01-22 15:13:05.059576+00	1236	ESP-2 - 2016-04-29 00:00:00-04:00	1	new through import_export	50	1
2595	2019-01-22 15:13:05.065957+00	1237	ESP-2 - 2016-05-02 00:00:00-04:00	1	new through import_export	50	1
2596	2019-01-22 15:13:05.072044+00	1238	ESP-2 - 2016-05-03 00:00:00-04:00	1	new through import_export	50	1
2597	2019-01-22 15:13:05.078396+00	1239	ESP-2 - 2016-05-05 00:00:00-04:00	1	new through import_export	50	1
2598	2019-01-22 15:13:05.08562+00	1240	ESP-2 - 2016-05-06 00:00:00-04:00	1	new through import_export	50	1
2599	2019-01-22 15:13:05.093577+00	1241	ESP-2 - 2016-05-09 00:00:00-04:00	1	new through import_export	50	1
2600	2019-01-22 15:13:05.099885+00	1242	ESP-2 - 2016-05-10 00:00:00-04:00	1	new through import_export	50	1
2601	2019-01-22 15:13:05.106068+00	1243	ESP-2 - 2016-05-11 00:00:00-04:00	1	new through import_export	50	1
2602	2019-01-22 15:13:05.113029+00	1244	ESP-2 - 2016-05-12 00:00:00-04:00	1	new through import_export	50	1
2603	2019-01-22 15:13:05.119585+00	1245	ESP-2 - 2016-05-13 00:00:00-04:00	1	new through import_export	50	1
2604	2019-01-22 15:13:05.126136+00	1246	ESP-2 - 2016-05-16 00:00:00-04:00	1	new through import_export	50	1
2605	2019-01-22 15:13:05.13317+00	1247	ESP-2 - 2016-05-17 00:00:00-04:00	1	new through import_export	50	1
2606	2019-01-22 15:13:05.13918+00	1248	ESP-2 - 2016-05-18 00:00:00-04:00	1	new through import_export	50	1
2607	2019-01-22 15:13:05.145372+00	1249	ESP-2 - 2016-05-19 00:00:00-04:00	1	new through import_export	50	1
2608	2019-01-22 15:13:05.151545+00	1250	ESP-2 - 2016-05-20 00:00:00-04:00	1	new through import_export	50	1
2609	2019-01-22 15:13:05.157498+00	1251	ESP-2 - 2016-05-23 00:00:00-04:00	1	new through import_export	50	1
2610	2019-01-22 15:13:05.164755+00	1252	ESP-2 - 2016-05-24 00:00:00-04:00	1	new through import_export	50	1
2611	2019-01-22 15:13:05.171694+00	1253	ESP-2 - 2016-05-25 00:00:00-04:00	1	new through import_export	50	1
2612	2019-01-22 15:13:05.179514+00	1254	ESP-2 - 2016-05-26 00:00:00-04:00	1	new through import_export	50	1
2613	2019-01-22 15:13:05.186098+00	1255	ESP-2 - 2016-05-27 00:00:00-04:00	1	new through import_export	50	1
2614	2019-01-22 15:13:05.1925+00	1256	ESP-2 - 2016-05-30 00:00:00-04:00	1	new through import_export	50	1
2615	2019-01-22 15:13:05.1987+00	1257	ESP-2 - 2016-05-31 00:00:00-04:00	1	new through import_export	50	1
2616	2019-01-22 15:13:05.205096+00	1258	ESP-2 - 2016-06-01 00:00:00-04:00	1	new through import_export	50	1
2617	2019-01-22 15:13:05.212068+00	1259	ESP-2 - 2016-06-02 00:00:00-04:00	1	new through import_export	50	1
2618	2019-01-22 15:13:05.218295+00	1260	ESP-2 - 2016-06-03 00:00:00-04:00	1	new through import_export	50	1
2619	2019-01-22 15:13:05.224467+00	1261	ESP-2 - 2016-06-06 00:00:00-04:00	1	new through import_export	50	1
2620	2019-01-22 15:13:05.230631+00	1262	ESP-2 - 2016-06-07 00:00:00-04:00	1	new through import_export	50	1
2621	2019-01-22 15:13:05.236896+00	1263	ESP-2 - 2016-06-08 00:00:00-04:00	1	new through import_export	50	1
2622	2019-01-22 15:13:05.243428+00	1264	ESP-2 - 2016-06-09 00:00:00-04:00	1	new through import_export	50	1
2623	2019-01-22 15:13:05.249431+00	1265	ESP-2 - 2016-06-10 00:00:00-04:00	1	new through import_export	50	1
2624	2019-01-22 15:13:05.265602+00	1266	ESP-2 - 2016-06-13 00:00:00-04:00	1	new through import_export	50	1
2625	2019-01-22 15:13:05.276723+00	1267	ESP-2 - 2016-06-14 00:00:00-04:00	1	new through import_export	50	1
2626	2019-01-22 15:13:05.295653+00	1268	ESP-2 - 2016-06-15 00:00:00-04:00	1	new through import_export	50	1
2627	2019-01-22 15:13:05.31606+00	1269	ESP-2 - 2016-06-16 00:00:00-04:00	1	new through import_export	50	1
2628	2019-01-22 15:13:05.350321+00	1270	ESP-2 - 2016-06-17 00:00:00-04:00	1	new through import_export	50	1
2629	2019-01-22 15:13:05.356657+00	1271	ESP-2 - 2016-06-20 00:00:00-04:00	1	new through import_export	50	1
2630	2019-01-22 15:13:05.363581+00	1272	ESP-2 - 2016-06-21 00:00:00-04:00	1	new through import_export	50	1
2631	2019-01-22 15:13:05.370152+00	1273	ESP-2 - 2016-06-22 00:00:00-04:00	1	new through import_export	50	1
2632	2019-01-22 15:13:05.377157+00	1274	ESP-2 - 2016-06-23 00:00:00-04:00	1	new through import_export	50	1
2633	2019-01-22 15:13:05.383562+00	1275	ESP-2 - 2016-06-24 00:00:00-04:00	1	new through import_export	50	1
2634	2019-01-22 15:13:05.390093+00	1276	ESP-2 - 2016-06-27 00:00:00-04:00	1	new through import_export	50	1
2635	2019-01-22 15:13:05.396962+00	1277	ESP-2 - 2016-07-04 00:00:00-04:00	1	new through import_export	50	1
2636	2019-01-22 15:13:05.403347+00	1278	ESP-2 - 2016-07-11 00:00:00-04:00	1	new through import_export	50	1
2637	2019-01-22 15:17:36.996509+00	1333	ESP-3 - 2017-03-27 00:00:00-04:00	1	new through import_export	50	1
2638	2019-01-22 15:17:37.00343+00	1334	ESP-3 - 2017-04-10 00:00:00-04:00	1	new through import_export	50	1
2639	2019-01-22 15:17:37.010048+00	1335	ESP-3 - 2017-04-24 00:00:00-04:00	1	new through import_export	50	1
2640	2019-01-22 15:17:37.016908+00	1336	ESP-3 - 2017-05-01 00:00:00-04:00	1	new through import_export	50	1
2641	2019-01-22 15:17:37.023212+00	1337	ESP-3 - 2017-05-08 00:00:00-04:00	1	new through import_export	50	1
2642	2019-01-22 15:17:37.029999+00	1338	ESP-3 - 2017-05-15 00:00:00-04:00	1	new through import_export	50	1
2643	2019-01-22 15:17:37.036449+00	1339	ESP-3 - 2017-05-22 00:00:00-04:00	1	new through import_export	50	1
2644	2019-01-22 15:17:37.044643+00	1340	ESP-3 - 2017-05-29 00:00:00-04:00	1	new through import_export	50	1
2645	2019-01-22 15:17:37.051306+00	1341	ESP-3 - 2017-06-05 00:00:00-04:00	1	new through import_export	50	1
2646	2019-01-22 15:17:37.057437+00	1342	ESP-3 - 2017-06-12 00:00:00-04:00	1	new through import_export	50	1
2647	2019-01-22 15:17:37.063699+00	1343	ESP-3 - 2017-06-19 00:00:00-04:00	1	new through import_export	50	1
2648	2019-01-22 15:17:37.070362+00	1344	ESP-3 - 2017-06-26 00:00:00-04:00	1	new through import_export	50	1
2649	2019-01-22 15:17:37.077065+00	1345	ESP-3 - 2017-06-29 00:00:00-04:00	1	new through import_export	50	1
2650	2019-01-22 15:17:37.083707+00	1346	ESP-3 - 2017-06-30 00:00:00-04:00	1	new through import_export	50	1
2651	2019-01-22 15:17:37.089651+00	1347	ESP-3 - 2017-07-01 00:00:00-04:00	1	new through import_export	50	1
2652	2019-01-22 15:17:37.096147+00	1348	ESP-3 - 2017-07-03 00:00:00-04:00	1	new through import_export	50	1
2653	2019-01-22 15:17:37.102954+00	1349	ESP-3 - 2017-07-05 00:00:00-04:00	1	new through import_export	50	1
2654	2019-01-22 15:17:37.109345+00	1350	ESP-3 - 2017-07-06 00:00:00-04:00	1	new through import_export	50	1
2655	2019-01-22 15:17:37.116585+00	1351	ESP-3 - 2017-07-07 00:00:00-04:00	1	new through import_export	50	1
2656	2019-01-22 15:17:37.123144+00	1352	ESP-3 - 2017-07-10 00:00:00-04:00	1	new through import_export	50	1
2657	2019-01-22 15:17:37.129861+00	1353	ESP-3 - 2017-07-11 00:00:00-04:00	1	new through import_export	50	1
2658	2019-01-22 15:17:37.136372+00	1354	ESP-3 - 2017-07-12 00:00:00-04:00	1	new through import_export	50	1
2659	2019-01-22 15:17:37.14409+00	1355	ESP-3 - 2017-07-13 00:00:00-04:00	1	new through import_export	50	1
2660	2019-01-22 15:17:37.15042+00	1356	ESP-3 - 2017-07-14 00:00:00-04:00	1	new through import_export	50	1
2661	2019-01-22 15:17:37.156265+00	1357	ESP-3 - 2017-07-17 00:00:00-04:00	1	new through import_export	50	1
2662	2019-01-22 15:17:37.162276+00	1358	ESP-3 - 2017-07-18 00:00:00-04:00	1	new through import_export	50	1
2663	2019-01-22 15:17:37.169193+00	1359	ESP-3 - 2017-07-19 00:00:00-04:00	1	new through import_export	50	1
2664	2019-01-22 15:17:37.175498+00	1360	ESP-3 - 2017-07-20 00:00:00-04:00	1	new through import_export	50	1
2665	2019-01-22 15:17:37.182407+00	1361	ESP-3 - 2017-07-21 00:00:00-04:00	1	new through import_export	50	1
2666	2019-01-22 15:17:37.188487+00	1362	ESP-3 - 2017-07-24 00:00:00-04:00	1	new through import_export	50	1
2667	2019-01-22 15:17:37.19461+00	1363	ESP-3 - 2017-07-25 00:00:00-04:00	1	new through import_export	50	1
2668	2019-01-22 15:17:37.20104+00	1364	ESP-3 - 2017-07-26 00:00:00-04:00	1	new through import_export	50	1
2669	2019-01-22 15:17:37.207415+00	1365	ESP-3 - 2017-07-27 00:00:00-04:00	1	new through import_export	50	1
2670	2019-01-22 15:17:37.213821+00	1366	ESP-3 - 2017-07-28 00:00:00-04:00	1	new through import_export	50	1
2671	2019-01-22 15:17:37.22018+00	1367	ESP-3 - 2017-07-31 00:00:00-04:00	1	new through import_export	50	1
2672	2019-01-22 15:17:37.227232+00	1368	ESP-3 - 2017-08-01 00:00:00-04:00	1	new through import_export	50	1
2673	2019-01-22 15:17:37.234226+00	1369	ESP-3 - 2017-08-02 00:00:00-04:00	1	new through import_export	50	1
2674	2019-01-22 15:17:37.241427+00	1370	ESP-3 - 2017-08-03 00:00:00-04:00	1	new through import_export	50	1
2675	2019-01-22 15:17:37.248881+00	1371	ESP-3 - 2017-08-04 00:00:00-04:00	1	new through import_export	50	1
2676	2019-01-22 15:17:37.255254+00	1372	ESP-3 - 2017-08-07 00:00:00-04:00	1	new through import_export	50	1
2677	2019-01-22 15:17:37.262493+00	1373	ESP-3 - 2017-08-08 00:00:00-04:00	1	new through import_export	50	1
2678	2019-01-22 15:17:37.26963+00	1374	ESP-3 - 2017-08-09 00:00:00-04:00	1	new through import_export	50	1
2679	2019-01-22 15:17:37.275778+00	1375	ESP-3 - 2017-08-10 00:00:00-04:00	1	new through import_export	50	1
2680	2019-01-22 15:17:37.281784+00	1376	ESP-3 - 2017-08-11 00:00:00-04:00	1	new through import_export	50	1
2681	2019-01-22 15:17:37.287595+00	1377	ESP-3 - 2017-08-14 00:00:00-04:00	1	new through import_export	50	1
2682	2019-01-22 15:17:37.293573+00	1378	ESP-3 - 2017-08-15 00:00:00-04:00	1	new through import_export	50	1
2683	2019-01-22 15:17:37.300452+00	1379	ESP-3 - 2017-08-16 00:00:00-04:00	1	new through import_export	50	1
2684	2019-01-22 15:17:37.306343+00	1380	ESP-3 - 2017-08-17 00:00:00-04:00	1	new through import_export	50	1
2685	2019-01-22 15:17:37.313273+00	1381	ESP-3 - 2017-08-18 00:00:00-04:00	1	new through import_export	50	1
2686	2019-01-22 15:17:37.319975+00	1382	ESP-3 - 2017-08-21 00:00:00-04:00	1	new through import_export	50	1
2687	2019-01-22 15:17:37.327867+00	1383	ESP-3 - 2017-08-22 00:00:00-04:00	1	new through import_export	50	1
2688	2019-01-22 15:17:37.335685+00	1384	ESP-3 - 2017-08-23 00:00:00-04:00	1	new through import_export	50	1
2689	2019-01-22 15:17:37.342567+00	1385	ESP-3 - 2017-08-24 00:00:00-04:00	1	new through import_export	50	1
2690	2019-01-22 15:17:37.349044+00	1386	ESP-3 - 2017-08-28 00:00:00-04:00	1	new through import_export	50	1
2691	2019-01-22 15:24:54.526539+00	1441	ESP-4 - 2017-03-27 00:00:00-04:00	1	new through import_export	50	1
2692	2019-01-22 15:24:54.533798+00	1442	ESP-4 - 2017-04-10 00:00:00-04:00	1	new through import_export	50	1
2693	2019-01-22 15:24:54.541461+00	1443	ESP-4 - 2017-04-24 00:00:00-04:00	1	new through import_export	50	1
2694	2019-01-22 15:24:54.548093+00	1444	ESP-4 - 2017-05-01 00:00:00-04:00	1	new through import_export	50	1
2695	2019-01-22 15:24:54.555248+00	1445	ESP-4 - 2017-05-08 00:00:00-04:00	1	new through import_export	50	1
2696	2019-01-22 15:24:54.57194+00	1446	ESP-4 - 2017-05-15 00:00:00-04:00	1	new through import_export	50	1
2697	2019-01-22 15:24:54.585332+00	1447	ESP-4 - 2017-05-22 00:00:00-04:00	1	new through import_export	50	1
2698	2019-01-22 15:24:54.605945+00	1448	ESP-4 - 2017-05-29 00:00:00-04:00	1	new through import_export	50	1
2699	2019-01-22 15:24:54.632079+00	1449	ESP-4 - 2017-06-05 00:00:00-04:00	1	new through import_export	50	1
2700	2019-01-22 15:24:54.671381+00	1450	ESP-4 - 2017-06-12 00:00:00-04:00	1	new through import_export	50	1
2701	2019-01-22 15:24:54.678555+00	1451	ESP-4 - 2017-06-19 00:00:00-04:00	1	new through import_export	50	1
2702	2019-01-22 15:24:54.685675+00	1452	ESP-4 - 2017-06-26 00:00:00-04:00	1	new through import_export	50	1
2703	2019-01-22 15:24:54.692189+00	1453	ESP-4 - 2017-06-29 00:00:00-04:00	1	new through import_export	50	1
2704	2019-01-22 15:24:54.698459+00	1454	ESP-4 - 2017-06-30 00:00:00-04:00	1	new through import_export	50	1
2705	2019-01-22 15:24:54.704956+00	1455	ESP-4 - 2017-07-01 00:00:00-04:00	1	new through import_export	50	1
2706	2019-01-22 15:24:54.711272+00	1456	ESP-4 - 2017-07-03 00:00:00-04:00	1	new through import_export	50	1
2707	2019-01-22 15:24:54.717571+00	1457	ESP-4 - 2017-07-05 00:00:00-04:00	1	new through import_export	50	1
2708	2019-01-22 15:24:54.723745+00	1458	ESP-4 - 2017-07-06 00:00:00-04:00	1	new through import_export	50	1
2709	2019-01-22 15:24:54.730594+00	1459	ESP-4 - 2017-07-07 00:00:00-04:00	1	new through import_export	50	1
2710	2019-01-22 15:24:54.737408+00	1460	ESP-4 - 2017-07-10 00:00:00-04:00	1	new through import_export	50	1
2711	2019-01-22 15:24:54.743756+00	1461	ESP-4 - 2017-07-11 00:00:00-04:00	1	new through import_export	50	1
2712	2019-01-22 15:24:54.749824+00	1462	ESP-4 - 2017-07-12 00:00:00-04:00	1	new through import_export	50	1
2713	2019-01-22 15:24:54.75615+00	1463	ESP-4 - 2017-07-13 00:00:00-04:00	1	new through import_export	50	1
2714	2019-01-22 15:24:54.762446+00	1464	ESP-4 - 2017-07-14 00:00:00-04:00	1	new through import_export	50	1
2715	2019-01-22 15:24:54.769032+00	1465	ESP-4 - 2017-07-17 00:00:00-04:00	1	new through import_export	50	1
2716	2019-01-22 15:24:54.775195+00	1466	ESP-4 - 2017-07-18 00:00:00-04:00	1	new through import_export	50	1
2717	2019-01-22 15:24:54.781172+00	1467	ESP-4 - 2017-07-19 00:00:00-04:00	1	new through import_export	50	1
2718	2019-01-22 15:24:54.788274+00	1468	ESP-4 - 2017-07-20 00:00:00-04:00	1	new through import_export	50	1
2719	2019-01-22 15:24:54.794372+00	1469	ESP-4 - 2017-07-21 00:00:00-04:00	1	new through import_export	50	1
2720	2019-01-22 15:24:54.800673+00	1470	ESP-4 - 2017-07-24 00:00:00-04:00	1	new through import_export	50	1
2721	2019-01-22 15:24:54.807217+00	1471	ESP-4 - 2017-07-25 00:00:00-04:00	1	new through import_export	50	1
2722	2019-01-22 15:24:54.813431+00	1472	ESP-4 - 2017-07-26 00:00:00-04:00	1	new through import_export	50	1
2723	2019-01-22 15:24:54.82005+00	1473	ESP-4 - 2017-07-27 00:00:00-04:00	1	new through import_export	50	1
2724	2019-01-22 15:24:54.826121+00	1474	ESP-4 - 2017-07-28 00:00:00-04:00	1	new through import_export	50	1
2725	2019-01-22 15:24:54.833577+00	1475	ESP-4 - 2017-07-31 00:00:00-04:00	1	new through import_export	50	1
2726	2019-01-22 15:24:54.840591+00	1476	ESP-4 - 2017-08-01 00:00:00-04:00	1	new through import_export	50	1
2727	2019-01-22 15:24:54.847437+00	1477	ESP-4 - 2017-08-02 00:00:00-04:00	1	new through import_export	50	1
2728	2019-01-22 15:24:54.854359+00	1478	ESP-4 - 2017-08-03 00:00:00-04:00	1	new through import_export	50	1
2729	2019-01-22 15:24:54.861191+00	1479	ESP-4 - 2017-08-04 00:00:00-04:00	1	new through import_export	50	1
2730	2019-01-22 15:24:54.867715+00	1480	ESP-4 - 2017-08-07 00:00:00-04:00	1	new through import_export	50	1
2731	2019-01-22 15:24:54.87375+00	1481	ESP-4 - 2017-08-08 00:00:00-04:00	1	new through import_export	50	1
2732	2019-01-22 15:24:54.879759+00	1482	ESP-4 - 2017-08-09 00:00:00-04:00	1	new through import_export	50	1
2733	2019-01-22 15:24:54.885782+00	1483	ESP-4 - 2017-08-10 00:00:00-04:00	1	new through import_export	50	1
2734	2019-01-22 15:24:54.893323+00	1484	ESP-4 - 2017-08-11 00:00:00-04:00	1	new through import_export	50	1
2735	2019-01-22 15:24:54.899626+00	1485	ESP-4 - 2017-08-14 00:00:00-04:00	1	new through import_export	50	1
2736	2019-01-22 15:24:54.906643+00	1486	ESP-4 - 2017-08-15 00:00:00-04:00	1	new through import_export	50	1
2737	2019-01-22 15:24:54.913186+00	1487	ESP-4 - 2017-08-16 00:00:00-04:00	1	new through import_export	50	1
2738	2019-01-22 15:24:54.920082+00	1488	ESP-4 - 2017-08-17 00:00:00-04:00	1	new through import_export	50	1
2739	2019-01-22 15:24:54.926236+00	1489	ESP-4 - 2017-08-18 00:00:00-04:00	1	new through import_export	50	1
2740	2019-01-22 15:24:54.932428+00	1490	ESP-4 - 2017-08-21 00:00:00-04:00	1	new through import_export	50	1
2741	2019-01-22 15:24:54.938893+00	1491	ESP-4 - 2017-08-22 00:00:00-04:00	1	new through import_export	50	1
2742	2019-01-22 15:24:54.945273+00	1492	ESP-4 - 2017-08-23 00:00:00-04:00	1	new through import_export	50	1
2743	2019-01-22 15:24:54.951683+00	1493	ESP-4 - 2017-08-24 00:00:00-04:00	1	new through import_export	50	1
2744	2019-01-22 15:24:54.958097+00	1494	ESP-4 - 2017-08-28 00:00:00-04:00	1	new through import_export	50	1
2745	2019-01-22 15:28:02.656571+00	1549	ESP-1 - 2017-03-27 00:00:00-04:00	1	new through import_export	50	1
2746	2019-01-22 15:28:02.664868+00	1550	ESP-1 - 2017-04-10 00:00:00-04:00	1	new through import_export	50	1
2747	2019-01-22 15:28:02.671384+00	1551	ESP-1 - 2017-04-24 00:00:00-04:00	1	new through import_export	50	1
2748	2019-01-22 15:28:02.677851+00	1552	ESP-1 - 2017-05-01 00:00:00-04:00	1	new through import_export	50	1
2749	2019-01-22 15:28:02.684601+00	1553	ESP-1 - 2017-05-08 00:00:00-04:00	1	new through import_export	50	1
2750	2019-01-22 15:28:02.692152+00	1554	ESP-1 - 2017-05-15 00:00:00-04:00	1	new through import_export	50	1
2751	2019-01-22 15:28:02.699281+00	1555	ESP-1 - 2017-05-22 00:00:00-04:00	1	new through import_export	50	1
2752	2019-01-22 15:28:02.705736+00	1556	ESP-1 - 2017-05-29 00:00:00-04:00	1	new through import_export	50	1
2753	2019-01-22 15:28:02.713001+00	1557	ESP-1 - 2017-06-05 00:00:00-04:00	1	new through import_export	50	1
2754	2019-01-22 15:28:02.721287+00	1558	ESP-1 - 2017-06-12 00:00:00-04:00	1	new through import_export	50	1
2755	2019-01-22 15:28:02.728102+00	1559	ESP-1 - 2017-06-19 00:00:00-04:00	1	new through import_export	50	1
2756	2019-01-22 15:28:02.736205+00	1560	ESP-1 - 2017-06-26 00:00:00-04:00	1	new through import_export	50	1
2757	2019-01-22 15:28:02.74284+00	1561	ESP-1 - 2017-06-29 00:00:00-04:00	1	new through import_export	50	1
2758	2019-01-22 15:28:02.749424+00	1562	ESP-1 - 2017-06-30 00:00:00-04:00	1	new through import_export	50	1
2759	2019-01-22 15:28:02.756333+00	1563	ESP-1 - 2017-07-01 00:00:00-04:00	1	new through import_export	50	1
2760	2019-01-22 15:28:02.762955+00	1564	ESP-1 - 2017-07-03 00:00:00-04:00	1	new through import_export	50	1
2761	2019-01-22 15:28:02.769994+00	1565	ESP-1 - 2017-07-05 00:00:00-04:00	1	new through import_export	50	1
2762	2019-01-22 15:28:02.776654+00	1566	ESP-1 - 2017-07-06 00:00:00-04:00	1	new through import_export	50	1
2763	2019-01-22 15:28:02.783771+00	1567	ESP-1 - 2017-07-07 00:00:00-04:00	1	new through import_export	50	1
2764	2019-01-22 15:28:02.790715+00	1568	ESP-1 - 2017-07-10 00:00:00-04:00	1	new through import_export	50	1
2765	2019-01-22 15:28:02.797191+00	1569	ESP-1 - 2017-07-11 00:00:00-04:00	1	new through import_export	50	1
2766	2019-01-22 15:28:02.803634+00	1570	ESP-1 - 2017-07-12 00:00:00-04:00	1	new through import_export	50	1
2767	2019-01-22 15:28:02.810524+00	1571	ESP-1 - 2017-07-13 00:00:00-04:00	1	new through import_export	50	1
2768	2019-01-22 15:28:02.816552+00	1572	ESP-1 - 2017-07-14 00:00:00-04:00	1	new through import_export	50	1
2769	2019-01-22 15:28:02.823637+00	1573	ESP-1 - 2017-07-17 00:00:00-04:00	1	new through import_export	50	1
2770	2019-01-22 15:28:02.830448+00	1574	ESP-1 - 2017-07-18 00:00:00-04:00	1	new through import_export	50	1
2771	2019-01-22 15:28:02.836566+00	1575	ESP-1 - 2017-07-19 00:00:00-04:00	1	new through import_export	50	1
2772	2019-01-22 15:28:02.842924+00	1576	ESP-1 - 2017-07-20 00:00:00-04:00	1	new through import_export	50	1
2773	2019-01-22 15:28:02.849196+00	1577	ESP-1 - 2017-07-21 00:00:00-04:00	1	new through import_export	50	1
2774	2019-01-22 15:28:02.855502+00	1578	ESP-1 - 2017-07-24 00:00:00-04:00	1	new through import_export	50	1
2775	2019-01-22 15:28:02.861996+00	1579	ESP-1 - 2017-07-25 00:00:00-04:00	1	new through import_export	50	1
2776	2019-01-22 15:28:02.868873+00	1580	ESP-1 - 2017-07-26 00:00:00-04:00	1	new through import_export	50	1
2777	2019-01-22 15:28:02.876018+00	1581	ESP-1 - 2017-07-27 00:00:00-04:00	1	new through import_export	50	1
2778	2019-01-22 15:28:02.882809+00	1582	ESP-1 - 2017-07-28 00:00:00-04:00	1	new through import_export	50	1
2779	2019-01-22 15:28:02.889386+00	1583	ESP-1 - 2017-07-31 00:00:00-04:00	1	new through import_export	50	1
2780	2019-01-22 15:28:02.895598+00	1584	ESP-1 - 2017-08-01 00:00:00-04:00	1	new through import_export	50	1
2781	2019-01-22 15:28:02.901712+00	1585	ESP-1 - 2017-08-02 00:00:00-04:00	1	new through import_export	50	1
2782	2019-01-22 15:28:02.907531+00	1586	ESP-1 - 2017-08-03 00:00:00-04:00	1	new through import_export	50	1
2783	2019-01-22 15:28:02.914113+00	1587	ESP-1 - 2017-08-04 00:00:00-04:00	1	new through import_export	50	1
2784	2019-01-22 15:28:02.919995+00	1588	ESP-1 - 2017-08-07 00:00:00-04:00	1	new through import_export	50	1
2785	2019-01-22 15:28:02.92643+00	1589	ESP-1 - 2017-08-08 00:00:00-04:00	1	new through import_export	50	1
2786	2019-01-22 15:28:02.932632+00	1590	ESP-1 - 2017-08-09 00:00:00-04:00	1	new through import_export	50	1
2787	2019-01-22 15:28:02.939108+00	1591	ESP-1 - 2017-08-10 00:00:00-04:00	1	new through import_export	50	1
2788	2019-01-22 15:28:02.945389+00	1592	ESP-1 - 2017-08-11 00:00:00-04:00	1	new through import_export	50	1
2789	2019-01-22 15:28:02.95191+00	1593	ESP-1 - 2017-08-14 00:00:00-04:00	1	new through import_export	50	1
2790	2019-01-22 15:28:02.958424+00	1594	ESP-1 - 2017-08-15 00:00:00-04:00	1	new through import_export	50	1
2791	2019-01-22 15:28:02.964716+00	1595	ESP-1 - 2017-08-16 00:00:00-04:00	1	new through import_export	50	1
2792	2019-01-22 15:28:02.971729+00	1596	ESP-1 - 2017-08-17 00:00:00-04:00	1	new through import_export	50	1
2793	2019-01-22 15:28:02.978157+00	1597	ESP-1 - 2017-08-18 00:00:00-04:00	1	new through import_export	50	1
2794	2019-01-22 15:28:02.984303+00	1598	ESP-1 - 2017-08-21 00:00:00-04:00	1	new through import_export	50	1
2795	2019-01-22 15:28:02.991132+00	1599	ESP-1 - 2017-08-22 00:00:00-04:00	1	new through import_export	50	1
2796	2019-01-22 15:28:02.997209+00	1600	ESP-1 - 2017-08-23 00:00:00-04:00	1	new through import_export	50	1
2797	2019-01-22 15:28:03.003666+00	1601	ESP-1 - 2017-08-24 00:00:00-04:00	1	new through import_export	50	1
2798	2019-01-22 15:28:03.009735+00	1602	ESP-1 - 2017-08-28 00:00:00-04:00	1	new through import_export	50	1
2799	2019-01-22 15:30:28.762011+00	1654	Bowdoin wetlab - 2018-03-12 00:00:00-04:00	1	new through import_export	50	1
2800	2019-01-22 15:30:28.769505+00	1655	Bowdoin wetlab - 2018-03-26 00:00:00-04:00	1	new through import_export	50	1
2801	2019-01-22 15:30:28.775891+00	1656	Bowdoin wetlab - 2018-04-10 00:00:00-04:00	1	new through import_export	50	1
2802	2019-01-22 15:30:28.78267+00	1657	Bowdoin wetlab - 2018-04-17 00:00:00-04:00	1	new through import_export	50	1
2803	2019-01-22 15:30:28.790569+00	1658	Bowdoin wetlab - 2018-04-19 00:00:00-04:00	1	new through import_export	50	1
2804	2019-01-22 15:30:28.797502+00	1659	Bowdoin wetlab - 2018-04-20 00:00:00-04:00	1	new through import_export	50	1
2805	2019-01-22 15:30:28.804054+00	1660	Bowdoin wetlab - 2018-04-24 00:00:00-04:00	1	new through import_export	50	1
2806	2019-01-22 15:30:28.810591+00	1661	Bowdoin wetlab - 2018-04-27 00:00:00-04:00	1	new through import_export	50	1
2807	2019-01-22 15:30:28.817298+00	1662	Bowdoin wetlab - 2018-05-01 00:00:00-04:00	1	new through import_export	50	1
2808	2019-01-22 15:30:28.823646+00	1663	Bowdoin wetlab - 2018-05-04 00:00:00-04:00	1	new through import_export	50	1
2809	2019-01-22 15:30:28.831215+00	1664	Bowdoin wetlab - 2018-05-07 00:00:00-04:00	1	new through import_export	50	1
2810	2019-01-22 15:30:28.838556+00	1665	Bowdoin wetlab - 2018-05-08 00:00:00-04:00	1	new through import_export	50	1
2811	2019-01-22 15:30:28.845638+00	1666	Bowdoin wetlab - 2018-05-09 00:00:00-04:00	1	new through import_export	50	1
2812	2019-01-22 15:30:28.85214+00	1667	Bowdoin wetlab - 2018-05-10 00:00:00-04:00	1	new through import_export	50	1
2813	2019-01-22 15:30:28.858918+00	1668	Bowdoin wetlab - 2018-05-11 00:00:00-04:00	1	new through import_export	50	1
2814	2019-01-22 15:30:28.865662+00	1669	Bowdoin wetlab - 2018-05-14 00:00:00-04:00	1	new through import_export	50	1
2815	2019-01-22 15:30:28.872584+00	1670	Bowdoin wetlab - 2018-05-15 00:00:00-04:00	1	new through import_export	50	1
2816	2019-01-22 15:30:28.879486+00	1671	Bowdoin wetlab - 2018-05-16 00:00:00-04:00	1	new through import_export	50	1
2817	2019-01-22 15:30:28.886011+00	1672	Bowdoin wetlab - 2018-05-17 00:00:00-04:00	1	new through import_export	50	1
2818	2019-01-22 15:30:28.894295+00	1673	Bowdoin wetlab - 2018-05-18 00:00:00-04:00	1	new through import_export	50	1
2819	2019-01-22 15:30:28.901119+00	1674	Bowdoin wetlab - 2018-05-21 00:00:00-04:00	1	new through import_export	50	1
2820	2019-01-22 15:30:28.907522+00	1675	Bowdoin wetlab - 2018-05-22 00:00:00-04:00	1	new through import_export	50	1
2821	2019-01-22 15:30:28.913984+00	1676	Bowdoin wetlab - 2018-05-23 00:00:00-04:00	1	new through import_export	50	1
2822	2019-01-22 15:30:28.920604+00	1677	Bowdoin wetlab - 2018-05-24 00:00:00-04:00	1	new through import_export	50	1
2823	2019-01-22 15:30:28.927027+00	1678	Bowdoin wetlab - 2018-05-25 00:00:00-04:00	1	new through import_export	50	1
2824	2019-01-22 15:30:28.933686+00	1679	Bowdoin wetlab - 2018-05-28 00:00:00-04:00	1	new through import_export	50	1
2825	2019-01-22 15:30:28.940294+00	1680	Bowdoin wetlab - 2018-05-29 00:00:00-04:00	1	new through import_export	50	1
2826	2019-01-22 15:30:28.947507+00	1681	Bowdoin wetlab - 2018-05-30 00:00:00-04:00	1	new through import_export	50	1
2827	2019-01-22 15:30:28.954403+00	1682	Bowdoin wetlab - 2018-05-31 00:00:00-04:00	1	new through import_export	50	1
2828	2019-01-22 15:30:28.961231+00	1683	Bowdoin wetlab - 2018-06-01 00:00:00-04:00	1	new through import_export	50	1
2829	2019-01-22 15:30:28.968713+00	1684	Bowdoin wetlab - 2018-06-04 00:00:00-04:00	1	new through import_export	50	1
2830	2019-01-22 15:30:28.976049+00	1685	Bowdoin wetlab - 2018-06-05 00:00:00-04:00	1	new through import_export	50	1
2831	2019-01-22 15:30:28.983894+00	1686	Bowdoin wetlab - 2018-06-06 00:00:00-04:00	1	new through import_export	50	1
2832	2019-01-22 15:30:28.992153+00	1687	Bowdoin wetlab - 2018-06-07 00:00:00-04:00	1	new through import_export	50	1
2833	2019-01-22 15:30:28.999165+00	1688	Bowdoin wetlab - 2018-06-08 00:00:00-04:00	1	new through import_export	50	1
2834	2019-01-22 15:30:29.005877+00	1689	Bowdoin wetlab - 2018-06-11 00:00:00-04:00	1	new through import_export	50	1
2835	2019-01-22 15:30:29.012954+00	1690	Bowdoin wetlab - 2018-06-12 00:00:00-04:00	1	new through import_export	50	1
2836	2019-01-22 15:30:29.02051+00	1691	Bowdoin wetlab - 2018-06-13 00:00:00-04:00	1	new through import_export	50	1
2837	2019-01-22 15:30:29.02781+00	1692	Bowdoin wetlab - 2018-06-14 00:00:00-04:00	1	new through import_export	50	1
2838	2019-01-22 15:30:29.034545+00	1693	Bowdoin wetlab - 2018-06-15 00:00:00-04:00	1	new through import_export	50	1
2839	2019-01-22 15:30:29.041977+00	1694	Bowdoin wetlab - 2018-06-18 00:00:00-04:00	1	new through import_export	50	1
2840	2019-01-22 15:30:29.048726+00	1695	Bowdoin wetlab - 2018-06-19 00:00:00-04:00	1	new through import_export	50	1
2841	2019-01-22 15:30:29.05508+00	1696	Bowdoin wetlab - 2018-06-20 00:00:00-04:00	1	new through import_export	50	1
2842	2019-01-22 15:30:29.061798+00	1697	Bowdoin wetlab - 2018-06-21 00:00:00-04:00	1	new through import_export	50	1
2843	2019-01-22 15:30:29.068223+00	1698	Bowdoin wetlab - 2018-06-22 00:00:00-04:00	1	new through import_export	50	1
2844	2019-01-22 15:30:29.074742+00	1699	Bowdoin wetlab - 2018-06-25 00:00:00-04:00	1	new through import_export	50	1
2845	2019-01-22 15:30:29.081438+00	1700	Bowdoin wetlab - 2018-06-26 00:00:00-04:00	1	new through import_export	50	1
2846	2019-01-22 15:30:29.088029+00	1701	Bowdoin wetlab - 2018-06-27 00:00:00-04:00	1	new through import_export	50	1
2847	2019-01-22 15:30:29.095262+00	1702	Bowdoin wetlab - 2018-06-29 00:00:00-04:00	1	new through import_export	50	1
2848	2019-01-22 15:30:29.102908+00	1703	Bowdoin wetlab - 2018-07-02 00:00:00-04:00	1	new through import_export	50	1
2849	2019-01-22 15:30:29.109271+00	1704	Bowdoin wetlab - 2018-07-08 00:00:00-04:00	1	new through import_export	50	1
2850	2019-01-22 15:35:30.480704+00	3775	OC5 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
2851	2019-01-22 15:35:30.487561+00	3776	OC5 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
2852	2019-01-22 15:35:30.494226+00	3777	OC5 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
2853	2019-01-22 15:35:30.500709+00	3778	OC5 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
2854	2019-01-22 15:35:30.506902+00	3779	OC5 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
2855	2019-01-22 15:35:30.51339+00	3780	OC5 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
2856	2019-01-22 15:35:30.519709+00	3781	OC5 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
2857	2019-01-22 15:35:30.526591+00	3782	OC5 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
2858	2019-01-22 15:35:30.53405+00	3783	OC5 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
2859	2019-01-22 15:35:30.540439+00	3784	OC5 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
2860	2019-01-22 15:35:30.547763+00	3785	OC5 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
2861	2019-01-22 15:35:30.5669+00	3786	OC5 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
2862	2019-01-22 15:35:30.585431+00	3787	OC5 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
2863	2019-01-22 15:35:30.606103+00	3788	OC5 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
2864	2019-01-22 15:35:30.639625+00	3789	OC5 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
2865	2019-01-22 15:35:30.646874+00	3790	OC5 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
2866	2019-01-22 15:35:30.655098+00	3791	OC5 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
2867	2019-01-22 15:35:30.661988+00	3792	OC5 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
2868	2019-01-22 15:35:30.669592+00	3793	OC5 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
2869	2019-01-22 15:35:30.676144+00	3794	OC5 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
2870	2019-01-22 15:35:30.684842+00	3795	OC5 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
2871	2019-01-22 15:35:30.691581+00	3796	OC5 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
2872	2019-01-22 15:35:30.698828+00	3797	OC5 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
2873	2019-01-22 15:35:30.705152+00	3798	OC5 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
2874	2019-01-22 15:35:30.711712+00	3799	OC5 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
2875	2019-01-22 15:35:30.718341+00	3800	OC5 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
2876	2019-01-22 15:35:30.725391+00	3801	OC5 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
2877	2019-01-22 15:35:30.731625+00	3802	OC5 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
2878	2019-01-22 15:35:30.738938+00	3803	OC5 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
2879	2019-01-22 15:35:30.745248+00	3804	OC5 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
2880	2019-01-22 15:35:30.752442+00	3805	OC5 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
2881	2019-01-22 15:35:30.7596+00	3806	OC5 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
2882	2019-01-22 15:35:30.766812+00	3807	OC5 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
2883	2019-01-22 15:35:30.773486+00	3808	OC5 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
2884	2019-01-22 15:35:30.780722+00	3809	OC5 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
2885	2019-01-22 15:35:30.78804+00	3810	OC5 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
2886	2019-01-22 15:35:30.794675+00	3811	OC5 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
2887	2019-01-22 15:35:30.801301+00	3812	OC5 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
2888	2019-01-22 15:35:30.807976+00	3813	OC5 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
2889	2019-01-22 15:35:30.815294+00	3814	OC5 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
2890	2019-01-22 15:35:30.821962+00	3815	OC5 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
2891	2019-01-22 15:35:30.828819+00	3816	OC5 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
2892	2019-01-22 15:35:30.836082+00	3817	OC5 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
2893	2019-01-22 15:35:30.842564+00	3818	OC5 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
2894	2019-01-22 15:35:30.850337+00	3819	OC5 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
2895	2019-01-22 15:35:30.857488+00	3820	OC5 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
2896	2019-01-22 15:35:30.864585+00	3821	OC5 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
2897	2019-01-22 15:35:30.871661+00	3822	OC5 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
2898	2019-01-22 15:35:30.877862+00	3823	OC5 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
2899	2019-01-22 15:35:30.885199+00	3824	OC5 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
2900	2019-01-22 15:35:30.89163+00	3825	OC5 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
2901	2019-01-22 15:35:30.898951+00	3826	OC5 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
2902	2019-01-22 15:35:30.905362+00	3827	OC5 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
2903	2019-01-22 15:35:30.912394+00	3828	OC5 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
2904	2019-01-22 15:35:30.919421+00	3829	OC5 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
2905	2019-01-22 15:35:30.925901+00	3830	OC5 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
2906	2019-01-22 15:35:30.931854+00	3831	OC5 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
2907	2019-01-22 15:35:30.938935+00	3832	OC5 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
2908	2019-01-22 15:35:30.94554+00	3833	OC5 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
2909	2019-01-22 15:35:30.952476+00	3834	OC5 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
2910	2019-01-22 15:35:30.960702+00	3835	OC5 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
2911	2019-01-22 15:35:30.967073+00	3836	OC5 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
2912	2019-01-22 15:35:30.973573+00	3837	OC5 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
2913	2019-01-22 15:35:30.980839+00	3838	OC5 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
2914	2019-01-22 15:35:30.9876+00	3839	OC5 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
2915	2019-01-22 15:35:30.994041+00	3840	OC5 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
2916	2019-01-22 15:35:31.000071+00	3841	OC5 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
2917	2019-01-22 15:35:31.006943+00	3842	OC5 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
2918	2019-01-22 15:35:31.013714+00	3843	OC5 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
2919	2019-01-22 15:35:31.020106+00	3844	OC5 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
2920	2019-01-22 15:35:31.026084+00	3845	OC5 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
2921	2019-01-22 15:35:31.032416+00	3846	OC5 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
2922	2019-01-22 15:35:31.03885+00	3847	OC5 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
2923	2019-01-22 15:35:31.045727+00	3848	OC5 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
2924	2019-01-22 15:37:04.307082+00	3923	OC6 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
2925	2019-01-22 15:37:04.31355+00	3924	OC6 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
2926	2019-01-22 15:37:04.320582+00	3925	OC6 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
2927	2019-01-22 15:37:04.327223+00	3926	OC6 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
2928	2019-01-22 15:37:04.333739+00	3927	OC6 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
2929	2019-01-22 15:37:04.340928+00	3928	OC6 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
2930	2019-01-22 15:37:04.356172+00	3929	OC6 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
2931	2019-01-22 15:37:04.367412+00	3930	OC6 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
2932	2019-01-22 15:37:04.385828+00	3931	OC6 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
2933	2019-01-22 15:37:04.40659+00	3932	OC6 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
2934	2019-01-22 15:37:04.439589+00	3933	OC6 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
2935	2019-01-22 15:37:04.447055+00	3934	OC6 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
2936	2019-01-22 15:37:04.453744+00	3935	OC6 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
2937	2019-01-22 15:37:04.460369+00	3936	OC6 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
2938	2019-01-22 15:37:04.466586+00	3937	OC6 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
2939	2019-01-22 15:37:04.473114+00	3938	OC6 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
2940	2019-01-22 15:37:04.479625+00	3939	OC6 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
2941	2019-01-22 15:37:04.486781+00	3940	OC6 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
2942	2019-01-22 15:37:04.494559+00	3941	OC6 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
2943	2019-01-22 15:37:04.501123+00	3942	OC6 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
2944	2019-01-22 15:37:04.507223+00	3943	OC6 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
2945	2019-01-22 15:37:04.51393+00	3944	OC6 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
2946	2019-01-22 15:37:04.521315+00	3945	OC6 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
2947	2019-01-22 15:37:04.528367+00	3946	OC6 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
2948	2019-01-22 15:37:04.534851+00	3947	OC6 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
2949	2019-01-22 15:37:04.541817+00	3948	OC6 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
2950	2019-01-22 15:37:04.549393+00	3949	OC6 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
2951	2019-01-22 15:37:04.556068+00	3950	OC6 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
2952	2019-01-22 15:37:04.562231+00	3951	OC6 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
2953	2019-01-22 15:37:04.568288+00	3952	OC6 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
2954	2019-01-22 15:37:04.574986+00	3953	OC6 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
2955	2019-01-22 15:37:04.582062+00	3954	OC6 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
2956	2019-01-22 15:37:04.589139+00	3955	OC6 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
2957	2019-01-22 15:37:04.596327+00	3956	OC6 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
2958	2019-01-22 15:37:04.602679+00	3957	OC6 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
2959	2019-01-22 15:37:04.608904+00	3958	OC6 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
2960	2019-01-22 15:37:04.615446+00	3959	OC6 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
2961	2019-01-22 15:37:04.622155+00	3960	OC6 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
2962	2019-01-22 15:37:04.628817+00	3961	OC6 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
2963	2019-01-22 15:37:04.635144+00	3962	OC6 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
2964	2019-01-22 15:37:04.642116+00	3963	OC6 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
2965	2019-01-22 15:37:04.648701+00	3964	OC6 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
2966	2019-01-22 15:37:04.654791+00	3965	OC6 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
2967	2019-01-22 15:37:04.661466+00	3966	OC6 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
2968	2019-01-22 15:37:04.667782+00	3967	OC6 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
2969	2019-01-22 15:37:04.674379+00	3968	OC6 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
2970	2019-01-22 15:37:04.681077+00	3969	OC6 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
2971	2019-01-22 15:37:04.687775+00	3970	OC6 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
2972	2019-01-22 15:37:04.694739+00	3971	OC6 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
2973	2019-01-22 15:37:04.70229+00	3972	OC6 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
2974	2019-01-22 15:37:04.709145+00	3973	OC6 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
2975	2019-01-22 15:37:04.715179+00	3974	OC6 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
2976	2019-01-22 15:37:04.721469+00	3975	OC6 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
2977	2019-01-22 15:37:04.727981+00	3976	OC6 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
2978	2019-01-22 15:37:04.734433+00	3977	OC6 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
2979	2019-01-22 15:37:04.741437+00	3978	OC6 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
2980	2019-01-22 15:37:04.748112+00	3979	OC6 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
2981	2019-01-22 15:37:04.754294+00	3980	OC6 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
2982	2019-01-22 15:37:04.760683+00	3981	OC6 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
2983	2019-01-22 15:37:04.766987+00	3982	OC6 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
2984	2019-01-22 15:37:04.773681+00	3983	OC6 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
2985	2019-01-22 15:37:04.78081+00	3984	OC6 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
2986	2019-01-22 15:37:04.787707+00	3985	OC6 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
2987	2019-01-22 15:37:04.79463+00	3986	OC6 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
2988	2019-01-22 15:37:04.801139+00	3987	OC6 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
2989	2019-01-22 15:37:04.809005+00	3988	OC6 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
2990	2019-01-22 15:37:04.815254+00	3989	OC6 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
2991	2019-01-22 15:37:04.82281+00	3990	OC6 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
2992	2019-01-22 15:37:04.830041+00	3991	OC6 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
2993	2019-01-22 15:37:04.837103+00	3992	OC6 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
2994	2019-01-22 15:37:04.844705+00	3993	OC6 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
2995	2019-01-22 15:37:04.851523+00	3994	OC6 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
2996	2019-01-22 15:37:04.859602+00	3995	OC6 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
2997	2019-01-22 15:37:04.865881+00	3996	OC6 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
2998	2019-01-22 15:39:29.69027+00	4071	SC52 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
2999	2019-01-22 15:39:29.697174+00	4072	SC52 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
3000	2019-01-22 15:39:29.704617+00	4073	SC52 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
3001	2019-01-22 15:39:29.711108+00	4074	SC52 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
3002	2019-01-22 15:39:29.717743+00	4075	SC52 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
3003	2019-01-22 15:39:29.724563+00	4076	SC52 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
3004	2019-01-22 15:39:29.730908+00	4077	SC52 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
3005	2019-01-22 15:39:29.737441+00	4078	SC52 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
3006	2019-01-22 15:39:29.743946+00	4079	SC52 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
3007	2019-01-22 15:39:29.750782+00	4080	SC52 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
3008	2019-01-22 15:39:29.757322+00	4081	SC52 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
3009	2019-01-22 15:39:29.763404+00	4082	SC52 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
3010	2019-01-22 15:39:29.769755+00	4083	SC52 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
3011	2019-01-22 15:39:29.776335+00	4084	SC52 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
3012	2019-01-22 15:39:29.792128+00	4085	SC52 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
3013	2019-01-22 15:39:29.802962+00	4086	SC52 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
3014	2019-01-22 15:39:29.822399+00	4087	SC52 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
3015	2019-01-22 15:39:29.850465+00	4088	SC52 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
3016	2019-01-22 15:39:29.87678+00	4089	SC52 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
3017	2019-01-22 15:39:29.883465+00	4090	SC52 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
3018	2019-01-22 15:39:29.890375+00	4091	SC52 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
3019	2019-01-22 15:39:29.898048+00	4092	SC52 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
3020	2019-01-22 15:39:29.904982+00	4093	SC52 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
3021	2019-01-22 15:39:29.911508+00	4094	SC52 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
3022	2019-01-22 15:39:29.917827+00	4095	SC52 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
3023	2019-01-22 15:39:29.925935+00	4096	SC52 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
3024	2019-01-22 15:39:29.933109+00	4097	SC52 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
3025	2019-01-22 15:39:29.939521+00	4098	SC52 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
3026	2019-01-22 15:39:29.945875+00	4099	SC52 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
3027	2019-01-22 15:39:29.951734+00	4100	SC52 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
3028	2019-01-22 15:39:29.958387+00	4101	SC52 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
3029	2019-01-22 15:39:29.964839+00	4102	SC52 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
3030	2019-01-22 15:39:29.970612+00	4103	SC52 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
3031	2019-01-22 15:39:29.977294+00	4104	SC52 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
3032	2019-01-22 15:39:29.984069+00	4105	SC52 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
3033	2019-01-22 15:39:29.990156+00	4106	SC52 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
3034	2019-01-22 15:39:29.996208+00	4107	SC52 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
3035	2019-01-22 15:39:30.002792+00	4108	SC52 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
3036	2019-01-22 15:39:30.009289+00	4109	SC52 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
3037	2019-01-22 15:39:30.016512+00	4110	SC52 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
3038	2019-01-22 15:39:30.024287+00	4111	SC52 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
3039	2019-01-22 15:39:30.031291+00	4112	SC52 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
3040	2019-01-22 15:39:30.037773+00	4113	SC52 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
3041	2019-01-22 15:39:30.044266+00	4114	SC52 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
3042	2019-01-22 15:39:30.051755+00	4115	SC52 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
3043	2019-01-22 15:39:30.05902+00	4116	SC52 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
3044	2019-01-22 15:39:30.065523+00	4117	SC52 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
3045	2019-01-22 15:39:30.071919+00	4118	SC52 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
3046	2019-01-22 15:39:30.078256+00	4119	SC52 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
3047	2019-01-22 15:39:30.085304+00	4120	SC52 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
3048	2019-01-22 15:39:30.091917+00	4121	SC52 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
3049	2019-01-22 15:39:30.098503+00	4122	SC52 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
3050	2019-01-22 15:39:30.104958+00	4123	SC52 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
3051	2019-01-22 15:39:30.111017+00	4124	SC52 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
3052	2019-01-22 15:39:30.118153+00	4125	SC52 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
3053	2019-01-22 15:39:30.125066+00	4126	SC52 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
3054	2019-01-22 15:39:30.132047+00	4127	SC52 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
3055	2019-01-22 15:39:30.138712+00	4128	SC52 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
3056	2019-01-22 15:39:30.145699+00	4129	SC52 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
3057	2019-01-22 15:39:30.152089+00	4130	SC52 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
3058	2019-01-22 15:39:30.158493+00	4131	SC52 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
3059	2019-01-22 15:39:30.164703+00	4132	SC52 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
3060	2019-01-22 15:39:30.170998+00	4133	SC52 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
3061	2019-01-22 15:39:30.177428+00	4134	SC52 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
3062	2019-01-22 15:39:30.184175+00	4135	SC52 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
3063	2019-01-22 15:39:30.190895+00	4136	SC52 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
3064	2019-01-22 15:39:30.197386+00	4137	SC52 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
3065	2019-01-22 15:39:30.203858+00	4138	SC52 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
3066	2019-01-22 15:39:30.211901+00	4139	SC52 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
3067	2019-01-22 15:39:30.218567+00	4140	SC52 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
3068	2019-01-22 15:39:30.225001+00	4141	SC52 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
3069	2019-01-22 15:39:30.23217+00	4142	SC52 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
3070	2019-01-22 15:39:30.238618+00	4143	SC52 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
3071	2019-01-22 15:39:30.245156+00	4144	SC52 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
3072	2019-01-22 15:42:23.080603+00	4219	CCB25 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
3073	2019-01-22 15:42:23.087585+00	4220	CCB25 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
3074	2019-01-22 15:42:23.09501+00	4221	CCB25 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
3075	2019-01-22 15:42:23.10134+00	4222	CCB25 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
3076	2019-01-22 15:42:23.107642+00	4223	CCB25 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
3077	2019-01-22 15:42:23.114578+00	4224	CCB25 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
3078	2019-01-22 15:42:23.121516+00	4225	CCB25 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
3079	2019-01-22 15:42:23.128297+00	4226	CCB25 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
3080	2019-01-22 15:42:23.134279+00	4227	CCB25 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
3081	2019-01-22 15:42:23.140454+00	4228	CCB25 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
3082	2019-01-22 15:42:23.146345+00	4229	CCB25 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
3083	2019-01-22 15:42:23.153935+00	4230	CCB25 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
3084	2019-01-22 15:42:23.16318+00	4231	CCB25 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
3085	2019-01-22 15:42:23.171423+00	4232	CCB25 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
3086	2019-01-22 15:42:23.180032+00	4233	CCB25 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
3087	2019-01-22 15:42:23.18697+00	4234	CCB25 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
3088	2019-01-22 15:42:23.193637+00	4235	CCB25 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
3089	2019-01-22 15:42:23.199841+00	4236	CCB25 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
3090	2019-01-22 15:42:23.205651+00	4237	CCB25 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
3091	2019-01-22 15:42:23.218153+00	4238	CCB25 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
3092	2019-01-22 15:42:23.227538+00	4239	CCB25 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
3093	2019-01-22 15:42:23.234202+00	4240	CCB25 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
3094	2019-01-22 15:42:23.240552+00	4241	CCB25 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
3095	2019-01-22 15:42:23.246414+00	4242	CCB25 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
3096	2019-01-22 15:42:23.252788+00	4243	CCB25 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
3097	2019-01-22 15:42:23.26044+00	4244	CCB25 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
3098	2019-01-22 15:42:23.267762+00	4245	CCB25 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
3099	2019-01-22 15:42:23.275073+00	4246	CCB25 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
3100	2019-01-22 15:42:23.282444+00	4247	CCB25 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
3101	2019-01-22 15:42:23.28902+00	4248	CCB25 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
3102	2019-01-22 15:42:23.295244+00	4249	CCB25 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
3103	2019-01-22 15:42:23.301741+00	4250	CCB25 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
3104	2019-01-22 15:42:23.308241+00	4251	CCB25 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
3105	2019-01-22 15:42:23.315729+00	4252	CCB25 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
3106	2019-01-22 15:42:23.322605+00	4253	CCB25 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
3107	2019-01-22 15:42:23.329688+00	4254	CCB25 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
3108	2019-01-22 15:42:23.336373+00	4255	CCB25 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
3109	2019-01-22 15:42:23.343104+00	4256	CCB25 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
3110	2019-01-22 15:42:23.349247+00	4257	CCB25 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
3111	2019-01-22 15:42:23.355259+00	4258	CCB25 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
3112	2019-01-22 15:42:23.365211+00	4259	CCB25 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
3113	2019-01-22 15:42:23.372435+00	4260	CCB25 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
3114	2019-01-22 15:42:23.379523+00	4261	CCB25 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
3115	2019-01-22 15:42:23.386053+00	4262	CCB25 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
3116	2019-01-22 15:42:23.392676+00	4263	CCB25 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
3117	2019-01-22 15:42:23.400215+00	4264	CCB25 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
3118	2019-01-22 15:42:23.406099+00	4265	CCB25 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
3119	2019-01-22 15:42:23.415662+00	4266	CCB25 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
3120	2019-01-22 15:42:23.422484+00	4267	CCB25 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
3121	2019-01-22 15:42:23.430477+00	4268	CCB25 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
3122	2019-01-22 15:42:23.437129+00	4269	CCB25 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
3123	2019-01-22 15:42:23.443768+00	4270	CCB25 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
3124	2019-01-22 15:42:23.45034+00	4271	CCB25 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
3125	2019-01-22 15:42:23.456374+00	4272	CCB25 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
3126	2019-01-22 15:42:23.464987+00	4273	CCB25 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
3127	2019-01-22 15:42:23.472764+00	4274	CCB25 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
3128	2019-01-22 15:42:23.480931+00	4275	CCB25 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
3129	2019-01-22 15:42:23.487677+00	4276	CCB25 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
3130	2019-01-22 15:42:23.494819+00	4277	CCB25 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
3131	2019-01-22 15:42:23.503322+00	4278	CCB25 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
3132	2019-01-22 15:42:23.510131+00	4279	CCB25 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
3133	2019-01-22 15:42:23.516661+00	4280	CCB25 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
3134	2019-01-22 15:42:23.522816+00	4281	CCB25 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
3135	2019-01-22 15:42:23.52922+00	4282	CCB25 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
3136	2019-01-22 15:42:23.535381+00	4283	CCB25 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
3137	2019-01-22 15:42:23.541407+00	4284	CCB25 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
3138	2019-01-22 15:42:23.548223+00	4285	CCB25 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
3139	2019-01-22 15:42:23.554757+00	4286	CCB25 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
3140	2019-01-22 15:42:23.562048+00	4287	CCB25 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
3141	2019-01-22 15:42:23.569008+00	4288	CCB25 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
3142	2019-01-22 15:42:23.576814+00	4289	CCB25 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
3143	2019-01-22 15:42:23.584204+00	4290	CCB25 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
3144	2019-01-22 15:42:23.590641+00	4291	CCB25 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
3145	2019-01-22 15:42:23.59672+00	4292	CCB25 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
3146	2019-01-22 15:44:13.621478+00	4367	N2 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
3147	2019-01-22 15:44:13.632097+00	4368	N2 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
3148	2019-01-22 15:44:13.642851+00	4369	N2 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
3149	2019-01-22 15:44:13.654412+00	4370	N2 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
3150	2019-01-22 15:44:13.664821+00	4371	N2 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
3151	2019-01-22 15:44:13.674784+00	4372	N2 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
3152	2019-01-22 15:44:13.683472+00	4373	N2 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
3153	2019-01-22 15:44:13.69257+00	4374	N2 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
3154	2019-01-22 15:44:13.70157+00	4375	N2 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
3155	2019-01-22 15:44:13.712537+00	4376	N2 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
3156	2019-01-22 15:44:13.722027+00	4377	N2 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
3157	2019-01-22 15:44:13.732969+00	4378	N2 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
3158	2019-01-22 15:44:13.747401+00	4379	N2 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
3159	2019-01-22 15:44:13.758945+00	4380	N2 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
3160	2019-01-22 15:44:13.76992+00	4381	N2 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
3161	2019-01-22 15:44:13.781826+00	4382	N2 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
3162	2019-01-22 15:44:13.791447+00	4383	N2 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
3163	2019-01-22 15:44:13.801702+00	4384	N2 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
3164	2019-01-22 15:44:13.811824+00	4385	N2 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
3165	2019-01-22 15:44:13.820742+00	4386	N2 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
3166	2019-01-22 15:44:13.830745+00	4387	N2 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
3167	2019-01-22 15:44:13.840231+00	4388	N2 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
3168	2019-01-22 15:44:13.84916+00	4389	N2 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
3169	2019-01-22 15:44:13.8599+00	4390	N2 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
3170	2019-01-22 15:44:13.868883+00	4391	N2 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
3171	2019-01-22 15:44:13.878347+00	4392	N2 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
3172	2019-01-22 15:44:13.888589+00	4393	N2 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
3173	2019-01-22 15:44:13.898287+00	4394	N2 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
3174	2019-01-22 15:44:13.907323+00	4395	N2 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
3175	2019-01-22 15:44:13.916525+00	4396	N2 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
3176	2019-01-22 15:44:13.926156+00	4397	N2 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
3177	2019-01-22 15:44:13.935957+00	4398	N2 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
3178	2019-01-22 15:44:13.945949+00	4399	N2 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
3179	2019-01-22 15:44:13.955484+00	4400	N2 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
3180	2019-01-22 15:44:13.964927+00	4401	N2 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
3181	2019-01-22 15:44:13.975763+00	4402	N2 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
3182	2019-01-22 15:44:13.985642+00	4403	N2 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
3183	2019-01-22 15:44:13.995613+00	4404	N2 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
3184	2019-01-22 15:44:14.004336+00	4405	N2 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
3185	2019-01-22 15:44:14.014844+00	4406	N2 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
3186	2019-01-22 15:44:14.024204+00	4407	N2 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
3187	2019-01-22 15:44:14.034349+00	4408	N2 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
3188	2019-01-22 15:44:14.045625+00	4409	N2 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
3189	2019-01-22 15:44:14.055407+00	4410	N2 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
3190	2019-01-22 15:44:14.065492+00	4411	N2 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
3191	2019-01-22 15:44:14.074289+00	4412	N2 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
3192	2019-01-22 15:44:14.08241+00	4413	N2 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
3193	2019-01-22 15:44:14.090989+00	4414	N2 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
3194	2019-01-22 15:44:14.100303+00	4415	N2 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
3195	2019-01-22 15:44:14.111178+00	4416	N2 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
3196	2019-01-22 15:44:14.121921+00	4417	N2 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
3197	2019-01-22 15:44:14.130387+00	4418	N2 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
3198	2019-01-22 15:44:14.138186+00	4419	N2 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
3199	2019-01-22 15:44:14.145728+00	4420	N2 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
3200	2019-01-22 15:44:14.154121+00	4421	N2 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
3201	2019-01-22 15:44:14.162951+00	4422	N2 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
3202	2019-01-22 15:44:14.170447+00	4423	N2 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
3203	2019-01-22 15:44:14.177932+00	4424	N2 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
3204	2019-01-22 15:44:14.184262+00	4425	N2 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
3205	2019-01-22 15:44:14.190503+00	4426	N2 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
3206	2019-01-22 15:44:14.197144+00	4427	N2 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
3207	2019-01-22 15:44:14.203074+00	4428	N2 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
3208	2019-01-22 15:44:14.210253+00	4429	N2 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
3209	2019-01-22 15:44:14.227825+00	4430	N2 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
3210	2019-01-22 15:44:14.250459+00	4431	N2 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
3211	2019-01-22 15:44:14.259682+00	4432	N2 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
3212	2019-01-22 15:44:14.280363+00	4433	N2 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
3213	2019-01-22 15:44:14.314464+00	4434	N2 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
3214	2019-01-22 15:44:14.320647+00	4435	N2 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
3215	2019-01-22 15:44:14.327698+00	4436	N2 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
3216	2019-01-22 15:44:14.334375+00	4437	N2 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
3217	2019-01-22 15:44:14.341828+00	4438	N2 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
3218	2019-01-22 15:44:14.348868+00	4439	N2 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
3219	2019-01-22 15:44:14.355557+00	4440	N2 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
3220	2019-01-22 15:46:24.88065+00	4515	N4 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
3221	2019-01-22 15:46:24.887969+00	4516	N4 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
3222	2019-01-22 15:46:24.895544+00	4517	N4 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
3223	2019-01-22 15:46:24.902691+00	4518	N4 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
3224	2019-01-22 15:46:24.909714+00	4519	N4 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
3225	2019-01-22 15:46:24.917161+00	4520	N4 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
3226	2019-01-22 15:46:24.924205+00	4521	N4 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
3227	2019-01-22 15:46:24.932844+00	4522	N4 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
3228	2019-01-22 15:46:24.939792+00	4523	N4 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
3229	2019-01-22 15:46:24.946621+00	4524	N4 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
3230	2019-01-22 15:46:24.953273+00	4525	N4 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
3231	2019-01-22 15:46:24.960463+00	4526	N4 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
3232	2019-01-22 15:46:24.968071+00	4527	N4 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
3233	2019-01-22 15:46:24.975213+00	4528	N4 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
3234	2019-01-22 15:46:24.982459+00	4529	N4 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
3235	2019-01-22 15:46:24.989094+00	4530	N4 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
3236	2019-01-22 15:46:24.996147+00	4531	N4 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
3237	2019-01-22 15:46:25.003185+00	4532	N4 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
3238	2019-01-22 15:46:25.010899+00	4533	N4 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
3239	2019-01-22 15:46:25.01847+00	4534	N4 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
3240	2019-01-22 15:46:25.025686+00	4535	N4 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
3241	2019-01-22 15:46:25.032448+00	4536	N4 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
3242	2019-01-22 15:46:25.048545+00	4537	N4 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
3243	2019-01-22 15:46:25.061414+00	4538	N4 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
3244	2019-01-22 15:46:25.077554+00	4539	N4 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
3245	2019-01-22 15:46:25.097058+00	4540	N4 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
3246	2019-01-22 15:46:25.129792+00	4541	N4 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
3247	2019-01-22 15:46:25.13607+00	4542	N4 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
3248	2019-01-22 15:46:25.143287+00	4543	N4 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
3249	2019-01-22 15:46:25.149858+00	4544	N4 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
3250	2019-01-22 15:46:25.155901+00	4545	N4 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
3251	2019-01-22 15:46:25.163467+00	4546	N4 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
3252	2019-01-22 15:46:25.170648+00	4547	N4 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
3253	2019-01-22 15:46:25.177607+00	4548	N4 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
3254	2019-01-22 15:46:25.184108+00	4549	N4 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
3255	2019-01-22 15:46:25.190667+00	4550	N4 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
3256	2019-01-22 15:46:25.197178+00	4551	N4 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
3257	2019-01-22 15:46:25.204361+00	4552	N4 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
3258	2019-01-22 15:46:25.211329+00	4553	N4 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
3259	2019-01-22 15:46:25.218584+00	4554	N4 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
3260	2019-01-22 15:46:25.22567+00	4555	N4 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
3261	2019-01-22 15:46:25.232563+00	4556	N4 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
3262	2019-01-22 15:46:25.240117+00	4557	N4 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
3263	2019-01-22 15:46:25.24782+00	4558	N4 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
3264	2019-01-22 15:46:25.255451+00	4559	N4 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
3265	2019-01-22 15:46:25.263373+00	4560	N4 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
3266	2019-01-22 15:46:25.270529+00	4561	N4 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
3267	2019-01-22 15:46:25.277664+00	4562	N4 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
3268	2019-01-22 15:46:25.285038+00	4563	N4 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
3269	2019-01-22 15:46:25.292183+00	4564	N4 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
3270	2019-01-22 15:46:25.298973+00	4565	N4 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
3271	2019-01-22 15:46:25.305752+00	4566	N4 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
3272	2019-01-22 15:46:25.312971+00	4567	N4 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
3273	2019-01-22 15:46:25.319622+00	4568	N4 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
3274	2019-01-22 15:46:25.326643+00	4569	N4 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
3275	2019-01-22 15:46:25.3332+00	4570	N4 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
3276	2019-01-22 15:46:25.33985+00	4571	N4 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
3277	2019-01-22 15:46:25.346431+00	4572	N4 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
3278	2019-01-22 15:46:25.352966+00	4573	N4 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
3279	2019-01-22 15:46:25.360648+00	4574	N4 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
3280	2019-01-22 15:46:25.367268+00	4575	N4 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
3281	2019-01-22 15:46:25.373772+00	4576	N4 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
3282	2019-01-22 15:46:25.380675+00	4577	N4 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
3283	2019-01-22 15:46:25.387156+00	4578	N4 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
3284	2019-01-22 15:46:25.394097+00	4579	N4 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
3285	2019-01-22 15:46:25.40064+00	4580	N4 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
3286	2019-01-22 15:46:25.407828+00	4581	N4 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
3287	2019-01-22 15:46:25.415251+00	4582	N4 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
3288	2019-01-22 15:46:25.421876+00	4583	N4 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
3289	2019-01-22 15:46:25.428238+00	4584	N4 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
3290	2019-01-22 15:46:25.434511+00	4585	N4 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
3291	2019-01-22 15:46:25.440647+00	4586	N4 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
3292	2019-01-22 15:46:25.447544+00	4587	N4 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
3293	2019-01-22 15:46:25.453872+00	4588	N4 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
3294	2019-01-22 15:48:28.171357+00	4663	N7 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
3295	2019-01-22 15:48:28.179282+00	4664	N7 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
3296	2019-01-22 15:48:28.187539+00	4665	N7 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
3297	2019-01-22 15:48:28.195497+00	4666	N7 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
3298	2019-01-22 15:48:28.203327+00	4667	N7 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
3299	2019-01-22 15:48:28.210934+00	4668	N7 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
3300	2019-01-22 15:48:28.218342+00	4669	N7 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
3301	2019-01-22 15:48:28.226207+00	4670	N7 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
3302	2019-01-22 15:48:28.234464+00	4671	N7 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
3303	2019-01-22 15:48:28.244008+00	4672	N7 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
3304	2019-01-22 15:48:28.253225+00	4673	N7 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
3305	2019-01-22 15:48:28.261124+00	4674	N7 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
3306	2019-01-22 15:48:28.269994+00	4675	N7 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
3307	2019-01-22 15:48:28.277928+00	4676	N7 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
3308	2019-01-22 15:48:28.285768+00	4677	N7 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
3309	2019-01-22 15:48:28.294313+00	4678	N7 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
3310	2019-01-22 15:48:28.302019+00	4679	N7 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
3311	2019-01-22 15:48:28.309814+00	4680	N7 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
3312	2019-01-22 15:48:28.317679+00	4681	N7 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
3313	2019-01-22 15:48:28.327336+00	4682	N7 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
3314	2019-01-22 15:48:28.336091+00	4683	N7 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
3315	2019-01-22 15:48:28.345255+00	4684	N7 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
3316	2019-01-22 15:48:28.353217+00	4685	N7 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
3317	2019-01-22 15:48:28.360217+00	4686	N7 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
3318	2019-01-22 15:48:28.367018+00	4687	N7 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
3319	2019-01-22 15:48:28.373377+00	4688	N7 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
3320	2019-01-22 15:48:28.379589+00	4689	N7 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
3321	2019-01-22 15:48:28.386253+00	4690	N7 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
3322	2019-01-22 15:48:28.392377+00	4691	N7 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
3323	2019-01-22 15:48:28.398689+00	4692	N7 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
3324	2019-01-22 15:48:28.405221+00	4693	N7 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
3325	2019-01-22 15:48:28.411509+00	4694	N7 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
3326	2019-01-22 15:48:28.41798+00	4695	N7 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
3327	2019-01-22 15:48:28.424692+00	4696	N7 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
3328	2019-01-22 15:48:28.431352+00	4697	N7 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
3329	2019-01-22 15:48:28.438411+00	4698	N7 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
3330	2019-01-22 15:48:28.444998+00	4699	N7 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
3331	2019-01-22 15:48:28.450898+00	4700	N7 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
3332	2019-01-22 15:48:28.457037+00	4701	N7 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
3333	2019-01-22 15:48:28.463733+00	4702	N7 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
3334	2019-01-22 15:48:28.470132+00	4703	N7 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
3335	2019-01-22 15:48:28.476982+00	4704	N7 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
3336	2019-01-22 15:48:28.483709+00	4705	N7 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
3337	2019-01-22 15:48:28.498778+00	4706	N7 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
3338	2019-01-22 15:48:28.508982+00	4707	N7 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
3339	2019-01-22 15:48:28.527806+00	4708	N7 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
3340	2019-01-22 15:48:28.54861+00	4709	N7 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
3341	2019-01-22 15:48:28.580949+00	4710	N7 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
3342	2019-01-22 15:48:28.587466+00	4711	N7 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
3343	2019-01-22 15:48:28.595564+00	4712	N7 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
3344	2019-01-22 15:48:28.601739+00	4713	N7 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
3345	2019-01-22 15:48:28.608272+00	4714	N7 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
3346	2019-01-22 15:48:28.615088+00	4715	N7 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
3347	2019-01-22 15:48:28.621748+00	4716	N7 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
3348	2019-01-22 15:48:28.628202+00	4717	N7 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
3349	2019-01-22 15:48:28.634804+00	4718	N7 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
3350	2019-01-22 15:48:28.641421+00	4719	N7 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
3351	2019-01-22 15:48:28.650355+00	4720	N7 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
3352	2019-01-22 15:48:28.657675+00	4721	N7 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
3353	2019-01-22 15:48:28.663929+00	4722	N7 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
3354	2019-01-22 15:48:28.669743+00	4723	N7 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
3355	2019-01-22 15:48:28.676293+00	4724	N7 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
3356	2019-01-22 15:48:28.682337+00	4725	N7 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
3357	2019-01-22 15:48:28.68895+00	4726	N7 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
3358	2019-01-22 15:48:28.696164+00	4727	N7 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
3359	2019-01-22 15:48:28.702432+00	4728	N7 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
3360	2019-01-22 15:48:28.70865+00	4729	N7 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
3361	2019-01-22 15:48:28.714754+00	4730	N7 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
3362	2019-01-22 15:48:28.721126+00	4731	N7 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
3363	2019-01-22 15:48:28.727456+00	4732	N7 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
3364	2019-01-22 15:48:28.733575+00	4733	N7 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
3365	2019-01-22 15:48:28.73995+00	4734	N7 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
3366	2019-01-22 15:48:28.746991+00	4735	N7 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
3367	2019-01-22 15:48:28.753222+00	4736	N7 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
3368	2019-01-22 15:50:33.77648+00	4811	N9 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
3369	2019-01-22 15:50:33.78349+00	4812	N9 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
3370	2019-01-22 15:50:33.789753+00	4813	N9 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
3371	2019-01-22 15:50:33.795837+00	4814	N9 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
3372	2019-01-22 15:50:33.802585+00	4815	N9 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
3373	2019-01-22 15:50:33.808737+00	4816	N9 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
3374	2019-01-22 15:50:33.814841+00	4817	N9 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
3375	2019-01-22 15:50:33.822024+00	4818	N9 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
3376	2019-01-22 15:50:33.828859+00	4819	N9 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
3377	2019-01-22 15:50:33.836271+00	4820	N9 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
3378	2019-01-22 15:50:33.843066+00	4821	N9 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
3379	2019-01-22 15:50:33.84953+00	4822	N9 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
3380	2019-01-22 15:50:33.855994+00	4823	N9 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
3381	2019-01-22 15:50:33.863104+00	4824	N9 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
3382	2019-01-22 15:50:33.870041+00	4825	N9 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
3383	2019-01-22 15:50:33.877793+00	4826	N9 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
3384	2019-01-22 15:50:33.885337+00	4827	N9 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
3385	2019-01-22 15:50:33.892853+00	4828	N9 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
3386	2019-01-22 15:50:33.900106+00	4829	N9 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
3387	2019-01-22 15:50:33.9074+00	4830	N9 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
3388	2019-01-22 15:50:33.914461+00	4831	N9 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
3389	2019-01-22 15:50:33.923502+00	4832	N9 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
3390	2019-01-22 15:50:33.932697+00	4833	N9 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
3391	2019-01-22 15:50:33.940822+00	4834	N9 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
3392	2019-01-22 15:50:33.947698+00	4835	N9 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
3393	2019-01-22 15:50:33.953927+00	4836	N9 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
3394	2019-01-22 15:50:33.960022+00	4837	N9 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
3395	2019-01-22 15:50:33.966208+00	4838	N9 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
3396	2019-01-22 15:50:33.972293+00	4839	N9 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
3397	2019-01-22 15:50:33.978507+00	4840	N9 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
3398	2019-01-22 15:50:33.98481+00	4841	N9 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
3399	2019-01-22 15:50:33.99105+00	4842	N9 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
3400	2019-01-22 15:50:33.997527+00	4843	N9 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
3401	2019-01-22 15:50:34.004225+00	4844	N9 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
3402	2019-01-22 15:50:34.010406+00	4845	N9 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
3403	2019-01-22 15:50:34.016367+00	4846	N9 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
3404	2019-01-22 15:50:34.022263+00	4847	N9 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
3405	2019-01-22 15:50:34.029265+00	4848	N9 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
3406	2019-01-22 15:50:34.036423+00	4849	N9 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
3407	2019-01-22 15:50:34.042733+00	4850	N9 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
3408	2019-01-22 15:50:34.051334+00	4851	N9 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
3409	2019-01-22 15:50:34.058202+00	4852	N9 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
3410	2019-01-22 15:50:34.064714+00	4853	N9 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
3411	2019-01-22 15:50:34.072055+00	4854	N9 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
3412	2019-01-22 15:50:34.080215+00	4855	N9 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
3413	2019-01-22 15:50:34.087316+00	4856	N9 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
3414	2019-01-22 15:50:34.094032+00	4857	N9 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
3415	2019-01-22 15:50:34.100823+00	4858	N9 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
3416	2019-01-22 15:50:34.107209+00	4859	N9 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
3417	2019-01-22 15:50:34.11349+00	4860	N9 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
3418	2019-01-22 15:50:34.119754+00	4861	N9 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
3419	2019-01-22 15:50:34.126505+00	4862	N9 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
3420	2019-01-22 15:50:34.132619+00	4863	N9 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
3421	2019-01-22 15:50:34.138605+00	4864	N9 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
3422	2019-01-22 15:50:34.14477+00	4865	N9 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
3423	2019-01-22 15:50:34.15157+00	4866	N9 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
3424	2019-01-22 15:50:34.157912+00	4867	N9 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
3425	2019-01-22 15:50:34.16442+00	4868	N9 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
3426	2019-01-22 15:50:34.170518+00	4869	N9 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
3427	2019-01-22 15:50:34.176741+00	4870	N9 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
3428	2019-01-22 15:50:34.182961+00	4871	N9 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
3429	2019-01-22 15:50:34.189826+00	4872	N9 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
3430	2019-01-22 15:50:34.196372+00	4873	N9 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
3431	2019-01-22 15:50:34.202743+00	4874	N9 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
3432	2019-01-22 15:50:34.209464+00	4875	N9 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
3433	2019-01-22 15:50:34.21542+00	4876	N9 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
3434	2019-01-22 15:50:34.22351+00	4877	N9 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
3435	2019-01-22 15:50:34.229613+00	4878	N9 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
3436	2019-01-22 15:50:34.23637+00	4879	N9 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
3437	2019-01-22 15:50:34.242551+00	4880	N9 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
3438	2019-01-22 15:50:34.249229+00	4881	N9 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
3439	2019-01-22 15:50:34.256626+00	4882	N9 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
3440	2019-01-22 15:50:34.263331+00	4883	N9 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
3441	2019-01-22 15:50:34.26977+00	4884	N9 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
3442	2019-01-22 15:52:13.208903+00	4959	CCB4 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
3443	2019-01-22 15:52:13.215677+00	4960	CCB4 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
3444	2019-01-22 15:52:13.222361+00	4961	CCB4 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
3445	2019-01-22 15:52:13.228955+00	4962	CCB4 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
3446	2019-01-22 15:52:13.235882+00	4963	CCB4 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
3447	2019-01-22 15:52:13.242706+00	4964	CCB4 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
3448	2019-01-22 15:52:13.249155+00	4965	CCB4 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
3449	2019-01-22 15:52:13.25585+00	4966	CCB4 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
3450	2019-01-22 15:52:13.262983+00	4967	CCB4 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
3451	2019-01-22 15:52:13.269651+00	4968	CCB4 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
3452	2019-01-22 15:52:13.275754+00	4969	CCB4 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
3453	2019-01-22 15:52:13.281953+00	4970	CCB4 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
3454	2019-01-22 15:52:13.288425+00	4971	CCB4 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
3455	2019-01-22 15:52:13.295266+00	4972	CCB4 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
3456	2019-01-22 15:52:13.302616+00	4973	CCB4 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
3457	2019-01-22 15:52:13.308988+00	4974	CCB4 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
3458	2019-01-22 15:52:13.3153+00	4975	CCB4 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
3459	2019-01-22 15:52:13.321875+00	4976	CCB4 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
3460	2019-01-22 15:52:13.328131+00	4977	CCB4 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
3461	2019-01-22 15:52:13.334468+00	4978	CCB4 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
3462	2019-01-22 15:52:13.340732+00	4979	CCB4 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
3463	2019-01-22 15:52:13.346565+00	4980	CCB4 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
3464	2019-01-22 15:52:13.35324+00	4981	CCB4 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
3465	2019-01-22 15:52:13.359403+00	4982	CCB4 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
3466	2019-01-22 15:52:13.365348+00	4983	CCB4 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
3467	2019-01-22 15:52:13.37151+00	4984	CCB4 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
3468	2019-01-22 15:52:13.377155+00	4985	CCB4 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
3469	2019-01-22 15:52:13.383996+00	4986	CCB4 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
3470	2019-01-22 15:52:13.390173+00	4987	CCB4 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
3471	2019-01-22 15:52:13.397213+00	4988	CCB4 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
3472	2019-01-22 15:52:13.404347+00	4989	CCB4 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
3473	2019-01-22 15:52:13.411045+00	4990	CCB4 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
3474	2019-01-22 15:52:13.417418+00	4991	CCB4 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
3475	2019-01-22 15:52:13.423903+00	4992	CCB4 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
3476	2019-01-22 15:52:13.430743+00	4993	CCB4 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
3477	2019-01-22 15:52:13.438976+00	4994	CCB4 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
3478	2019-01-22 15:52:13.446605+00	4995	CCB4 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
3479	2019-01-22 15:52:13.45539+00	4996	CCB4 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
3480	2019-01-22 15:52:13.462672+00	4997	CCB4 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
3481	2019-01-22 15:52:13.470312+00	4998	CCB4 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
3482	2019-01-22 15:52:13.477091+00	4999	CCB4 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
3483	2019-01-22 15:52:13.483771+00	5000	CCB4 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
3484	2019-01-22 15:52:13.496976+00	5001	CCB4 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
3485	2019-01-22 15:52:13.506517+00	5002	CCB4 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
3486	2019-01-22 15:52:13.517444+00	5003	CCB4 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
3487	2019-01-22 15:52:13.536335+00	5004	CCB4 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
3488	2019-01-22 15:52:13.557341+00	5005	CCB4 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
3489	2019-01-22 15:52:13.590318+00	5006	CCB4 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
3490	2019-01-22 15:52:13.597635+00	5007	CCB4 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
3491	2019-01-22 15:52:13.604967+00	5008	CCB4 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
3492	2019-01-22 15:52:13.612058+00	5009	CCB4 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
3493	2019-01-22 15:52:13.618562+00	5010	CCB4 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
3494	2019-01-22 15:52:13.624625+00	5011	CCB4 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
3495	2019-01-22 15:52:13.630782+00	5012	CCB4 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
3496	2019-01-22 15:52:13.637158+00	5013	CCB4 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
3497	2019-01-22 15:52:13.643492+00	5014	CCB4 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
3498	2019-01-22 15:52:13.649829+00	5015	CCB4 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
3499	2019-01-22 15:52:13.656154+00	5016	CCB4 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
3500	2019-01-22 15:52:13.663331+00	5017	CCB4 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
3501	2019-01-22 15:52:13.670471+00	5018	CCB4 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
3502	2019-01-22 15:52:13.676972+00	5019	CCB4 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
3503	2019-01-22 15:52:13.683176+00	5020	CCB4 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
3504	2019-01-22 15:52:13.690344+00	5021	CCB4 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
3505	2019-01-22 15:52:13.696983+00	5022	CCB4 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
3506	2019-01-22 15:52:13.704494+00	5023	CCB4 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
3507	2019-01-22 15:52:13.711575+00	5024	CCB4 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
3508	2019-01-22 15:52:13.718529+00	5025	CCB4 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
3509	2019-01-22 15:52:13.724975+00	5026	CCB4 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
3510	2019-01-22 15:52:13.731291+00	5027	CCB4 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
3511	2019-01-22 15:52:13.738955+00	5028	CCB4 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
3512	2019-01-22 15:52:13.745535+00	5029	CCB4 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
3513	2019-01-22 15:52:13.752489+00	5030	CCB4 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
3514	2019-01-22 15:52:13.758963+00	5031	CCB4 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
3515	2019-01-22 15:52:13.766114+00	5032	CCB4 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
3516	2019-01-22 15:54:25.359122+00	5107	CCB11 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
3517	2019-01-22 15:54:25.367357+00	5108	CCB11 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
3518	2019-01-22 15:54:25.374159+00	5109	CCB11 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
3519	2019-01-22 15:54:25.381072+00	5110	CCB11 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
3520	2019-01-22 15:54:25.388463+00	5111	CCB11 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
3521	2019-01-22 15:54:25.395367+00	5112	CCB11 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
3522	2019-01-22 15:54:25.401773+00	5113	CCB11 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
3523	2019-01-22 15:54:25.408509+00	5114	CCB11 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
3524	2019-01-22 15:54:25.415561+00	5115	CCB11 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
3525	2019-01-22 15:54:25.423191+00	5116	CCB11 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
3526	2019-01-22 15:54:25.43049+00	5117	CCB11 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
3527	2019-01-22 15:54:25.437737+00	5118	CCB11 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
3528	2019-01-22 15:54:25.444242+00	5119	CCB11 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
3529	2019-01-22 15:54:25.450582+00	5120	CCB11 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
3530	2019-01-22 15:54:25.45679+00	5121	CCB11 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
3531	2019-01-22 15:54:25.463111+00	5122	CCB11 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
3532	2019-01-22 15:54:25.469867+00	5123	CCB11 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
3533	2019-01-22 15:54:25.477411+00	5124	CCB11 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
3534	2019-01-22 15:54:25.484719+00	5125	CCB11 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
3535	2019-01-22 15:54:25.492442+00	5126	CCB11 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
3536	2019-01-22 15:54:25.499243+00	5127	CCB11 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
3537	2019-01-22 15:54:25.505687+00	5128	CCB11 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
3538	2019-01-22 15:54:25.511774+00	5129	CCB11 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
3539	2019-01-22 15:54:25.519008+00	5130	CCB11 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
3540	2019-01-22 15:54:25.526354+00	5131	CCB11 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
3541	2019-01-22 15:54:25.53297+00	5132	CCB11 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
3542	2019-01-22 15:54:25.53984+00	5133	CCB11 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
3543	2019-01-22 15:54:25.546059+00	5134	CCB11 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
3544	2019-01-22 15:54:25.552179+00	5135	CCB11 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
3545	2019-01-22 15:54:25.558421+00	5136	CCB11 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
3546	2019-01-22 15:54:25.565829+00	5137	CCB11 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
3547	2019-01-22 15:54:25.575949+00	5138	CCB11 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
3548	2019-01-22 15:54:25.59005+00	5139	CCB11 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
3549	2019-01-22 15:54:25.600888+00	5140	CCB11 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
3550	2019-01-22 15:54:25.62002+00	5141	CCB11 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
3551	2019-01-22 15:54:25.640337+00	5142	CCB11 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
3552	2019-01-22 15:54:25.675717+00	5143	CCB11 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
3553	2019-01-22 15:54:25.683348+00	5144	CCB11 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
3554	2019-01-22 15:54:25.690603+00	5145	CCB11 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
3555	2019-01-22 15:54:25.697287+00	5146	CCB11 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
3556	2019-01-22 15:54:25.703693+00	5147	CCB11 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
3557	2019-01-22 15:54:25.710212+00	5148	CCB11 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
3558	2019-01-22 15:54:25.716772+00	5149	CCB11 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
3559	2019-01-22 15:54:25.724849+00	5150	CCB11 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
3560	2019-01-22 15:54:25.732039+00	5151	CCB11 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
3561	2019-01-22 15:54:25.739195+00	5152	CCB11 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
3562	2019-01-22 15:54:25.745964+00	5153	CCB11 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
3563	2019-01-22 15:54:25.75217+00	5154	CCB11 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
3564	2019-01-22 15:54:25.758465+00	5155	CCB11 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
3565	2019-01-22 15:54:25.764729+00	5156	CCB11 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
3566	2019-01-22 15:54:25.77183+00	5157	CCB11 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
3567	2019-01-22 15:54:25.778835+00	5158	CCB11 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
3568	2019-01-22 15:54:25.785321+00	5159	CCB11 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
3569	2019-01-22 15:54:25.792393+00	5160	CCB11 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
3570	2019-01-22 15:54:25.799196+00	5161	CCB11 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
3571	2019-01-22 15:54:25.805354+00	5162	CCB11 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
3572	2019-01-22 15:54:25.811594+00	5163	CCB11 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
3573	2019-01-22 15:54:25.818922+00	5164	CCB11 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
3574	2019-01-22 15:54:25.827773+00	5165	CCB11 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
3575	2019-01-22 15:54:25.836437+00	5166	CCB11 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
3576	2019-01-22 15:54:25.845899+00	5167	CCB11 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
3577	2019-01-22 15:54:25.853659+00	5168	CCB11 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
3578	2019-01-22 15:54:25.861178+00	5169	CCB11 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
3579	2019-01-22 15:54:25.871103+00	5170	CCB11 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
3580	2019-01-22 15:54:25.879943+00	5171	CCB11 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
3581	2019-01-22 15:54:25.888028+00	5172	CCB11 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
3582	2019-01-22 15:54:25.895956+00	5173	CCB11 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
3583	2019-01-22 15:54:25.902995+00	5174	CCB11 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
3584	2019-01-22 15:54:25.909622+00	5175	CCB11 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
3585	2019-01-22 15:54:25.916812+00	5176	CCB11 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
3586	2019-01-22 15:54:25.924472+00	5177	CCB11 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
3587	2019-01-22 15:54:25.931704+00	5178	CCB11 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
3588	2019-01-22 15:54:25.938725+00	5179	CCB11 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
3589	2019-01-22 15:54:25.945757+00	5180	CCB11 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
3590	2019-01-22 15:57:01.796899+00	5255	Unlisted - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
3591	2019-01-22 15:57:01.804186+00	5256	Unlisted - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
3592	2019-01-22 15:57:01.8111+00	5257	Unlisted - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
3593	2019-01-22 15:57:01.817098+00	5258	Unlisted - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
3594	2019-01-22 15:57:01.824618+00	5259	Unlisted - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
3595	2019-01-22 15:57:01.833274+00	5260	Unlisted - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
3596	2019-01-22 15:57:01.840008+00	5261	Unlisted - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
3597	2019-01-22 15:57:01.846684+00	5262	Unlisted - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
3598	2019-01-22 15:57:01.853489+00	5263	Unlisted - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
3599	2019-01-22 15:57:01.861147+00	5264	Unlisted - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
3600	2019-01-22 15:57:01.867916+00	5265	Unlisted - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
3601	2019-01-22 15:57:01.875315+00	5266	Unlisted - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
3602	2019-01-22 15:57:01.882795+00	5267	Unlisted - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
3603	2019-01-22 15:57:01.889452+00	5268	Unlisted - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
3604	2019-01-22 15:57:01.895897+00	5269	Unlisted - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
3605	2019-01-22 15:57:01.902574+00	5270	Unlisted - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
3606	2019-01-22 15:57:01.908996+00	5271	Unlisted - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
3607	2019-01-22 15:57:01.916127+00	5272	Unlisted - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
3608	2019-01-22 15:57:01.922992+00	5273	Unlisted - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
3609	2019-01-22 15:57:01.930166+00	5274	Unlisted - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
3610	2019-01-22 15:57:01.936366+00	5275	Unlisted - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
3611	2019-01-22 15:57:01.942125+00	5276	Unlisted - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
3612	2019-01-22 15:57:01.949005+00	5277	Unlisted - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
3613	2019-01-22 15:57:01.956152+00	5278	Unlisted - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
3614	2019-01-22 15:57:01.962787+00	5279	Unlisted - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
3615	2019-01-22 15:57:01.968917+00	5280	Unlisted - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
3616	2019-01-22 15:57:01.976118+00	5281	Unlisted - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
3617	2019-01-22 15:57:01.983334+00	5282	Unlisted - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
3618	2019-01-22 15:57:01.989881+00	5283	Unlisted - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
3619	2019-01-22 15:57:01.995958+00	5284	Unlisted - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
3620	2019-01-22 15:57:02.002061+00	5285	Unlisted - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
3621	2019-01-22 15:57:02.007951+00	5286	Unlisted - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
3622	2019-01-22 15:57:02.014691+00	5287	Unlisted - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
3623	2019-01-22 15:57:02.021256+00	5288	Unlisted - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
3624	2019-01-22 15:57:02.027864+00	5289	Unlisted - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
3625	2019-01-22 15:57:02.033707+00	5290	Unlisted - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
3626	2019-01-22 15:57:02.040675+00	5291	Unlisted - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
3627	2019-01-22 15:57:02.047024+00	5292	Unlisted - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
3628	2019-01-22 15:57:02.054114+00	5293	Unlisted - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
3629	2019-01-22 15:57:02.061891+00	5294	Unlisted - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
3630	2019-01-22 15:57:02.068521+00	5295	Unlisted - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
3631	2019-01-22 15:57:02.075179+00	5296	Unlisted - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
3632	2019-01-22 15:57:02.082071+00	5297	Unlisted - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
3633	2019-01-22 15:57:02.090121+00	5298	Unlisted - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
3634	2019-01-22 15:57:02.0976+00	5299	Unlisted - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
3635	2019-01-22 15:57:02.104756+00	5300	Unlisted - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
3636	2019-01-22 15:57:02.111073+00	5301	Unlisted - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
3637	2019-01-22 15:57:02.117388+00	5302	Unlisted - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
3638	2019-01-22 15:57:02.124149+00	5303	Unlisted - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
3639	2019-01-22 15:57:02.131958+00	5304	Unlisted - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
3640	2019-01-22 15:57:02.138832+00	5305	Unlisted - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
3641	2019-01-22 15:57:02.145214+00	5306	Unlisted - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
3642	2019-01-22 15:57:02.151462+00	5307	Unlisted - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
3643	2019-01-22 15:57:02.157924+00	5308	Unlisted - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
3644	2019-01-22 15:57:02.165208+00	5309	Unlisted - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
3645	2019-01-22 15:57:02.171985+00	5310	Unlisted - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
3646	2019-01-22 15:57:02.178518+00	5311	Unlisted - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
3647	2019-01-22 15:57:02.184677+00	5312	Unlisted - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
3648	2019-01-22 15:57:02.190939+00	5313	Unlisted - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
3649	2019-01-22 15:57:02.197498+00	5314	Unlisted - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
3650	2019-01-22 15:57:02.205115+00	5315	Unlisted - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
3651	2019-01-22 15:57:02.211357+00	5316	Unlisted - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
3652	2019-01-22 15:57:02.21762+00	5317	Unlisted - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
3653	2019-01-22 15:57:02.224499+00	5318	Unlisted - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
3654	2019-01-22 15:57:02.231074+00	5319	Unlisted - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
3655	2019-01-22 15:57:02.238128+00	5320	Unlisted - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
3656	2019-01-22 15:57:02.244202+00	5321	Unlisted - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
3657	2019-01-22 15:57:02.250547+00	5322	Unlisted - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
3658	2019-01-22 15:57:02.257834+00	5323	Unlisted - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
3659	2019-01-22 15:57:02.264281+00	5324	Unlisted - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
3660	2019-01-22 15:57:02.271168+00	5325	Unlisted - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
3661	2019-01-22 15:57:02.277424+00	5326	Unlisted - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
3662	2019-01-22 15:57:02.284706+00	5327	Unlisted - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
3663	2019-01-22 15:57:02.291923+00	5328	Unlisted - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
3664	2019-01-22 16:00:24.871613+00	5403	OC6 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
3665	2019-01-22 16:00:24.878476+00	5404	OC6 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
3666	2019-01-22 16:00:24.88507+00	5405	OC6 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
3667	2019-01-22 16:00:24.891955+00	5406	OC6 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
3668	2019-01-22 16:00:24.89815+00	5407	OC6 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
3669	2019-01-22 16:00:24.904264+00	5408	OC6 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
3670	2019-01-22 16:00:24.910292+00	5409	OC6 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
3671	2019-01-22 16:00:24.916583+00	5410	OC6 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
3672	2019-01-22 16:00:24.923019+00	5411	OC6 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
3673	2019-01-22 16:00:24.92959+00	5412	OC6 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
3674	2019-01-22 16:00:24.936423+00	5413	OC6 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
3675	2019-01-22 16:00:24.94353+00	5414	OC6 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
3676	2019-01-22 16:00:24.949967+00	5415	OC6 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
3677	2019-01-22 16:00:24.956258+00	5416	OC6 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
3678	2019-01-22 16:00:24.963415+00	5417	OC6 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
3679	2019-01-22 16:00:24.982419+00	5418	OC6 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
3680	2019-01-22 16:00:25.001242+00	5419	OC6 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
3681	2019-01-22 16:00:25.025863+00	5420	OC6 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
3682	2019-01-22 16:00:25.055895+00	5421	OC6 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
3683	2019-01-22 16:00:25.062527+00	5422	OC6 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
3684	2019-01-22 16:00:25.069183+00	5423	OC6 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
3685	2019-01-22 16:00:25.075675+00	5424	OC6 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
3686	2019-01-22 16:00:25.082621+00	5425	OC6 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
3687	2019-01-22 16:00:25.088996+00	5426	OC6 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
3688	2019-01-22 16:00:25.095917+00	5427	OC6 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
3689	2019-01-22 16:00:25.102429+00	5428	OC6 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
3690	2019-01-22 16:00:25.109297+00	5429	OC6 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
3691	2019-01-22 16:00:25.11644+00	5430	OC6 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
3692	2019-01-22 16:00:25.123116+00	5431	OC6 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
3693	2019-01-22 16:00:25.129979+00	5432	OC6 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
3694	2019-01-22 16:00:25.136423+00	5433	OC6 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
3695	2019-01-22 16:00:25.142966+00	5434	OC6 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
3696	2019-01-22 16:00:25.14993+00	5435	OC6 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
3697	2019-01-22 16:00:25.156371+00	5436	OC6 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
3698	2019-01-22 16:00:25.162759+00	5437	OC6 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
3699	2019-01-22 16:00:25.169181+00	5438	OC6 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
3700	2019-01-22 16:00:25.176496+00	5439	OC6 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
3701	2019-01-22 16:00:25.183043+00	5440	OC6 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
3702	2019-01-22 16:00:25.189141+00	5441	OC6 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
3703	2019-01-22 16:00:25.196037+00	5442	OC6 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
3704	2019-01-22 16:00:25.202422+00	5443	OC6 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
3705	2019-01-22 16:00:25.20879+00	5444	OC6 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
3706	2019-01-22 16:00:25.215358+00	5445	OC6 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
3707	2019-01-22 16:00:25.222627+00	5446	OC6 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
3708	2019-01-22 16:00:25.230154+00	5447	OC6 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
3709	2019-01-22 16:00:25.237205+00	5448	OC6 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
3710	2019-01-22 16:00:25.2441+00	5449	OC6 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
3711	2019-01-22 16:00:25.250802+00	5450	OC6 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
3712	2019-01-22 16:00:25.257213+00	5451	OC6 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
3713	2019-01-22 16:00:25.264093+00	5452	OC6 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
3714	2019-01-22 16:00:25.270321+00	5453	OC6 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
3715	2019-01-22 16:00:25.276678+00	5454	OC6 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
3716	2019-01-22 16:00:25.283502+00	5455	OC6 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
3717	2019-01-22 16:00:25.290342+00	5456	OC6 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
3718	2019-01-22 16:00:25.297371+00	5457	OC6 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
3719	2019-01-22 16:00:25.303692+00	5458	OC6 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
3720	2019-01-22 16:00:25.310423+00	5459	OC6 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
3721	2019-01-22 16:00:25.317134+00	5460	OC6 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
3722	2019-01-22 16:00:25.324048+00	5461	OC6 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
3723	2019-01-22 16:00:25.33084+00	5462	OC6 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
3724	2019-01-22 16:00:25.337162+00	5463	OC6 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
3725	2019-01-22 16:00:25.343772+00	5464	OC6 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
3726	2019-01-22 16:00:25.350151+00	5465	OC6 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
3727	2019-01-22 16:00:25.356863+00	5466	OC6 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
3728	2019-01-22 16:00:25.363467+00	5467	OC6 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
3729	2019-01-22 16:00:25.369831+00	5468	OC6 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
3730	2019-01-22 16:00:25.376773+00	5469	OC6 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
3731	2019-01-22 16:00:25.383757+00	5470	OC6 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
3732	2019-01-22 16:00:25.390856+00	5471	OC6 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
3733	2019-01-22 16:00:25.397787+00	5472	OC6 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
3734	2019-01-22 16:00:25.404903+00	5473	OC6 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
3735	2019-01-22 16:00:25.412261+00	5474	OC6 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
3736	2019-01-22 16:00:25.419285+00	5475	OC6 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
3737	2019-01-22 16:00:25.425897+00	5476	OC6 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
3738	2019-01-22 16:02:26.583509+00	5551	OC5 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
3739	2019-01-22 16:02:26.595563+00	5552	OC5 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
3740	2019-01-22 16:02:26.606094+00	5553	OC5 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
3741	2019-01-22 16:02:26.616049+00	5554	OC5 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
3742	2019-01-22 16:02:26.626434+00	5555	OC5 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
3743	2019-01-22 16:02:26.63763+00	5556	OC5 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
3744	2019-01-22 16:02:26.647141+00	5557	OC5 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
3745	2019-01-22 16:02:26.657348+00	5558	OC5 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
3746	2019-01-22 16:02:26.667827+00	5559	OC5 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
3747	2019-01-22 16:02:26.67632+00	5560	OC5 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
3748	2019-01-22 16:02:26.684677+00	5561	OC5 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
3749	2019-01-22 16:02:26.693202+00	5562	OC5 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
3750	2019-01-22 16:02:26.701045+00	5563	OC5 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
3751	2019-01-22 16:02:26.709668+00	5564	OC5 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
3752	2019-01-22 16:02:26.718059+00	5565	OC5 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
3753	2019-01-22 16:02:26.726809+00	5566	OC5 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
3754	2019-01-22 16:02:26.736302+00	5567	OC5 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
3755	2019-01-22 16:02:26.744185+00	5568	OC5 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
3756	2019-01-22 16:02:26.75338+00	5569	OC5 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
3757	2019-01-22 16:02:26.761478+00	5570	OC5 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
3758	2019-01-22 16:02:26.77096+00	5571	OC5 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
3759	2019-01-22 16:02:26.77907+00	5572	OC5 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
3760	2019-01-22 16:02:26.788207+00	5573	OC5 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
3761	2019-01-22 16:02:26.796015+00	5574	OC5 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
3762	2019-01-22 16:02:26.804745+00	5575	OC5 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
3763	2019-01-22 16:02:26.81252+00	5576	OC5 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
3764	2019-01-22 16:02:26.820044+00	5577	OC5 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
3765	2019-01-22 16:02:26.82767+00	5578	OC5 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
3766	2019-01-22 16:02:26.836153+00	5579	OC5 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
3767	2019-01-22 16:02:26.844238+00	5580	OC5 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
3768	2019-01-22 16:02:26.852556+00	5581	OC5 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
3769	2019-01-22 16:02:26.860759+00	5582	OC5 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
3770	2019-01-22 16:02:26.869411+00	5583	OC5 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
3771	2019-01-22 16:02:26.877568+00	5584	OC5 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
3772	2019-01-22 16:02:26.885242+00	5585	OC5 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
3773	2019-01-22 16:02:26.893066+00	5586	OC5 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
3774	2019-01-22 16:02:26.903367+00	5587	OC5 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
3775	2019-01-22 16:02:26.911862+00	5588	OC5 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
3776	2019-01-22 16:02:26.921463+00	5589	OC5 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
3777	2019-01-22 16:02:26.929788+00	5590	OC5 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
3778	2019-01-22 16:02:26.93886+00	5591	OC5 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
3779	2019-01-22 16:02:26.948552+00	5592	OC5 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
3780	2019-01-22 16:02:26.957048+00	5593	OC5 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
3781	2019-01-22 16:02:26.965702+00	5594	OC5 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
3782	2019-01-22 16:02:26.97362+00	5595	OC5 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
3783	2019-01-22 16:02:26.981512+00	5596	OC5 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
3784	2019-01-22 16:02:26.989924+00	5597	OC5 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
3785	2019-01-22 16:02:26.998056+00	5598	OC5 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
3786	2019-01-22 16:02:27.006199+00	5599	OC5 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
3787	2019-01-22 16:02:27.014529+00	5600	OC5 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
3788	2019-01-22 16:02:27.025231+00	5601	OC5 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
3789	2019-01-22 16:02:27.035115+00	5602	OC5 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
3790	2019-01-22 16:02:27.043458+00	5603	OC5 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
3791	2019-01-22 16:02:27.053367+00	5604	OC5 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
3792	2019-01-22 16:02:27.061674+00	5605	OC5 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
3793	2019-01-22 16:02:27.071033+00	5606	OC5 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
3794	2019-01-22 16:02:27.08004+00	5607	OC5 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
3795	2019-01-22 16:02:27.089955+00	5608	OC5 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
3796	2019-01-22 16:02:27.099418+00	5609	OC5 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
3797	2019-01-22 16:02:27.107887+00	5610	OC5 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
3798	2019-01-22 16:02:27.115898+00	5611	OC5 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
3799	2019-01-22 16:02:27.124305+00	5612	OC5 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
3800	2019-01-22 16:02:27.132971+00	5613	OC5 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
3801	2019-01-22 16:02:27.141068+00	5614	OC5 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
3802	2019-01-22 16:02:27.15032+00	5615	OC5 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
3803	2019-01-22 16:02:27.159009+00	5616	OC5 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
3804	2019-01-22 16:02:27.168264+00	5617	OC5 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
3805	2019-01-22 16:02:27.176563+00	5618	OC5 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
3806	2019-01-22 16:02:27.18462+00	5619	OC5 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
3807	2019-01-22 16:02:27.193224+00	5620	OC5 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
3808	2019-01-22 16:02:27.202237+00	5621	OC5 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
3809	2019-01-22 16:02:27.211166+00	5622	OC5 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
3810	2019-01-22 16:02:27.220098+00	5623	OC5 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
3811	2019-01-22 16:02:27.22882+00	5624	OC5 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
3812	2019-01-22 16:06:34.191473+00	5626	V24 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
3813	2019-01-22 16:09:48.3117+00	5628	N2 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
3814	2019-01-22 16:12:20.946287+00	5703	N4 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
3815	2019-01-22 16:12:20.979074+00	5704	N4 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
3816	2019-01-22 16:12:21.00034+00	5705	N4 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
3817	2019-01-22 16:12:21.00685+00	5706	N4 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
3818	2019-01-22 16:12:21.013466+00	5707	N4 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
3819	2019-01-22 16:12:21.020097+00	5708	N4 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
3820	2019-01-22 16:12:21.026345+00	5709	N4 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
3821	2019-01-22 16:12:21.033161+00	5710	N4 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
3822	2019-01-22 16:12:21.039312+00	5711	N4 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
3823	2019-01-22 16:12:21.046074+00	5712	N4 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
3824	2019-01-22 16:12:21.052759+00	5713	N4 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
3825	2019-01-22 16:12:21.058891+00	5714	N4 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
3826	2019-01-22 16:12:21.065145+00	5715	N4 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
3827	2019-01-22 16:12:21.071864+00	5716	N4 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
3828	2019-01-22 16:12:21.079337+00	5717	N4 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
3829	2019-01-22 16:12:21.088088+00	5718	N4 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
3830	2019-01-22 16:12:21.096799+00	5719	N4 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
3831	2019-01-22 16:12:21.105982+00	5720	N4 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
3832	2019-01-22 16:12:21.112995+00	5721	N4 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
3833	2019-01-22 16:12:21.123056+00	5722	N4 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
3834	2019-01-22 16:12:21.130943+00	5723	N4 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
3835	2019-01-22 16:12:21.13883+00	5724	N4 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
3836	2019-01-22 16:12:21.146226+00	5725	N4 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
3837	2019-01-22 16:12:21.153224+00	5726	N4 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
3838	2019-01-22 16:12:21.160121+00	5727	N4 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
3839	2019-01-22 16:12:21.166575+00	5728	N4 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
3840	2019-01-22 16:12:21.17362+00	5729	N4 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
3841	2019-01-22 16:12:21.181026+00	5730	N4 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
3842	2019-01-22 16:12:21.187526+00	5731	N4 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
3843	2019-01-22 16:12:21.19442+00	5732	N4 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
3844	2019-01-22 16:12:21.200929+00	5733	N4 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
3845	2019-01-22 16:12:21.206969+00	5734	N4 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
3846	2019-01-22 16:12:21.214083+00	5735	N4 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
3847	2019-01-22 16:12:21.222736+00	5736	N4 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
3848	2019-01-22 16:12:21.230316+00	5737	N4 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
3849	2019-01-22 16:12:21.237134+00	5738	N4 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
3850	2019-01-22 16:12:21.244525+00	5739	N4 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
3851	2019-01-22 16:12:21.250855+00	5740	N4 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
3852	2019-01-22 16:12:21.256818+00	5741	N4 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
3853	2019-01-22 16:12:21.263217+00	5742	N4 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
3854	2019-01-22 16:12:21.270073+00	5743	N4 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
3855	2019-01-22 16:12:21.276962+00	5744	N4 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
3856	2019-01-22 16:12:21.283855+00	5745	N4 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
3857	2019-01-22 16:12:21.290261+00	5746	N4 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
3858	2019-01-22 16:12:21.296933+00	5747	N4 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
3859	2019-01-22 16:12:21.303334+00	5748	N4 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
3860	2019-01-22 16:12:21.310188+00	5749	N4 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
3861	2019-01-22 16:12:21.316814+00	5750	N4 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
3862	2019-01-22 16:12:21.323636+00	5751	N4 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
3863	2019-01-22 16:12:21.331854+00	5752	N4 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
3864	2019-01-22 16:12:21.340573+00	5753	N4 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
3865	2019-01-22 16:12:21.348342+00	5754	N4 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
3866	2019-01-22 16:12:21.354417+00	5755	N4 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
3867	2019-01-22 16:12:21.36091+00	5756	N4 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
3868	2019-01-22 16:12:21.367942+00	5757	N4 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
3869	2019-01-22 16:12:21.374786+00	5758	N4 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
3870	2019-01-22 16:12:21.383275+00	5759	N4 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
3871	2019-01-22 16:12:21.390364+00	5760	N4 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
3872	2019-01-22 16:12:21.398068+00	5761	N4 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
3873	2019-01-22 16:12:21.404535+00	5762	N4 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
3874	2019-01-22 16:12:21.410971+00	5763	N4 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
3875	2019-01-22 16:12:21.418674+00	5764	N4 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
3876	2019-01-22 16:12:21.426638+00	5765	N4 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
3877	2019-01-22 16:12:21.433554+00	5766	N4 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
3878	2019-01-22 16:12:21.440005+00	5767	N4 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
3879	2019-01-22 16:12:21.446726+00	5768	N4 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
3880	2019-01-22 16:12:21.453037+00	5769	N4 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
3881	2019-01-22 16:12:21.459299+00	5770	N4 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
3882	2019-01-22 16:12:21.465976+00	5771	N4 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
3883	2019-01-22 16:12:21.472466+00	5772	N4 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
3884	2019-01-22 16:12:21.478593+00	5773	N4 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
3885	2019-01-22 16:12:21.485607+00	5774	N4 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
3886	2019-01-22 16:12:21.491562+00	5775	N4 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
3887	2019-01-22 16:12:21.498547+00	5776	N4 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
3888	2019-01-22 16:14:35.803153+00	5851	N7 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
3889	2019-01-22 16:14:35.80966+00	5852	N7 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
3890	2019-01-22 16:14:35.815932+00	5853	N7 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
3891	2019-01-22 16:14:35.822023+00	5854	N7 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
3892	2019-01-22 16:14:35.827991+00	5855	N7 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
3893	2019-01-22 16:14:35.834961+00	5856	N7 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
3894	2019-01-22 16:14:35.843333+00	5857	N7 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
3895	2019-01-22 16:14:35.850522+00	5858	N7 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
3896	2019-01-22 16:14:35.857046+00	5859	N7 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
3897	2019-01-22 16:14:35.864004+00	5860	N7 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
3898	2019-01-22 16:14:35.870652+00	5861	N7 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
3899	2019-01-22 16:14:35.876595+00	5862	N7 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
3900	2019-01-22 16:14:35.883007+00	5863	N7 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
3901	2019-01-22 16:14:35.890533+00	5864	N7 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
3902	2019-01-22 16:14:35.897239+00	5865	N7 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
3903	2019-01-22 16:14:35.903849+00	5866	N7 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
3904	2019-01-22 16:14:35.910107+00	5867	N7 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
3905	2019-01-22 16:14:35.916355+00	5868	N7 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
3906	2019-01-22 16:14:35.923023+00	5869	N7 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
3907	2019-01-22 16:14:35.928975+00	5870	N7 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
3908	2019-01-22 16:14:35.936283+00	5871	N7 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
3909	2019-01-22 16:14:35.943222+00	5872	N7 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
3910	2019-01-22 16:14:35.950364+00	5873	N7 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
3911	2019-01-22 16:14:35.956979+00	5874	N7 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
3912	2019-01-22 16:14:35.963334+00	5875	N7 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
3913	2019-01-22 16:14:35.969432+00	5876	N7 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
3914	2019-01-22 16:14:35.975886+00	5877	N7 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
3915	2019-01-22 16:14:35.982797+00	5878	N7 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
3916	2019-01-22 16:14:35.991355+00	5879	N7 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
3917	2019-01-22 16:14:35.998447+00	5880	N7 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
3918	2019-01-22 16:14:36.005143+00	5881	N7 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
3919	2019-01-22 16:14:36.011777+00	5882	N7 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
3920	2019-01-22 16:14:36.018344+00	5883	N7 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
3921	2019-01-22 16:14:36.02439+00	5884	N7 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
3922	2019-01-22 16:14:36.030415+00	5885	N7 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
3923	2019-01-22 16:14:36.037097+00	5886	N7 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
3924	2019-01-22 16:14:36.043836+00	5887	N7 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
3925	2019-01-22 16:14:36.050925+00	5888	N7 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
3926	2019-01-22 16:14:36.059285+00	5889	N7 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
3927	2019-01-22 16:14:36.065478+00	5890	N7 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
3928	2019-01-22 16:14:36.07244+00	5891	N7 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
3929	2019-01-22 16:14:36.078566+00	5892	N7 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
3930	2019-01-22 16:14:36.085946+00	5893	N7 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
3931	2019-01-22 16:14:36.094157+00	5894	N7 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
3932	2019-01-22 16:14:36.101692+00	5895	N7 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
3933	2019-01-22 16:14:36.108433+00	5896	N7 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
3934	2019-01-22 16:14:36.115876+00	5897	N7 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
3935	2019-01-22 16:14:36.122411+00	5898	N7 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
3936	2019-01-22 16:14:36.128528+00	5899	N7 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
3937	2019-01-22 16:14:36.135946+00	5900	N7 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
3938	2019-01-22 16:14:36.142728+00	5901	N7 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
3939	2019-01-22 16:14:36.150246+00	5902	N7 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
3940	2019-01-22 16:14:36.156504+00	5903	N7 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
3941	2019-01-22 16:14:36.162678+00	5904	N7 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
3942	2019-01-22 16:14:36.169162+00	5905	N7 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
3943	2019-01-22 16:14:36.17535+00	5906	N7 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
3944	2019-01-22 16:14:36.181547+00	5907	N7 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
3945	2019-01-22 16:14:36.188339+00	5908	N7 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
3946	2019-01-22 16:14:36.195227+00	5909	N7 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
3947	2019-01-22 16:14:36.202398+00	5910	N7 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
3948	2019-01-22 16:14:36.20883+00	5911	N7 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
3949	2019-01-22 16:14:36.215199+00	5912	N7 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
3950	2019-01-22 16:14:36.22129+00	5913	N7 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
3951	2019-01-22 16:14:36.227617+00	5914	N7 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
3952	2019-01-22 16:14:36.250871+00	5915	N7 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
3953	2019-01-22 16:14:36.267943+00	5916	N7 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
3954	2019-01-22 16:14:36.287895+00	5917	N7 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
3955	2019-01-22 16:14:36.320733+00	5918	N7 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
3956	2019-01-22 16:14:36.327109+00	5919	N7 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
3957	2019-01-22 16:14:36.333634+00	5920	N7 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
3958	2019-01-22 16:14:36.340237+00	5921	N7 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
3959	2019-01-22 16:14:36.346599+00	5922	N7 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
3960	2019-01-22 16:14:36.353295+00	5923	N7 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
3961	2019-01-22 16:14:36.359894+00	5924	N7 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
3962	2019-01-22 16:16:32.362928+00	5999	N9 - 2017-03-12 00:00:00-05:00	1	new through import_export	14	1
3963	2019-01-22 16:16:32.370105+00	6000	N9 - 2017-03-19 00:00:00-04:00	1	new through import_export	14	1
3964	2019-01-22 16:16:32.377+00	6001	N9 - 2017-03-26 00:00:00-04:00	1	new through import_export	14	1
3965	2019-01-22 16:16:32.383654+00	6002	N9 - 2017-03-27 00:00:00-04:00	1	new through import_export	14	1
3966	2019-01-22 16:16:32.390468+00	6003	N9 - 2017-04-02 00:00:00-04:00	1	new through import_export	14	1
3967	2019-01-22 16:16:32.397431+00	6004	N9 - 2017-04-03 00:00:00-04:00	1	new through import_export	14	1
3968	2019-01-22 16:16:32.40453+00	6005	N9 - 2017-04-09 00:00:00-04:00	1	new through import_export	14	1
3969	2019-01-22 16:16:32.411382+00	6006	N9 - 2017-04-10 00:00:00-04:00	1	new through import_export	14	1
3970	2019-01-22 16:16:32.418357+00	6007	N9 - 2017-04-11 00:00:00-04:00	1	new through import_export	14	1
3971	2019-01-22 16:16:32.425946+00	6008	N9 - 2017-04-16 00:00:00-04:00	1	new through import_export	14	1
3972	2019-01-22 16:16:32.432771+00	6009	N9 - 2017-04-17 00:00:00-04:00	1	new through import_export	14	1
3973	2019-01-22 16:16:32.440125+00	6010	N9 - 2017-04-20 00:00:00-04:00	1	new through import_export	14	1
3974	2019-01-22 16:16:32.447996+00	6011	N9 - 2017-04-23 00:00:00-04:00	1	new through import_export	14	1
3975	2019-01-22 16:16:32.455063+00	6012	N9 - 2017-04-24 00:00:00-04:00	1	new through import_export	14	1
3976	2019-01-22 16:16:32.462208+00	6013	N9 - 2017-04-25 00:00:00-04:00	1	new through import_export	14	1
3977	2019-01-22 16:16:32.46896+00	6014	N9 - 2017-04-30 00:00:00-04:00	1	new through import_export	14	1
3978	2019-01-22 16:16:32.476882+00	6015	N9 - 2017-05-01 00:00:00-04:00	1	new through import_export	14	1
3979	2019-01-22 16:16:32.483541+00	6016	N9 - 2017-05-07 00:00:00-04:00	1	new through import_export	14	1
3980	2019-01-22 16:16:32.491523+00	6017	N9 - 2017-05-08 00:00:00-04:00	1	new through import_export	14	1
3981	2019-01-22 16:16:32.498713+00	6018	N9 - 2017-05-09 00:00:00-04:00	1	new through import_export	14	1
3982	2019-01-22 16:16:32.506699+00	6019	N9 - 2017-05-10 00:00:00-04:00	1	new through import_export	14	1
3983	2019-01-22 16:16:32.513285+00	6020	N9 - 2017-05-14 00:00:00-04:00	1	new through import_export	14	1
3984	2019-01-22 16:16:32.520076+00	6021	N9 - 2017-05-15 00:00:00-04:00	1	new through import_export	14	1
3985	2019-01-22 16:16:32.526912+00	6022	N9 - 2017-05-21 00:00:00-04:00	1	new through import_export	14	1
3986	2019-01-22 16:16:32.533524+00	6023	N9 - 2017-05-22 00:00:00-04:00	1	new through import_export	14	1
3987	2019-01-22 16:16:32.539936+00	6024	N9 - 2017-05-28 00:00:00-04:00	1	new through import_export	14	1
3988	2019-01-22 16:16:32.546421+00	6025	N9 - 2017-05-29 00:00:00-04:00	1	new through import_export	14	1
3989	2019-01-22 16:16:32.553019+00	6026	N9 - 2017-05-30 00:00:00-04:00	1	new through import_export	14	1
3990	2019-01-22 16:16:32.559357+00	6027	N9 - 2017-06-02 00:00:00-04:00	1	new through import_export	14	1
3991	2019-01-22 16:16:32.565993+00	6028	N9 - 2017-06-04 00:00:00-04:00	1	new through import_export	14	1
3992	2019-01-22 16:16:32.572238+00	6029	N9 - 2017-06-05 00:00:00-04:00	1	new through import_export	14	1
3993	2019-01-22 16:16:32.578697+00	6030	N9 - 2017-06-09 00:00:00-04:00	1	new through import_export	14	1
3994	2019-01-22 16:16:32.58534+00	6031	N9 - 2017-06-10 00:00:00-04:00	1	new through import_export	14	1
3995	2019-01-22 16:16:32.592187+00	6032	N9 - 2017-06-11 00:00:00-04:00	1	new through import_export	14	1
3996	2019-01-22 16:16:32.598804+00	6033	N9 - 2017-06-12 00:00:00-04:00	1	new through import_export	14	1
3997	2019-01-22 16:16:32.605831+00	6034	N9 - 2017-06-18 00:00:00-04:00	1	new through import_export	14	1
3998	2019-01-22 16:16:32.612395+00	6035	N9 - 2017-06-19 00:00:00-04:00	1	new through import_export	14	1
3999	2019-01-22 16:16:32.618523+00	6036	N9 - 2017-06-22 00:00:00-04:00	1	new through import_export	14	1
4000	2019-01-22 16:16:32.625365+00	6037	N9 - 2017-06-23 00:00:00-04:00	1	new through import_export	14	1
4001	2019-01-22 16:16:32.632073+00	6038	N9 - 2017-06-25 00:00:00-04:00	1	new through import_export	14	1
4002	2019-01-22 16:16:32.638632+00	6039	N9 - 2017-06-26 00:00:00-04:00	1	new through import_export	14	1
4003	2019-01-22 16:16:32.645434+00	6040	N9 - 2017-07-02 00:00:00-04:00	1	new through import_export	14	1
4004	2019-01-22 16:16:32.651423+00	6041	N9 - 2017-07-05 00:00:00-04:00	1	new through import_export	14	1
4005	2019-01-22 16:16:32.657731+00	6042	N9 - 2017-07-09 00:00:00-04:00	1	new through import_export	14	1
4006	2019-01-22 16:16:32.665557+00	6043	N9 - 2017-07-10 00:00:00-04:00	1	new through import_export	14	1
4007	2019-01-22 16:16:32.67211+00	6044	N9 - 2017-07-14 00:00:00-04:00	1	new through import_export	14	1
4008	2019-01-22 16:16:32.678707+00	6045	N9 - 2017-07-16 00:00:00-04:00	1	new through import_export	14	1
4009	2019-01-22 16:16:32.684909+00	6046	N9 - 2017-07-17 00:00:00-04:00	1	new through import_export	14	1
4010	2019-01-22 16:16:32.691545+00	6047	N9 - 2017-07-23 00:00:00-04:00	1	new through import_export	14	1
4011	2019-01-22 16:16:32.698173+00	6048	N9 - 2017-07-24 00:00:00-04:00	1	new through import_export	14	1
4012	2019-01-22 16:16:32.704921+00	6049	N9 - 2017-07-30 00:00:00-04:00	1	new through import_export	14	1
4013	2019-01-22 16:16:32.711228+00	6050	N9 - 2017-07-31 00:00:00-04:00	1	new through import_export	14	1
4014	2019-01-22 16:16:32.717242+00	6051	N9 - 2017-08-06 00:00:00-04:00	1	new through import_export	14	1
4015	2019-01-22 16:16:32.724248+00	6052	N9 - 2017-08-07 00:00:00-04:00	1	new through import_export	14	1
4016	2019-01-22 16:16:32.73013+00	6053	N9 - 2017-08-08 00:00:00-04:00	1	new through import_export	14	1
4017	2019-01-22 16:16:32.736618+00	6054	N9 - 2017-08-13 00:00:00-04:00	1	new through import_export	14	1
4018	2019-01-22 16:16:32.744072+00	6055	N9 - 2017-08-14 00:00:00-04:00	1	new through import_export	14	1
4019	2019-01-22 16:16:32.751563+00	6056	N9 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
4020	2019-01-22 16:16:32.759504+00	6057	N9 - 2017-08-20 00:00:00-04:00	1	new through import_export	14	1
4021	2019-01-22 16:16:32.765864+00	6058	N9 - 2017-08-21 00:00:00-04:00	1	new through import_export	14	1
4022	2019-01-22 16:16:32.772087+00	6059	N9 - 2017-08-22 00:00:00-04:00	1	new through import_export	14	1
4023	2019-01-22 16:16:32.778531+00	6060	N9 - 2017-08-23 00:00:00-04:00	1	new through import_export	14	1
4024	2019-01-22 16:16:32.784636+00	6061	N9 - 2017-09-03 00:00:00-04:00	1	new through import_export	14	1
4025	2019-01-22 16:16:32.79155+00	6062	N9 - 2017-09-04 00:00:00-04:00	1	new through import_export	14	1
4026	2019-01-22 16:16:32.798472+00	6063	N9 - 2017-09-05 00:00:00-04:00	1	new through import_export	14	1
4027	2019-01-22 16:16:32.804559+00	6064	N9 - 2017-09-10 00:00:00-04:00	1	new through import_export	14	1
4028	2019-01-22 16:16:32.812372+00	6065	N9 - 2017-09-11 00:00:00-04:00	1	new through import_export	14	1
4029	2019-01-22 16:16:32.818484+00	6066	N9 - 2017-09-17 00:00:00-04:00	1	new through import_export	14	1
4030	2019-01-22 16:16:32.825922+00	6067	N9 - 2017-09-18 00:00:00-04:00	1	new through import_export	14	1
4031	2019-01-22 16:16:32.832281+00	6068	N9 - 2017-10-02 00:00:00-04:00	1	new through import_export	14	1
4032	2019-01-22 16:16:32.838985+00	6069	N9 - 2017-10-10 00:00:00-04:00	1	new through import_export	14	1
4033	2019-01-22 16:16:32.845343+00	6070	N9 - 2017-10-15 00:00:00-04:00	1	new through import_export	14	1
4034	2019-01-22 16:16:32.851116+00	6071	N9 - 2017-10-16 00:00:00-04:00	1	new through import_export	14	1
4035	2019-01-22 16:16:32.857529+00	6072	N9 - 2018-03-12 00:00:00-04:00	1	new through import_export	14	1
4036	2019-01-22 16:18:46.228619+00	6074	NT3 - 2017-08-17 00:00:00-04:00	1	new through import_export	14	1
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	auth	permission
2	auth	group
3	contenttypes	contenttype
4	sessions	session
5	sites	site
6	admin	logentry
7	account	emailaddress
8	account	emailconfirmation
9	socialaccount	socialaccount
10	socialaccount	socialapp
11	socialaccount	socialtoken
12	users	user
13	stations	station
14	stations	datapoint
15	stations	species
16	esp_instrument	espinstrument
17	esp_instrument	deployment
50	esp_instrument	espdatapoint
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2018-12-17 18:18:58.920065+00
2	contenttypes	0002_remove_content_type_name	2018-12-17 18:18:58.932085+00
3	auth	0001_initial	2018-12-17 18:18:58.983965+00
4	auth	0002_alter_permission_name_max_length	2018-12-17 18:18:58.991621+00
5	auth	0003_alter_user_email_max_length	2018-12-17 18:18:58.999589+00
6	auth	0004_alter_user_username_opts	2018-12-17 18:18:59.007072+00
7	auth	0005_alter_user_last_login_null	2018-12-17 18:18:59.014571+00
8	auth	0006_require_contenttypes_0002	2018-12-17 18:18:59.017525+00
9	auth	0007_alter_validators_add_error_messages	2018-12-17 18:18:59.026562+00
10	auth	0008_alter_user_username_max_length	2018-12-17 18:18:59.035919+00
11	users	0001_initial	2018-12-17 18:18:59.088469+00
12	account	0001_initial	2018-12-17 18:18:59.136591+00
13	account	0002_email_max_length	2018-12-17 18:18:59.148411+00
14	admin	0001_initial	2018-12-17 18:18:59.175066+00
15	admin	0002_logentry_remove_auto_add	2018-12-17 18:18:59.188699+00
16	auth	0009_alter_user_last_name_max_length	2018-12-17 18:18:59.200785+00
17	sessions	0001_initial	2018-12-17 18:18:59.225064+00
18	sites	0001_initial	2018-12-17 18:18:59.235441+00
19	sites	0002_alter_domain_unique	2018-12-17 18:18:59.247957+00
20	sites	0003_set_site_domain_and_name	2018-12-17 18:18:59.268914+00
21	socialaccount	0001_initial	2018-12-17 18:18:59.395288+00
22	socialaccount	0002_token_max_lengths	2018-12-17 18:18:59.428634+00
23	socialaccount	0003_extra_data_default_dict	2018-12-17 18:18:59.441585+00
24	stations	0001_initial	2018-12-17 19:02:24.148875+00
25	stations	0002_station_state	2018-12-17 19:09:12.751149+00
26	stations	0003_auto_20181217_1920	2018-12-17 19:20:48.053975+00
27	stations	0004_auto_20181217_2009	2018-12-17 20:09:25.968178+00
28	stations	0005_datapoint	2018-12-18 18:58:18.621143+00
29	stations	0006_auto_20181218_1924	2018-12-18 19:25:02.757014+00
30	stations	0007_auto_20181218_1936	2018-12-18 19:36:30.653973+00
31	stations	0008_datapoint_species	2018-12-18 19:45:34.673681+00
32	stations	0009_auto_20190107_2011	2019-01-07 20:12:00.636158+00
33	esp_instrument	0001_initial	2019-01-07 20:13:45.703624+00
34	esp_instrument	0002_deployment	2019-01-07 20:35:33.427264+00
67	esp_instrument	0003_espdatapoint	2019-01-18 18:20:50.338421+00
68	esp_instrument	0004_auto_20190117_1852	2019-01-18 18:20:50.345837+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
9lnwxl64yyqelqfmvbw9rh3o25g0u18r	NzljYzMzYTQ4ZGM1MGQ5MzkzNzMzYTExOWRiYjIyNDhhY2ZiNjM4ZDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhOWI0MDJjYmQxZDhlNjE2MmU0ZmEyZmY0ZmI0NDE2YTBiOGQzM2FkIn0=	2018-12-31 19:03:36.781114+00
sozkq1w8jqo4qx7cquekkjbc7ji9ro1p	NzljYzMzYTQ4ZGM1MGQ5MzkzNzMzYTExOWRiYjIyNDhhY2ZiNjM4ZDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhOWI0MDJjYmQxZDhlNjE2MmU0ZmEyZmY0ZmI0NDE2YTBiOGQzM2FkIn0=	2019-01-17 14:09:15.482745+00
zgmddzig1e8k4p88u6a7gv1wg8ppt987	NzljYzMzYTQ4ZGM1MGQ5MzkzNzMzYTExOWRiYjIyNDhhY2ZiNjM4ZDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhOWI0MDJjYmQxZDhlNjE2MmU0ZmEyZmY0ZmI0NDE2YTBiOGQzM2FkIn0=	2019-01-21 20:10:13.712055+00
sjnunndft69585aolj2wkimcj69lt08y	OGI1MTQxZTMzNDg1NDI4MzRkYjFmOTU5NGZkYzdmMGYyMDhiMzNjMTp7Il9zZXNzaW9uX2V4cGlyeSI6MCwiX2F1dGhfdXNlcl9pZCI6IjEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6ImE5YjQwMmNiZDFkOGU2MTYyZTRmYTJmZjRmYjQ0MTZhMGI4ZDMzYWQifQ==	2019-02-01 18:23:04.430194+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.django_site (id, domain, name) FROM stdin;
1	example.com	Starterkit
\.


--
-- Data for Name: esp_instrument_deployment; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.esp_instrument_deployment (id, latitude, longitude, mooring_name, year, espinstrument_id) FROM stdin;
1	43.1768000	-70.4432000	ESP-1	2014	2
2	43.6872000	-69.9768000	ESP-2	2014	3
3	43.8029000	-69.4575000	ESP-3	2014	1
4	43.6874000	-69.9762000	ESP-1	2015	2
5	43.7323000	-69.3548000	ESP-2	2015	1
6	44.1182000	-68.1445000	ESP-3	2015	3
7	43.7034000	-70.0222000	ESP-1	2016	2
8	43.2718000	-70.5336000	ESP-2	2016	1
9	43.7921000	-69.9579000	Bowdoin wetlab	2016	3
10	44.7030000	-66.4860000	ESP-1	2017	3
11	44.3820000	-66.9450000	ESP-2	2017	1
12	44.5680000	-67.2950000	ESP-3	2017	4
13	44.1190000	-68.1450000	ESP-4	2017	2
14	43.1730000	-70.4420000	ESP-1	2018	2
15	43.6870000	-69.9770000	ESP-2	2018	1
16	43.7920000	-69.9580000	Bowdoin wetlab	2018	3
\.


--
-- Data for Name: esp_instrument_espdatapoint; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.esp_instrument_espdatapoint (id, measurement, measurement_date, algal_species, deployment_id) FROM stdin;
46		2014-03-31 04:00:00+00	Alexandrium fundyense	2
47		2014-04-07 04:00:00+00	Alexandrium fundyense	2
48		2014-04-14 04:00:00+00	Alexandrium fundyense	2
49		2014-04-21 04:00:00+00	Alexandrium fundyense	2
50		2014-04-28 04:00:00+00	Alexandrium fundyense	2
51	0	2014-05-02 04:00:00+00	Alexandrium fundyense	2
52		2014-05-03 04:00:00+00	Alexandrium fundyense	2
53		2014-05-04 04:00:00+00	Alexandrium fundyense	2
54	43	2014-05-05 04:00:00+00	Alexandrium fundyense	2
55	0	2014-05-06 04:00:00+00	Alexandrium fundyense	2
56	0	2014-05-07 04:00:00+00	Alexandrium fundyense	2
57		2014-05-08 04:00:00+00	Alexandrium fundyense	2
58	0	2014-05-09 04:00:00+00	Alexandrium fundyense	2
59	0	2014-05-12 04:00:00+00	Alexandrium fundyense	2
60		2014-05-13 04:00:00+00	Alexandrium fundyense	2
61	0	2014-05-14 04:00:00+00	Alexandrium fundyense	2
62		2014-05-15 04:00:00+00	Alexandrium fundyense	2
63	216	2014-05-16 04:00:00+00	Alexandrium fundyense	2
64	262	2014-05-19 04:00:00+00	Alexandrium fundyense	2
65	318	2014-05-20 04:00:00+00	Alexandrium fundyense	2
66	1679	2014-05-21 04:00:00+00	Alexandrium fundyense	2
67	904	2014-05-22 04:00:00+00	Alexandrium fundyense	2
68	425	2014-05-23 04:00:00+00	Alexandrium fundyense	2
69	126	2014-05-26 04:00:00+00	Alexandrium fundyense	2
70		2014-05-27 04:00:00+00	Alexandrium fundyense	2
71	499	2014-05-28 04:00:00+00	Alexandrium fundyense	2
72		2014-05-29 04:00:00+00	Alexandrium fundyense	2
73	392	2014-05-30 04:00:00+00	Alexandrium fundyense	2
74	1131	2014-06-02 04:00:00+00	Alexandrium fundyense	2
75		2014-06-03 04:00:00+00	Alexandrium fundyense	2
76	392	2014-06-04 04:00:00+00	Alexandrium fundyense	2
77		2014-06-05 04:00:00+00	Alexandrium fundyense	2
78	298	2014-06-06 04:00:00+00	Alexandrium fundyense	2
79	1050	2014-06-09 04:00:00+00	Alexandrium fundyense	2
80		2014-06-10 04:00:00+00	Alexandrium fundyense	2
81	772	2014-06-11 04:00:00+00	Alexandrium fundyense	2
82		2014-06-12 04:00:00+00	Alexandrium fundyense	2
83	479	2014-06-13 04:00:00+00	Alexandrium fundyense	2
84	0	2014-06-16 04:00:00+00	Alexandrium fundyense	2
85	236	2014-06-17 04:00:00+00	Alexandrium fundyense	2
86	0	2014-06-18 04:00:00+00	Alexandrium fundyense	2
87	0	2014-06-19 04:00:00+00	Alexandrium fundyense	2
88	0	2014-06-20 04:00:00+00	Alexandrium fundyense	2
89		2014-06-23 04:00:00+00	Alexandrium fundyense	2
90		2014-06-30 04:00:00+00	Alexandrium fundyense	2
1227		2016-03-14 04:00:00+00	Alexandrium fundyense	8
1228		2016-03-15 04:00:00+00	Alexandrium fundyense	8
1229		2016-03-28 04:00:00+00	Alexandrium fundyense	8
1230		2016-03-29 04:00:00+00	Alexandrium fundyense	8
1231		2016-04-11 04:00:00+00	Alexandrium fundyense	8
1232		2016-04-22 04:00:00+00	Alexandrium fundyense	8
1233		2016-04-25 04:00:00+00	Alexandrium fundyense	8
1234		2016-04-26 04:00:00+00	Alexandrium fundyense	8
1235		2016-04-28 04:00:00+00	Alexandrium fundyense	8
1236		2016-04-29 04:00:00+00	Alexandrium fundyense	8
226		2014-03-31 04:00:00+00	Alexandrium fundyense	3
227		2014-04-07 04:00:00+00	Alexandrium fundyense	3
228		2014-04-14 04:00:00+00	Alexandrium fundyense	3
229		2014-04-21 04:00:00+00	Alexandrium fundyense	3
230		2014-04-28 04:00:00+00	Alexandrium fundyense	3
231		2014-05-02 04:00:00+00	Alexandrium fundyense	3
232	0	2014-05-03 04:00:00+00	Alexandrium fundyense	3
233		2014-05-04 04:00:00+00	Alexandrium fundyense	3
234	0	2014-05-05 04:00:00+00	Alexandrium fundyense	3
235	117	2014-05-06 04:00:00+00	Alexandrium fundyense	3
236	150	2014-05-07 04:00:00+00	Alexandrium fundyense	3
237	0	2014-05-08 04:00:00+00	Alexandrium fundyense	3
238	141	2014-05-09 04:00:00+00	Alexandrium fundyense	3
239	0	2014-05-12 04:00:00+00	Alexandrium fundyense	3
240	158	2014-05-13 04:00:00+00	Alexandrium fundyense	3
241	236	2014-05-14 04:00:00+00	Alexandrium fundyense	3
242	0	2014-05-15 04:00:00+00	Alexandrium fundyense	3
243	0	2014-05-16 04:00:00+00	Alexandrium fundyense	3
244	0	2014-05-19 04:00:00+00	Alexandrium fundyense	3
245	262	2014-05-20 04:00:00+00	Alexandrium fundyense	3
246	0	2014-05-21 04:00:00+00	Alexandrium fundyense	3
247	0	2014-05-22 04:00:00+00	Alexandrium fundyense	3
248	327	2014-05-23 04:00:00+00	Alexandrium fundyense	3
249	314	2014-05-26 04:00:00+00	Alexandrium fundyense	3
250	395	2014-05-27 04:00:00+00	Alexandrium fundyense	3
251		2014-05-28 04:00:00+00	Alexandrium fundyense	3
252	324	2014-05-29 04:00:00+00	Alexandrium fundyense	3
253	261	2014-05-30 04:00:00+00	Alexandrium fundyense	3
254	341	2014-06-02 04:00:00+00	Alexandrium fundyense	3
136		2014-03-31 04:00:00+00	Alexandrium fundyense	1
137		2014-04-07 04:00:00+00	Alexandrium fundyense	1
138		2014-04-14 04:00:00+00	Alexandrium fundyense	1
139		2014-04-21 04:00:00+00	Alexandrium fundyense	1
140		2014-04-28 04:00:00+00	Alexandrium fundyense	1
141	0	2014-05-02 04:00:00+00	Alexandrium fundyense	1
142	141	2014-05-03 04:00:00+00	Alexandrium fundyense	1
143	280	2014-05-04 04:00:00+00	Alexandrium fundyense	1
144	359	2014-05-05 04:00:00+00	Alexandrium fundyense	1
145	0	2014-05-06 04:00:00+00	Alexandrium fundyense	1
146	337	2014-05-07 04:00:00+00	Alexandrium fundyense	1
147	398	2014-05-08 04:00:00+00	Alexandrium fundyense	1
148	0	2014-05-09 04:00:00+00	Alexandrium fundyense	1
149	0	2014-05-12 04:00:00+00	Alexandrium fundyense	1
150	422	2014-05-13 04:00:00+00	Alexandrium fundyense	1
151	581	2014-05-14 04:00:00+00	Alexandrium fundyense	1
152	0	2014-05-15 04:00:00+00	Alexandrium fundyense	1
153	0	2014-05-16 04:00:00+00	Alexandrium fundyense	1
154	0	2014-05-19 04:00:00+00	Alexandrium fundyense	1
155	0	2014-05-20 04:00:00+00	Alexandrium fundyense	1
156	1662	2014-05-21 04:00:00+00	Alexandrium fundyense	1
157	1512	2014-05-22 04:00:00+00	Alexandrium fundyense	1
158	1488	2014-05-23 04:00:00+00	Alexandrium fundyense	1
159	0	2014-05-26 04:00:00+00	Alexandrium fundyense	1
160	822	2014-05-27 04:00:00+00	Alexandrium fundyense	1
161	1024	2014-05-28 04:00:00+00	Alexandrium fundyense	1
162		2014-05-29 04:00:00+00	Alexandrium fundyense	1
163	575	2014-05-30 04:00:00+00	Alexandrium fundyense	1
164	1112	2014-06-02 04:00:00+00	Alexandrium fundyense	1
165	895	2014-06-03 04:00:00+00	Alexandrium fundyense	1
166	446	2014-06-04 04:00:00+00	Alexandrium fundyense	1
167	2189	2014-06-05 04:00:00+00	Alexandrium fundyense	1
168	1729	2014-06-06 04:00:00+00	Alexandrium fundyense	1
169	1139	2014-06-09 04:00:00+00	Alexandrium fundyense	1
170	801	2014-06-10 04:00:00+00	Alexandrium fundyense	1
171	611	2014-06-11 04:00:00+00	Alexandrium fundyense	1
172	0	2014-06-12 04:00:00+00	Alexandrium fundyense	1
173	945	2014-06-13 04:00:00+00	Alexandrium fundyense	1
174	0	2014-06-16 04:00:00+00	Alexandrium fundyense	1
175	0	2014-06-17 04:00:00+00	Alexandrium fundyense	1
176		2014-06-18 04:00:00+00	Alexandrium fundyense	1
177		2014-06-19 04:00:00+00	Alexandrium fundyense	1
178		2014-06-20 04:00:00+00	Alexandrium fundyense	1
179		2014-06-23 04:00:00+00	Alexandrium fundyense	1
180		2014-06-30 04:00:00+00	Alexandrium fundyense	1
255	277	2014-06-03 04:00:00+00	Alexandrium fundyense	3
256	540	2014-06-04 04:00:00+00	Alexandrium fundyense	3
257	701	2014-06-05 04:00:00+00	Alexandrium fundyense	3
258	0	2014-06-06 04:00:00+00	Alexandrium fundyense	3
259	407	2014-06-09 04:00:00+00	Alexandrium fundyense	3
260	419	2014-06-10 04:00:00+00	Alexandrium fundyense	3
261	373	2014-06-11 04:00:00+00	Alexandrium fundyense	3
262	1470	2014-06-12 04:00:00+00	Alexandrium fundyense	3
263	766	2014-06-13 04:00:00+00	Alexandrium fundyense	3
264		2014-06-16 04:00:00+00	Alexandrium fundyense	3
265		2014-06-17 04:00:00+00	Alexandrium fundyense	3
266		2014-06-18 04:00:00+00	Alexandrium fundyense	3
267		2014-06-19 04:00:00+00	Alexandrium fundyense	3
268		2014-06-20 04:00:00+00	Alexandrium fundyense	3
269		2014-06-23 04:00:00+00	Alexandrium fundyense	3
270		2014-06-30 04:00:00+00	Alexandrium fundyense	3
1123		2016-03-14 04:00:00+00	Alexandrium fundyense	7
1124		2016-03-15 04:00:00+00	Alexandrium fundyense	7
1125		2016-03-28 04:00:00+00	Alexandrium fundyense	7
1126		2016-03-29 04:00:00+00	Alexandrium fundyense	7
1127		2016-04-11 04:00:00+00	Alexandrium fundyense	7
1128		2016-04-22 04:00:00+00	Alexandrium fundyense	7
1129		2016-04-25 04:00:00+00	Alexandrium fundyense	7
1130		2016-04-26 04:00:00+00	Alexandrium fundyense	7
1131		2016-04-28 04:00:00+00	Alexandrium fundyense	7
1132		2016-04-29 04:00:00+00	Alexandrium fundyense	7
1133		2016-05-02 04:00:00+00	Alexandrium fundyense	7
1134	0	2016-05-03 04:00:00+00	Alexandrium fundyense	7
1135	0	2016-05-05 04:00:00+00	Alexandrium fundyense	7
1136		2016-05-06 04:00:00+00	Alexandrium fundyense	7
1137	74	2016-05-09 04:00:00+00	Alexandrium fundyense	7
1138		2016-05-10 04:00:00+00	Alexandrium fundyense	7
1139	116	2016-05-11 04:00:00+00	Alexandrium fundyense	7
1140		2016-05-12 04:00:00+00	Alexandrium fundyense	7
1141		2016-05-13 04:00:00+00	Alexandrium fundyense	7
1142		2016-05-16 04:00:00+00	Alexandrium fundyense	7
1143	0	2016-05-17 04:00:00+00	Alexandrium fundyense	7
1144	85	2016-05-18 04:00:00+00	Alexandrium fundyense	7
1145		2016-05-19 04:00:00+00	Alexandrium fundyense	7
1146	0	2016-05-20 04:00:00+00	Alexandrium fundyense	7
1147	0	2016-05-23 04:00:00+00	Alexandrium fundyense	7
1148	0	2016-05-24 04:00:00+00	Alexandrium fundyense	7
1149	0	2016-05-25 04:00:00+00	Alexandrium fundyense	7
1150	0	2016-05-26 04:00:00+00	Alexandrium fundyense	7
1151	0	2016-05-27 04:00:00+00	Alexandrium fundyense	7
1152	0	2016-05-30 04:00:00+00	Alexandrium fundyense	7
1153	0	2016-05-31 04:00:00+00	Alexandrium fundyense	7
1154	0	2016-06-01 04:00:00+00	Alexandrium fundyense	7
1155	0	2016-06-02 04:00:00+00	Alexandrium fundyense	7
1156	116	2016-06-03 04:00:00+00	Alexandrium fundyense	7
1157	0	2016-06-06 04:00:00+00	Alexandrium fundyense	7
1158	0	2016-06-07 04:00:00+00	Alexandrium fundyense	7
1159	99	2016-06-08 04:00:00+00	Alexandrium fundyense	7
1160	0	2016-06-09 04:00:00+00	Alexandrium fundyense	7
1161	0	2016-06-10 04:00:00+00	Alexandrium fundyense	7
1162	82	2016-06-13 04:00:00+00	Alexandrium fundyense	7
1163		2016-06-14 04:00:00+00	Alexandrium fundyense	7
1164		2016-06-15 04:00:00+00	Alexandrium fundyense	7
1165		2016-06-16 04:00:00+00	Alexandrium fundyense	7
1166		2016-06-17 04:00:00+00	Alexandrium fundyense	7
1167		2016-06-20 04:00:00+00	Alexandrium fundyense	7
1168		2016-06-21 04:00:00+00	Alexandrium fundyense	7
1169		2016-06-22 04:00:00+00	Alexandrium fundyense	7
1170		2016-06-23 04:00:00+00	Alexandrium fundyense	7
1171		2016-06-24 04:00:00+00	Alexandrium fundyense	7
1172		2016-06-27 04:00:00+00	Alexandrium fundyense	7
1173		2016-07-04 04:00:00+00	Alexandrium fundyense	7
1174		2016-07-11 04:00:00+00	Alexandrium fundyense	7
1237		2016-05-02 04:00:00+00	Alexandrium fundyense	8
1238		2016-05-03 04:00:00+00	Alexandrium fundyense	8
632		2015-05-06 04:00:00+00	Alexandrium fundyense	4
633		2015-05-07 04:00:00+00	Alexandrium fundyense	4
634	0	2015-05-08 04:00:00+00	Alexandrium fundyense	4
635		2015-05-09 04:00:00+00	Alexandrium fundyense	4
636		2015-05-10 04:00:00+00	Alexandrium fundyense	4
637	0	2015-05-11 04:00:00+00	Alexandrium fundyense	4
638	60	2015-05-12 04:00:00+00	Alexandrium fundyense	4
639	0	2015-05-13 04:00:00+00	Alexandrium fundyense	4
640	10	2015-05-14 04:00:00+00	Alexandrium fundyense	4
641	0	2015-05-15 04:00:00+00	Alexandrium fundyense	4
642		2015-05-17 04:00:00+00	Alexandrium fundyense	4
643	0	2015-05-18 04:00:00+00	Alexandrium fundyense	4
644	0	2015-05-19 04:00:00+00	Alexandrium fundyense	4
645	0	2015-05-20 04:00:00+00	Alexandrium fundyense	4
646	35	2015-05-21 04:00:00+00	Alexandrium fundyense	4
647	0	2015-05-22 04:00:00+00	Alexandrium fundyense	4
648		2015-05-24 04:00:00+00	Alexandrium fundyense	4
649	0	2015-05-25 04:00:00+00	Alexandrium fundyense	4
650	0	2015-05-26 04:00:00+00	Alexandrium fundyense	4
651	0	2015-05-27 04:00:00+00	Alexandrium fundyense	4
652	0	2015-05-28 04:00:00+00	Alexandrium fundyense	4
653	145	2015-05-29 04:00:00+00	Alexandrium fundyense	4
654		2015-05-31 04:00:00+00	Alexandrium fundyense	4
655	26	2015-06-01 04:00:00+00	Alexandrium fundyense	4
656	0	2015-06-02 04:00:00+00	Alexandrium fundyense	4
657	0	2015-06-03 04:00:00+00	Alexandrium fundyense	4
658	0	2015-06-04 04:00:00+00	Alexandrium fundyense	4
659	0	2015-06-05 04:00:00+00	Alexandrium fundyense	4
660		2015-06-07 04:00:00+00	Alexandrium fundyense	4
661		2015-06-08 04:00:00+00	Alexandrium fundyense	4
662		2015-06-09 04:00:00+00	Alexandrium fundyense	4
663		2015-06-10 04:00:00+00	Alexandrium fundyense	4
664		2015-06-11 04:00:00+00	Alexandrium fundyense	4
665		2015-06-12 04:00:00+00	Alexandrium fundyense	4
666		2015-06-14 04:00:00+00	Alexandrium fundyense	4
667		2015-06-15 04:00:00+00	Alexandrium fundyense	4
668		2015-06-16 04:00:00+00	Alexandrium fundyense	4
669		2015-06-17 04:00:00+00	Alexandrium fundyense	4
670		2015-06-18 04:00:00+00	Alexandrium fundyense	4
671		2015-06-19 04:00:00+00	Alexandrium fundyense	4
672		2015-06-20 04:00:00+00	Alexandrium fundyense	4
673		2015-06-21 04:00:00+00	Alexandrium fundyense	4
674		2015-06-22 04:00:00+00	Alexandrium fundyense	4
675		2015-06-23 04:00:00+00	Alexandrium fundyense	4
676		2015-06-24 04:00:00+00	Alexandrium fundyense	4
387		2015-04-07 04:00:00+00	Alexandrium fundyense	6
388		2015-04-13 04:00:00+00	Alexandrium fundyense	6
389		2015-04-14 04:00:00+00	Alexandrium fundyense	6
390		2015-04-15 04:00:00+00	Alexandrium fundyense	6
391		2015-04-20 04:00:00+00	Alexandrium fundyense	6
392		2015-04-21 04:00:00+00	Alexandrium fundyense	6
393		2015-04-22 04:00:00+00	Alexandrium fundyense	6
394		2015-04-26 04:00:00+00	Alexandrium fundyense	6
395		2015-04-27 04:00:00+00	Alexandrium fundyense	6
396		2015-04-29 04:00:00+00	Alexandrium fundyense	6
397		2015-05-03 04:00:00+00	Alexandrium fundyense	6
398		2015-05-04 04:00:00+00	Alexandrium fundyense	6
399		2015-05-05 04:00:00+00	Alexandrium fundyense	6
400		2015-05-06 04:00:00+00	Alexandrium fundyense	6
401		2015-05-07 04:00:00+00	Alexandrium fundyense	6
402		2015-05-08 04:00:00+00	Alexandrium fundyense	6
403		2015-05-09 04:00:00+00	Alexandrium fundyense	6
404		2015-05-10 04:00:00+00	Alexandrium fundyense	6
405		2015-05-11 04:00:00+00	Alexandrium fundyense	6
406		2015-05-12 04:00:00+00	Alexandrium fundyense	6
407		2015-05-13 04:00:00+00	Alexandrium fundyense	6
408		2015-05-14 04:00:00+00	Alexandrium fundyense	6
409		2015-05-15 04:00:00+00	Alexandrium fundyense	6
677		2015-06-25 04:00:00+00	Alexandrium fundyense	4
410		2015-05-17 04:00:00+00	Alexandrium fundyense	6
411		2015-05-18 04:00:00+00	Alexandrium fundyense	6
412		2015-05-19 04:00:00+00	Alexandrium fundyense	6
413		2015-05-20 04:00:00+00	Alexandrium fundyense	6
414		2015-05-21 04:00:00+00	Alexandrium fundyense	6
415		2015-05-22 04:00:00+00	Alexandrium fundyense	6
416		2015-05-24 04:00:00+00	Alexandrium fundyense	6
417		2015-05-25 04:00:00+00	Alexandrium fundyense	6
418		2015-05-26 04:00:00+00	Alexandrium fundyense	6
419		2015-05-27 04:00:00+00	Alexandrium fundyense	6
420		2015-05-28 04:00:00+00	Alexandrium fundyense	6
421		2015-05-29 04:00:00+00	Alexandrium fundyense	6
422		2015-05-31 04:00:00+00	Alexandrium fundyense	6
423		2015-06-01 04:00:00+00	Alexandrium fundyense	6
424		2015-06-02 04:00:00+00	Alexandrium fundyense	6
425		2015-06-03 04:00:00+00	Alexandrium fundyense	6
426		2015-06-04 04:00:00+00	Alexandrium fundyense	6
427		2015-06-05 04:00:00+00	Alexandrium fundyense	6
428		2015-06-07 04:00:00+00	Alexandrium fundyense	6
429		2015-06-08 04:00:00+00	Alexandrium fundyense	6
430		2015-06-09 04:00:00+00	Alexandrium fundyense	6
431		2015-06-10 04:00:00+00	Alexandrium fundyense	6
432		2015-06-11 04:00:00+00	Alexandrium fundyense	6
433		2015-06-12 04:00:00+00	Alexandrium fundyense	6
434		2015-06-14 04:00:00+00	Alexandrium fundyense	6
435		2015-06-15 04:00:00+00	Alexandrium fundyense	6
436		2015-06-16 04:00:00+00	Alexandrium fundyense	6
437	68	2015-06-17 04:00:00+00	Alexandrium fundyense	6
438	141	2015-06-18 04:00:00+00	Alexandrium fundyense	6
439	70	2015-06-19 04:00:00+00	Alexandrium fundyense	6
440	0	2015-06-20 04:00:00+00	Alexandrium fundyense	6
441		2015-06-21 04:00:00+00	Alexandrium fundyense	6
442	0	2015-06-22 04:00:00+00	Alexandrium fundyense	6
443	79	2015-06-23 04:00:00+00	Alexandrium fundyense	6
444	100	2015-06-24 04:00:00+00	Alexandrium fundyense	6
445	125	2015-06-25 04:00:00+00	Alexandrium fundyense	6
446	308	2015-06-26 04:00:00+00	Alexandrium fundyense	6
447	626	2015-06-27 04:00:00+00	Alexandrium fundyense	6
448	304	2015-06-28 04:00:00+00	Alexandrium fundyense	6
449	256	2015-06-29 04:00:00+00	Alexandrium fundyense	6
450	392	2015-06-30 04:00:00+00	Alexandrium fundyense	6
451	289	2015-07-01 04:00:00+00	Alexandrium fundyense	6
452	428	2015-07-02 04:00:00+00	Alexandrium fundyense	6
453		2015-07-05 04:00:00+00	Alexandrium fundyense	6
454	290	2015-07-06 04:00:00+00	Alexandrium fundyense	6
455	344	2015-07-07 04:00:00+00	Alexandrium fundyense	6
456	360	2015-07-08 04:00:00+00	Alexandrium fundyense	6
457	330	2015-07-09 04:00:00+00	Alexandrium fundyense	6
458	2432	2015-07-10 04:00:00+00	Alexandrium fundyense	6
459	545	2015-07-11 04:00:00+00	Alexandrium fundyense	6
460	356	2015-07-13 04:00:00+00	Alexandrium fundyense	6
461	2170	2015-07-14 04:00:00+00	Alexandrium fundyense	6
462	1501	2015-07-15 04:00:00+00	Alexandrium fundyense	6
463	294	2015-07-16 04:00:00+00	Alexandrium fundyense	6
464	1179	2015-07-17 04:00:00+00	Alexandrium fundyense	6
465	1368	2015-07-18 04:00:00+00	Alexandrium fundyense	6
466		2015-07-19 04:00:00+00	Alexandrium fundyense	6
467	1211	2015-07-20 04:00:00+00	Alexandrium fundyense	6
468	1285	2015-07-21 04:00:00+00	Alexandrium fundyense	6
469	330	2015-07-22 04:00:00+00	Alexandrium fundyense	6
470	820	2015-07-23 04:00:00+00	Alexandrium fundyense	6
471	409	2015-07-24 04:00:00+00	Alexandrium fundyense	6
472	1051	2015-07-25 04:00:00+00	Alexandrium fundyense	6
473		2015-07-26 04:00:00+00	Alexandrium fundyense	6
474	383	2015-07-27 04:00:00+00	Alexandrium fundyense	6
475	952	2015-07-28 04:00:00+00	Alexandrium fundyense	6
476	798	2015-07-29 04:00:00+00	Alexandrium fundyense	6
477	199	2015-07-30 04:00:00+00	Alexandrium fundyense	6
478	226	2015-07-31 04:00:00+00	Alexandrium fundyense	6
479		2015-08-02 04:00:00+00	Alexandrium fundyense	6
480		2015-08-03 04:00:00+00	Alexandrium fundyense	6
481		2015-08-04 04:00:00+00	Alexandrium fundyense	6
482		2015-08-05 04:00:00+00	Alexandrium fundyense	6
483		2015-08-10 04:00:00+00	Alexandrium fundyense	6
484		2015-08-11 04:00:00+00	Alexandrium fundyense	6
485		2015-08-12 04:00:00+00	Alexandrium fundyense	6
486		2015-08-16 04:00:00+00	Alexandrium fundyense	6
487		2015-08-17 04:00:00+00	Alexandrium fundyense	6
488		2015-08-18 04:00:00+00	Alexandrium fundyense	6
489		2015-08-19 04:00:00+00	Alexandrium fundyense	6
490		2015-08-23 04:00:00+00	Alexandrium fundyense	6
491		2015-08-24 04:00:00+00	Alexandrium fundyense	6
492		2015-08-25 04:00:00+00	Alexandrium fundyense	6
493		2015-08-26 04:00:00+00	Alexandrium fundyense	6
494		2015-08-27 04:00:00+00	Alexandrium fundyense	6
495		2015-08-31 04:00:00+00	Alexandrium fundyense	6
496		2015-09-01 04:00:00+00	Alexandrium fundyense	6
497		2015-09-02 04:00:00+00	Alexandrium fundyense	6
498		2015-09-03 04:00:00+00	Alexandrium fundyense	6
499		2015-09-06 04:00:00+00	Alexandrium fundyense	6
500		2015-09-07 04:00:00+00	Alexandrium fundyense	6
501		2015-09-08 04:00:00+00	Alexandrium fundyense	6
502		2015-09-09 04:00:00+00	Alexandrium fundyense	6
619		2015-04-07 04:00:00+00	Alexandrium fundyense	4
620		2015-04-13 04:00:00+00	Alexandrium fundyense	4
621		2015-04-14 04:00:00+00	Alexandrium fundyense	4
622		2015-04-15 04:00:00+00	Alexandrium fundyense	4
623		2015-04-20 04:00:00+00	Alexandrium fundyense	4
624		2015-04-21 04:00:00+00	Alexandrium fundyense	4
625		2015-04-22 04:00:00+00	Alexandrium fundyense	4
626		2015-04-26 04:00:00+00	Alexandrium fundyense	4
627		2015-04-27 04:00:00+00	Alexandrium fundyense	4
628		2015-04-29 04:00:00+00	Alexandrium fundyense	4
629		2015-05-03 04:00:00+00	Alexandrium fundyense	4
630		2015-05-04 04:00:00+00	Alexandrium fundyense	4
631		2015-05-05 04:00:00+00	Alexandrium fundyense	4
678		2015-06-26 04:00:00+00	Alexandrium fundyense	4
679		2015-06-27 04:00:00+00	Alexandrium fundyense	4
680		2015-06-28 04:00:00+00	Alexandrium fundyense	4
681		2015-06-29 04:00:00+00	Alexandrium fundyense	4
682		2015-06-30 04:00:00+00	Alexandrium fundyense	4
683		2015-07-01 04:00:00+00	Alexandrium fundyense	4
684		2015-07-02 04:00:00+00	Alexandrium fundyense	4
685		2015-07-05 04:00:00+00	Alexandrium fundyense	4
686		2015-07-06 04:00:00+00	Alexandrium fundyense	4
687		2015-07-07 04:00:00+00	Alexandrium fundyense	4
688		2015-07-08 04:00:00+00	Alexandrium fundyense	4
689		2015-07-09 04:00:00+00	Alexandrium fundyense	4
690		2015-07-10 04:00:00+00	Alexandrium fundyense	4
691		2015-07-11 04:00:00+00	Alexandrium fundyense	4
692		2015-07-13 04:00:00+00	Alexandrium fundyense	4
693		2015-07-14 04:00:00+00	Alexandrium fundyense	4
694		2015-07-15 04:00:00+00	Alexandrium fundyense	4
695		2015-07-16 04:00:00+00	Alexandrium fundyense	4
696		2015-07-17 04:00:00+00	Alexandrium fundyense	4
697		2015-07-18 04:00:00+00	Alexandrium fundyense	4
698		2015-07-19 04:00:00+00	Alexandrium fundyense	4
699		2015-07-20 04:00:00+00	Alexandrium fundyense	4
700		2015-07-21 04:00:00+00	Alexandrium fundyense	4
701		2015-07-22 04:00:00+00	Alexandrium fundyense	4
702		2015-07-23 04:00:00+00	Alexandrium fundyense	4
703		2015-07-24 04:00:00+00	Alexandrium fundyense	4
704		2015-07-25 04:00:00+00	Alexandrium fundyense	4
705		2015-07-26 04:00:00+00	Alexandrium fundyense	4
706		2015-07-27 04:00:00+00	Alexandrium fundyense	4
707		2015-07-28 04:00:00+00	Alexandrium fundyense	4
708		2015-07-29 04:00:00+00	Alexandrium fundyense	4
709		2015-07-30 04:00:00+00	Alexandrium fundyense	4
710		2015-07-31 04:00:00+00	Alexandrium fundyense	4
711		2015-08-02 04:00:00+00	Alexandrium fundyense	4
712		2015-08-03 04:00:00+00	Alexandrium fundyense	4
713		2015-08-04 04:00:00+00	Alexandrium fundyense	4
714		2015-08-05 04:00:00+00	Alexandrium fundyense	4
715		2015-08-10 04:00:00+00	Alexandrium fundyense	4
716		2015-08-11 04:00:00+00	Alexandrium fundyense	4
717		2015-08-12 04:00:00+00	Alexandrium fundyense	4
718		2015-08-16 04:00:00+00	Alexandrium fundyense	4
719		2015-08-17 04:00:00+00	Alexandrium fundyense	4
720		2015-08-18 04:00:00+00	Alexandrium fundyense	4
721		2015-08-19 04:00:00+00	Alexandrium fundyense	4
722		2015-08-23 04:00:00+00	Alexandrium fundyense	4
723		2015-08-24 04:00:00+00	Alexandrium fundyense	4
724		2015-08-25 04:00:00+00	Alexandrium fundyense	4
725		2015-08-26 04:00:00+00	Alexandrium fundyense	4
726		2015-08-27 04:00:00+00	Alexandrium fundyense	4
727		2015-08-31 04:00:00+00	Alexandrium fundyense	4
728		2015-09-01 04:00:00+00	Alexandrium fundyense	4
729		2015-09-02 04:00:00+00	Alexandrium fundyense	4
730		2015-09-03 04:00:00+00	Alexandrium fundyense	4
731		2015-09-06 04:00:00+00	Alexandrium fundyense	4
732		2015-09-07 04:00:00+00	Alexandrium fundyense	4
733		2015-09-08 04:00:00+00	Alexandrium fundyense	4
734		2015-09-09 04:00:00+00	Alexandrium fundyense	4
851		2015-04-07 04:00:00+00	Alexandrium fundyense	5
852		2015-04-13 04:00:00+00	Alexandrium fundyense	5
853		2015-04-14 04:00:00+00	Alexandrium fundyense	5
854		2015-04-15 04:00:00+00	Alexandrium fundyense	5
855		2015-04-20 04:00:00+00	Alexandrium fundyense	5
856		2015-04-21 04:00:00+00	Alexandrium fundyense	5
857		2015-04-22 04:00:00+00	Alexandrium fundyense	5
858		2015-04-26 04:00:00+00	Alexandrium fundyense	5
859		2015-04-27 04:00:00+00	Alexandrium fundyense	5
860		2015-04-29 04:00:00+00	Alexandrium fundyense	5
861		2015-05-03 04:00:00+00	Alexandrium fundyense	5
862		2015-05-04 04:00:00+00	Alexandrium fundyense	5
863		2015-05-05 04:00:00+00	Alexandrium fundyense	5
864		2015-05-06 04:00:00+00	Alexandrium fundyense	5
865	69	2015-05-07 04:00:00+00	Alexandrium fundyense	5
866		2015-05-08 04:00:00+00	Alexandrium fundyense	5
867	69	2015-05-09 04:00:00+00	Alexandrium fundyense	5
868		2015-05-10 04:00:00+00	Alexandrium fundyense	5
869	74	2015-05-11 04:00:00+00	Alexandrium fundyense	5
870	75	2015-05-12 04:00:00+00	Alexandrium fundyense	5
871	69	2015-05-13 04:00:00+00	Alexandrium fundyense	5
872	84	2015-05-14 04:00:00+00	Alexandrium fundyense	5
873	39	2015-05-15 04:00:00+00	Alexandrium fundyense	5
874		2015-05-17 04:00:00+00	Alexandrium fundyense	5
875	51	2015-05-18 04:00:00+00	Alexandrium fundyense	5
876	0	2015-05-19 04:00:00+00	Alexandrium fundyense	5
877	0	2015-05-20 04:00:00+00	Alexandrium fundyense	5
878	48	2015-05-21 04:00:00+00	Alexandrium fundyense	5
879	38	2015-05-22 04:00:00+00	Alexandrium fundyense	5
880		2015-05-24 04:00:00+00	Alexandrium fundyense	5
881	0	2015-05-25 04:00:00+00	Alexandrium fundyense	5
882	0	2015-05-26 04:00:00+00	Alexandrium fundyense	5
883	0	2015-05-27 04:00:00+00	Alexandrium fundyense	5
884	33	2015-05-28 04:00:00+00	Alexandrium fundyense	5
885		2015-05-29 04:00:00+00	Alexandrium fundyense	5
886		2015-05-31 04:00:00+00	Alexandrium fundyense	5
887	27	2015-06-01 04:00:00+00	Alexandrium fundyense	5
888		2015-06-02 04:00:00+00	Alexandrium fundyense	5
889	0	2015-06-03 04:00:00+00	Alexandrium fundyense	5
890		2015-06-04 04:00:00+00	Alexandrium fundyense	5
891	77	2015-06-05 04:00:00+00	Alexandrium fundyense	5
892		2015-06-07 04:00:00+00	Alexandrium fundyense	5
893	0	2015-06-08 04:00:00+00	Alexandrium fundyense	5
894	0	2015-06-09 04:00:00+00	Alexandrium fundyense	5
895	71	2015-06-10 04:00:00+00	Alexandrium fundyense	5
896	0	2015-06-11 04:00:00+00	Alexandrium fundyense	5
897	0	2015-06-12 04:00:00+00	Alexandrium fundyense	5
898		2015-06-14 04:00:00+00	Alexandrium fundyense	5
899	0	2015-06-15 04:00:00+00	Alexandrium fundyense	5
900	0	2015-06-16 04:00:00+00	Alexandrium fundyense	5
901		2015-06-17 04:00:00+00	Alexandrium fundyense	5
902		2015-06-18 04:00:00+00	Alexandrium fundyense	5
903		2015-06-19 04:00:00+00	Alexandrium fundyense	5
904		2015-06-20 04:00:00+00	Alexandrium fundyense	5
905		2015-06-21 04:00:00+00	Alexandrium fundyense	5
906		2015-06-22 04:00:00+00	Alexandrium fundyense	5
907		2015-06-23 04:00:00+00	Alexandrium fundyense	5
908		2015-06-24 04:00:00+00	Alexandrium fundyense	5
909		2015-06-25 04:00:00+00	Alexandrium fundyense	5
910		2015-06-26 04:00:00+00	Alexandrium fundyense	5
911		2015-06-27 04:00:00+00	Alexandrium fundyense	5
912		2015-06-28 04:00:00+00	Alexandrium fundyense	5
913		2015-06-29 04:00:00+00	Alexandrium fundyense	5
914		2015-06-30 04:00:00+00	Alexandrium fundyense	5
915		2015-07-01 04:00:00+00	Alexandrium fundyense	5
916		2015-07-02 04:00:00+00	Alexandrium fundyense	5
917		2015-07-05 04:00:00+00	Alexandrium fundyense	5
918		2015-07-06 04:00:00+00	Alexandrium fundyense	5
919		2015-07-07 04:00:00+00	Alexandrium fundyense	5
920		2015-07-08 04:00:00+00	Alexandrium fundyense	5
921		2015-07-09 04:00:00+00	Alexandrium fundyense	5
922		2015-07-10 04:00:00+00	Alexandrium fundyense	5
923		2015-07-11 04:00:00+00	Alexandrium fundyense	5
924		2015-07-13 04:00:00+00	Alexandrium fundyense	5
925		2015-07-14 04:00:00+00	Alexandrium fundyense	5
926		2015-07-15 04:00:00+00	Alexandrium fundyense	5
927		2015-07-16 04:00:00+00	Alexandrium fundyense	5
928		2015-07-17 04:00:00+00	Alexandrium fundyense	5
929		2015-07-18 04:00:00+00	Alexandrium fundyense	5
930		2015-07-19 04:00:00+00	Alexandrium fundyense	5
931		2015-07-20 04:00:00+00	Alexandrium fundyense	5
932		2015-07-21 04:00:00+00	Alexandrium fundyense	5
933		2015-07-22 04:00:00+00	Alexandrium fundyense	5
934		2015-07-23 04:00:00+00	Alexandrium fundyense	5
935		2015-07-24 04:00:00+00	Alexandrium fundyense	5
936		2015-07-25 04:00:00+00	Alexandrium fundyense	5
937		2015-07-26 04:00:00+00	Alexandrium fundyense	5
938		2015-07-27 04:00:00+00	Alexandrium fundyense	5
939		2015-07-28 04:00:00+00	Alexandrium fundyense	5
940		2015-07-29 04:00:00+00	Alexandrium fundyense	5
941		2015-07-30 04:00:00+00	Alexandrium fundyense	5
942		2015-07-31 04:00:00+00	Alexandrium fundyense	5
943		2015-08-02 04:00:00+00	Alexandrium fundyense	5
944		2015-08-03 04:00:00+00	Alexandrium fundyense	5
945		2015-08-04 04:00:00+00	Alexandrium fundyense	5
946		2015-08-05 04:00:00+00	Alexandrium fundyense	5
947		2015-08-10 04:00:00+00	Alexandrium fundyense	5
948		2015-08-11 04:00:00+00	Alexandrium fundyense	5
949		2015-08-12 04:00:00+00	Alexandrium fundyense	5
950		2015-08-16 04:00:00+00	Alexandrium fundyense	5
951		2015-08-17 04:00:00+00	Alexandrium fundyense	5
952		2015-08-18 04:00:00+00	Alexandrium fundyense	5
953		2015-08-19 04:00:00+00	Alexandrium fundyense	5
954		2015-08-23 04:00:00+00	Alexandrium fundyense	5
955		2015-08-24 04:00:00+00	Alexandrium fundyense	5
956		2015-08-25 04:00:00+00	Alexandrium fundyense	5
957		2015-08-26 04:00:00+00	Alexandrium fundyense	5
958		2015-08-27 04:00:00+00	Alexandrium fundyense	5
959		2015-08-31 04:00:00+00	Alexandrium fundyense	5
960		2015-09-01 04:00:00+00	Alexandrium fundyense	5
961		2015-09-02 04:00:00+00	Alexandrium fundyense	5
962		2015-09-03 04:00:00+00	Alexandrium fundyense	5
963		2015-09-06 04:00:00+00	Alexandrium fundyense	5
964		2015-09-07 04:00:00+00	Alexandrium fundyense	5
965		2015-09-08 04:00:00+00	Alexandrium fundyense	5
966		2015-09-09 04:00:00+00	Alexandrium fundyense	5
1549		2017-03-27 04:00:00+00	Alexandrium fundyense	10
1550		2017-04-10 04:00:00+00	Alexandrium fundyense	10
1551		2017-04-24 04:00:00+00	Alexandrium fundyense	10
1552		2017-05-01 04:00:00+00	Alexandrium fundyense	10
1553		2017-05-08 04:00:00+00	Alexandrium fundyense	10
1554		2017-05-15 04:00:00+00	Alexandrium fundyense	10
1555		2017-05-22 04:00:00+00	Alexandrium fundyense	10
1556		2017-05-29 04:00:00+00	Alexandrium fundyense	10
1557		2017-06-05 04:00:00+00	Alexandrium fundyense	10
1558		2017-06-12 04:00:00+00	Alexandrium fundyense	10
1559		2017-06-19 04:00:00+00	Alexandrium fundyense	10
1019		2016-03-14 04:00:00+00	Alexandrium fundyense	9
1020		2016-03-15 04:00:00+00	Alexandrium fundyense	9
1021		2016-03-28 04:00:00+00	Alexandrium fundyense	9
1022		2016-03-29 04:00:00+00	Alexandrium fundyense	9
1023		2016-04-11 04:00:00+00	Alexandrium fundyense	9
1024	130	2016-04-22 04:00:00+00	Alexandrium fundyense	9
1025		2016-04-25 04:00:00+00	Alexandrium fundyense	9
1026		2016-04-26 04:00:00+00	Alexandrium fundyense	9
1027	97	2016-04-28 04:00:00+00	Alexandrium fundyense	9
1028	0	2016-04-29 04:00:00+00	Alexandrium fundyense	9
1029	0	2016-05-02 04:00:00+00	Alexandrium fundyense	9
1030	0	2016-05-03 04:00:00+00	Alexandrium fundyense	9
1031	150	2016-05-05 04:00:00+00	Alexandrium fundyense	9
1032		2016-05-06 04:00:00+00	Alexandrium fundyense	9
1033	125	2016-05-09 04:00:00+00	Alexandrium fundyense	9
1034	69	2016-05-10 04:00:00+00	Alexandrium fundyense	9
1035		2016-05-11 04:00:00+00	Alexandrium fundyense	9
1036	74	2016-05-12 04:00:00+00	Alexandrium fundyense	9
1037	61	2016-05-13 04:00:00+00	Alexandrium fundyense	9
1038	61	2016-05-16 04:00:00+00	Alexandrium fundyense	9
1039	0	2016-05-17 04:00:00+00	Alexandrium fundyense	9
1040		2016-05-18 04:00:00+00	Alexandrium fundyense	9
1041	0	2016-05-19 04:00:00+00	Alexandrium fundyense	9
1042		2016-05-20 04:00:00+00	Alexandrium fundyense	9
1043	0	2016-05-23 04:00:00+00	Alexandrium fundyense	9
1044	0	2016-05-24 04:00:00+00	Alexandrium fundyense	9
1045	0	2016-05-25 04:00:00+00	Alexandrium fundyense	9
1046	0	2016-05-26 04:00:00+00	Alexandrium fundyense	9
1047	0	2016-05-27 04:00:00+00	Alexandrium fundyense	9
1048	0	2016-05-30 04:00:00+00	Alexandrium fundyense	9
1049	0	2016-05-31 04:00:00+00	Alexandrium fundyense	9
1050	0	2016-06-01 04:00:00+00	Alexandrium fundyense	9
1051	0	2016-06-02 04:00:00+00	Alexandrium fundyense	9
1052	0	2016-06-03 04:00:00+00	Alexandrium fundyense	9
1053	0	2016-06-06 04:00:00+00	Alexandrium fundyense	9
1054	0	2016-06-07 04:00:00+00	Alexandrium fundyense	9
1055	0	2016-06-08 04:00:00+00	Alexandrium fundyense	9
1056	0	2016-06-09 04:00:00+00	Alexandrium fundyense	9
1057	0	2016-06-10 04:00:00+00	Alexandrium fundyense	9
1058	0	2016-06-13 04:00:00+00	Alexandrium fundyense	9
1059	0	2016-06-14 04:00:00+00	Alexandrium fundyense	9
1060	0	2016-06-15 04:00:00+00	Alexandrium fundyense	9
1061	0	2016-06-16 04:00:00+00	Alexandrium fundyense	9
1062	0	2016-06-17 04:00:00+00	Alexandrium fundyense	9
1063	0	2016-06-20 04:00:00+00	Alexandrium fundyense	9
1064	0	2016-06-21 04:00:00+00	Alexandrium fundyense	9
1065	0	2016-06-22 04:00:00+00	Alexandrium fundyense	9
1066	0	2016-06-23 04:00:00+00	Alexandrium fundyense	9
1067	0	2016-06-24 04:00:00+00	Alexandrium fundyense	9
1068		2016-06-27 04:00:00+00	Alexandrium fundyense	9
1069		2016-07-04 04:00:00+00	Alexandrium fundyense	9
1070		2016-07-11 04:00:00+00	Alexandrium fundyense	9
1239		2016-05-05 04:00:00+00	Alexandrium fundyense	8
1240	146	2016-05-06 04:00:00+00	Alexandrium fundyense	8
1241	274	2016-05-09 04:00:00+00	Alexandrium fundyense	8
1242	89	2016-05-10 04:00:00+00	Alexandrium fundyense	8
1243		2016-05-11 04:00:00+00	Alexandrium fundyense	8
1244		2016-05-12 04:00:00+00	Alexandrium fundyense	8
1245		2016-05-13 04:00:00+00	Alexandrium fundyense	8
1246	0	2016-05-16 04:00:00+00	Alexandrium fundyense	8
1247	0	2016-05-17 04:00:00+00	Alexandrium fundyense	8
1248	0	2016-05-18 04:00:00+00	Alexandrium fundyense	8
1249	0	2016-05-19 04:00:00+00	Alexandrium fundyense	8
1250		2016-05-20 04:00:00+00	Alexandrium fundyense	8
1251	0	2016-05-23 04:00:00+00	Alexandrium fundyense	8
1252	0	2016-05-24 04:00:00+00	Alexandrium fundyense	8
1253	0	2016-05-25 04:00:00+00	Alexandrium fundyense	8
1254	0	2016-05-26 04:00:00+00	Alexandrium fundyense	8
1255	0	2016-05-27 04:00:00+00	Alexandrium fundyense	8
1256	0	2016-05-30 04:00:00+00	Alexandrium fundyense	8
1257	0	2016-05-31 04:00:00+00	Alexandrium fundyense	8
1258	0	2016-06-01 04:00:00+00	Alexandrium fundyense	8
1259	0	2016-06-02 04:00:00+00	Alexandrium fundyense	8
1260	0	2016-06-03 04:00:00+00	Alexandrium fundyense	8
1261	0	2016-06-06 04:00:00+00	Alexandrium fundyense	8
1262	0	2016-06-07 04:00:00+00	Alexandrium fundyense	8
1263	0	2016-06-08 04:00:00+00	Alexandrium fundyense	8
1264		2016-06-09 04:00:00+00	Alexandrium fundyense	8
1265		2016-06-10 04:00:00+00	Alexandrium fundyense	8
1266		2016-06-13 04:00:00+00	Alexandrium fundyense	8
1267		2016-06-14 04:00:00+00	Alexandrium fundyense	8
1268		2016-06-15 04:00:00+00	Alexandrium fundyense	8
1269		2016-06-16 04:00:00+00	Alexandrium fundyense	8
1270		2016-06-17 04:00:00+00	Alexandrium fundyense	8
1271		2016-06-20 04:00:00+00	Alexandrium fundyense	8
1272		2016-06-21 04:00:00+00	Alexandrium fundyense	8
1273		2016-06-22 04:00:00+00	Alexandrium fundyense	8
1274		2016-06-23 04:00:00+00	Alexandrium fundyense	8
1275		2016-06-24 04:00:00+00	Alexandrium fundyense	8
1276		2016-06-27 04:00:00+00	Alexandrium fundyense	8
1277		2016-07-04 04:00:00+00	Alexandrium fundyense	8
1278		2016-07-11 04:00:00+00	Alexandrium fundyense	8
1560		2017-06-26 04:00:00+00	Alexandrium fundyense	10
1561		2017-06-29 04:00:00+00	Alexandrium fundyense	10
1562		2017-06-30 04:00:00+00	Alexandrium fundyense	10
1563	9517.4	2017-07-01 04:00:00+00	Alexandrium fundyense	10
1564	1655.9	2017-07-03 04:00:00+00	Alexandrium fundyense	10
1565	277.7	2017-07-05 04:00:00+00	Alexandrium fundyense	10
1566	8627.5	2017-07-06 04:00:00+00	Alexandrium fundyense	10
1567	1278.2	2017-07-07 04:00:00+00	Alexandrium fundyense	10
1568	1742.7	2017-07-10 04:00:00+00	Alexandrium fundyense	10
1569	958.2	2017-07-11 04:00:00+00	Alexandrium fundyense	10
1570	0	2017-07-12 04:00:00+00	Alexandrium fundyense	10
1571	0	2017-07-13 04:00:00+00	Alexandrium fundyense	10
1572	0	2017-07-14 04:00:00+00	Alexandrium fundyense	10
1573	0	2017-07-17 04:00:00+00	Alexandrium fundyense	10
1574	0	2017-07-18 04:00:00+00	Alexandrium fundyense	10
1575	0	2017-07-19 04:00:00+00	Alexandrium fundyense	10
1576	0	2017-07-20 04:00:00+00	Alexandrium fundyense	10
1577	0	2017-07-21 04:00:00+00	Alexandrium fundyense	10
1578	0	2017-07-24 04:00:00+00	Alexandrium fundyense	10
1579	0	2017-07-25 04:00:00+00	Alexandrium fundyense	10
1580	0.3	2017-07-26 04:00:00+00	Alexandrium fundyense	10
1581	0	2017-07-27 04:00:00+00	Alexandrium fundyense	10
1582	0	2017-07-28 04:00:00+00	Alexandrium fundyense	10
1583	0	2017-07-31 04:00:00+00	Alexandrium fundyense	10
1584		2017-08-01 04:00:00+00	Alexandrium fundyense	10
1585	0	2017-08-02 04:00:00+00	Alexandrium fundyense	10
1586	0	2017-08-03 04:00:00+00	Alexandrium fundyense	10
1587	0	2017-08-04 04:00:00+00	Alexandrium fundyense	10
1588	0	2017-08-07 04:00:00+00	Alexandrium fundyense	10
1589	0	2017-08-08 04:00:00+00	Alexandrium fundyense	10
1590		2017-08-09 04:00:00+00	Alexandrium fundyense	10
1591	0	2017-08-10 04:00:00+00	Alexandrium fundyense	10
1592	0	2017-08-11 04:00:00+00	Alexandrium fundyense	10
1593	0	2017-08-14 04:00:00+00	Alexandrium fundyense	10
1594	0	2017-08-15 04:00:00+00	Alexandrium fundyense	10
1595	0	2017-08-16 04:00:00+00	Alexandrium fundyense	10
1596	0	2017-08-17 04:00:00+00	Alexandrium fundyense	10
1597	0	2017-08-18 04:00:00+00	Alexandrium fundyense	10
1598	0	2017-08-21 04:00:00+00	Alexandrium fundyense	10
1599	0	2017-08-22 04:00:00+00	Alexandrium fundyense	10
1600	0	2017-08-23 04:00:00+00	Alexandrium fundyense	10
1601	0	2017-08-24 04:00:00+00	Alexandrium fundyense	10
1602		2017-08-28 04:00:00+00	Alexandrium fundyense	10
1333		2017-03-27 04:00:00+00	Alexandrium fundyense	12
1334		2017-04-10 04:00:00+00	Alexandrium fundyense	12
1335		2017-04-24 04:00:00+00	Alexandrium fundyense	12
1336		2017-05-01 04:00:00+00	Alexandrium fundyense	12
1337		2017-05-08 04:00:00+00	Alexandrium fundyense	12
1338		2017-05-15 04:00:00+00	Alexandrium fundyense	12
1339		2017-05-22 04:00:00+00	Alexandrium fundyense	12
1340		2017-05-29 04:00:00+00	Alexandrium fundyense	12
1341		2017-06-05 04:00:00+00	Alexandrium fundyense	12
1342		2017-06-12 04:00:00+00	Alexandrium fundyense	12
1343		2017-06-19 04:00:00+00	Alexandrium fundyense	12
1344		2017-06-26 04:00:00+00	Alexandrium fundyense	12
1345		2017-06-29 04:00:00+00	Alexandrium fundyense	12
1346	686.9	2017-06-30 04:00:00+00	Alexandrium fundyense	12
1347		2017-07-01 04:00:00+00	Alexandrium fundyense	12
1348	0	2017-07-03 04:00:00+00	Alexandrium fundyense	12
1349	0	2017-07-05 04:00:00+00	Alexandrium fundyense	12
1350		2017-07-06 04:00:00+00	Alexandrium fundyense	12
1351	87.7	2017-07-07 04:00:00+00	Alexandrium fundyense	12
1352	1259.8	2017-07-10 04:00:00+00	Alexandrium fundyense	12
1353	1954.4	2017-07-11 04:00:00+00	Alexandrium fundyense	12
1354	403.7	2017-07-12 04:00:00+00	Alexandrium fundyense	12
1355	3944.1	2017-07-13 04:00:00+00	Alexandrium fundyense	12
1356	3672.3	2017-07-14 04:00:00+00	Alexandrium fundyense	12
1357	116.1	2017-07-17 04:00:00+00	Alexandrium fundyense	12
1358	4.6	2017-07-18 04:00:00+00	Alexandrium fundyense	12
1359	37.1	2017-07-19 04:00:00+00	Alexandrium fundyense	12
1360	91.6	2017-07-20 04:00:00+00	Alexandrium fundyense	12
1361	48.3	2017-07-21 04:00:00+00	Alexandrium fundyense	12
1362	0	2017-07-24 04:00:00+00	Alexandrium fundyense	12
1363	0	2017-07-25 04:00:00+00	Alexandrium fundyense	12
1364	0	2017-07-26 04:00:00+00	Alexandrium fundyense	12
1365	0	2017-07-27 04:00:00+00	Alexandrium fundyense	12
1366	0	2017-07-28 04:00:00+00	Alexandrium fundyense	12
1367	0	2017-07-31 04:00:00+00	Alexandrium fundyense	12
1368	0	2017-08-01 04:00:00+00	Alexandrium fundyense	12
1369	0	2017-08-02 04:00:00+00	Alexandrium fundyense	12
1370	0	2017-08-03 04:00:00+00	Alexandrium fundyense	12
1371	0	2017-08-04 04:00:00+00	Alexandrium fundyense	12
1372	0	2017-08-07 04:00:00+00	Alexandrium fundyense	12
1373	0	2017-08-08 04:00:00+00	Alexandrium fundyense	12
1374	0	2017-08-09 04:00:00+00	Alexandrium fundyense	12
1375	0	2017-08-10 04:00:00+00	Alexandrium fundyense	12
1376	0	2017-08-11 04:00:00+00	Alexandrium fundyense	12
1377	0	2017-08-14 04:00:00+00	Alexandrium fundyense	12
1378	0	2017-08-15 04:00:00+00	Alexandrium fundyense	12
1379	0	2017-08-16 04:00:00+00	Alexandrium fundyense	12
1380	0	2017-08-17 04:00:00+00	Alexandrium fundyense	12
1381	0	2017-08-18 04:00:00+00	Alexandrium fundyense	12
1382	0	2017-08-21 04:00:00+00	Alexandrium fundyense	12
1383	0	2017-08-22 04:00:00+00	Alexandrium fundyense	12
1384	0	2017-08-23 04:00:00+00	Alexandrium fundyense	12
1385	0	2017-08-24 04:00:00+00	Alexandrium fundyense	12
1386		2017-08-28 04:00:00+00	Alexandrium fundyense	12
1441		2017-03-27 04:00:00+00	Alexandrium fundyense	13
1442		2017-04-10 04:00:00+00	Alexandrium fundyense	13
1443		2017-04-24 04:00:00+00	Alexandrium fundyense	13
1444		2017-05-01 04:00:00+00	Alexandrium fundyense	13
1445		2017-05-08 04:00:00+00	Alexandrium fundyense	13
1446		2017-05-15 04:00:00+00	Alexandrium fundyense	13
1447		2017-05-22 04:00:00+00	Alexandrium fundyense	13
1448		2017-05-29 04:00:00+00	Alexandrium fundyense	13
1449		2017-06-05 04:00:00+00	Alexandrium fundyense	13
1450		2017-06-12 04:00:00+00	Alexandrium fundyense	13
1451		2017-06-19 04:00:00+00	Alexandrium fundyense	13
1452		2017-06-26 04:00:00+00	Alexandrium fundyense	13
1453	521.3	2017-06-29 04:00:00+00	Alexandrium fundyense	13
1454		2017-06-30 04:00:00+00	Alexandrium fundyense	13
1455		2017-07-01 04:00:00+00	Alexandrium fundyense	13
1456	0	2017-07-03 04:00:00+00	Alexandrium fundyense	13
1457	0	2017-07-05 04:00:00+00	Alexandrium fundyense	13
1458	310.7	2017-07-06 04:00:00+00	Alexandrium fundyense	13
1459	770.5	2017-07-07 04:00:00+00	Alexandrium fundyense	13
1460	645.1	2017-07-10 04:00:00+00	Alexandrium fundyense	13
1461	392.7	2017-07-11 04:00:00+00	Alexandrium fundyense	13
1462	687.9	2017-07-12 04:00:00+00	Alexandrium fundyense	13
1463	444.0	2017-07-13 04:00:00+00	Alexandrium fundyense	13
1464	1514.4	2017-07-14 04:00:00+00	Alexandrium fundyense	13
1465	737.6	2017-07-17 04:00:00+00	Alexandrium fundyense	13
1466	104.0	2017-07-18 04:00:00+00	Alexandrium fundyense	13
1467	0	2017-07-19 04:00:00+00	Alexandrium fundyense	13
1468	213.8	2017-07-20 04:00:00+00	Alexandrium fundyense	13
1469	385.2	2017-07-21 04:00:00+00	Alexandrium fundyense	13
1470	283.7	2017-07-24 04:00:00+00	Alexandrium fundyense	13
1471	100.6	2017-07-25 04:00:00+00	Alexandrium fundyense	13
1472	127.3	2017-07-26 04:00:00+00	Alexandrium fundyense	13
1473	0	2017-07-27 04:00:00+00	Alexandrium fundyense	13
1474	0	2017-07-28 04:00:00+00	Alexandrium fundyense	13
1475		2017-07-31 04:00:00+00	Alexandrium fundyense	13
1476	0	2017-08-01 04:00:00+00	Alexandrium fundyense	13
1477	0	2017-08-02 04:00:00+00	Alexandrium fundyense	13
1478	0	2017-08-03 04:00:00+00	Alexandrium fundyense	13
1479	0	2017-08-04 04:00:00+00	Alexandrium fundyense	13
1480	0	2017-08-07 04:00:00+00	Alexandrium fundyense	13
1481	0	2017-08-08 04:00:00+00	Alexandrium fundyense	13
1482	0	2017-08-09 04:00:00+00	Alexandrium fundyense	13
1483	0	2017-08-10 04:00:00+00	Alexandrium fundyense	13
1484	0	2017-08-11 04:00:00+00	Alexandrium fundyense	13
1485	0	2017-08-14 04:00:00+00	Alexandrium fundyense	13
1486		2017-08-15 04:00:00+00	Alexandrium fundyense	13
1487		2017-08-16 04:00:00+00	Alexandrium fundyense	13
1488	0	2017-08-17 04:00:00+00	Alexandrium fundyense	13
1489		2017-08-18 04:00:00+00	Alexandrium fundyense	13
1490		2017-08-21 04:00:00+00	Alexandrium fundyense	13
1491	0	2017-08-22 04:00:00+00	Alexandrium fundyense	13
1492		2017-08-23 04:00:00+00	Alexandrium fundyense	13
1493		2017-08-24 04:00:00+00	Alexandrium fundyense	13
1494		2017-08-28 04:00:00+00	Alexandrium fundyense	13
1654		2018-03-12 04:00:00+00	Alexandrium fundyense	16
1655		2018-03-26 04:00:00+00	Alexandrium fundyense	16
1656	0	2018-04-10 04:00:00+00	Alexandrium fundyense	16
1657	0	2018-04-17 04:00:00+00	Alexandrium fundyense	16
1658		2018-04-19 04:00:00+00	Alexandrium fundyense	16
1659		2018-04-20 04:00:00+00	Alexandrium fundyense	16
1660	0	2018-04-24 04:00:00+00	Alexandrium fundyense	16
1661		2018-04-27 04:00:00+00	Alexandrium fundyense	16
1662	0	2018-05-01 04:00:00+00	Alexandrium fundyense	16
1663	65	2018-05-04 04:00:00+00	Alexandrium fundyense	16
1664	142	2018-05-07 04:00:00+00	Alexandrium fundyense	16
1665		2018-05-08 04:00:00+00	Alexandrium fundyense	16
1666	196	2018-05-09 04:00:00+00	Alexandrium fundyense	16
1667	563	2018-05-10 04:00:00+00	Alexandrium fundyense	16
1668	493	2018-05-11 04:00:00+00	Alexandrium fundyense	16
1669	194	2018-05-14 04:00:00+00	Alexandrium fundyense	16
1670	194	2018-05-15 04:00:00+00	Alexandrium fundyense	16
1671	167	2018-05-16 04:00:00+00	Alexandrium fundyense	16
1672	323	2018-05-17 04:00:00+00	Alexandrium fundyense	16
1673		2018-05-18 04:00:00+00	Alexandrium fundyense	16
1674	0	2018-05-21 04:00:00+00	Alexandrium fundyense	16
1675	196	2018-05-22 04:00:00+00	Alexandrium fundyense	16
1676	176	2018-05-23 04:00:00+00	Alexandrium fundyense	16
1677	118	2018-05-24 04:00:00+00	Alexandrium fundyense	16
1678	111	2018-05-25 04:00:00+00	Alexandrium fundyense	16
1679	0	2018-05-28 04:00:00+00	Alexandrium fundyense	16
1680	0	2018-05-29 04:00:00+00	Alexandrium fundyense	16
1681	0	2018-05-30 04:00:00+00	Alexandrium fundyense	16
1682	63	2018-05-31 04:00:00+00	Alexandrium fundyense	16
1683	99	2018-06-01 04:00:00+00	Alexandrium fundyense	16
1684	143	2018-06-04 04:00:00+00	Alexandrium fundyense	16
1685	172	2018-06-05 04:00:00+00	Alexandrium fundyense	16
1686	230	2018-06-06 04:00:00+00	Alexandrium fundyense	16
1687	238	2018-06-07 04:00:00+00	Alexandrium fundyense	16
1688	387	2018-06-08 04:00:00+00	Alexandrium fundyense	16
1689	203	2018-06-11 04:00:00+00	Alexandrium fundyense	16
1690	149	2018-06-12 04:00:00+00	Alexandrium fundyense	16
1691	89	2018-06-13 04:00:00+00	Alexandrium fundyense	16
1692	0	2018-06-14 04:00:00+00	Alexandrium fundyense	16
1693	0	2018-06-15 04:00:00+00	Alexandrium fundyense	16
1694	0	2018-06-18 04:00:00+00	Alexandrium fundyense	16
1695	133	2018-06-19 04:00:00+00	Alexandrium fundyense	16
1696	158	2018-06-20 04:00:00+00	Alexandrium fundyense	16
1697	125	2018-06-21 04:00:00+00	Alexandrium fundyense	16
1698	0	2018-06-22 04:00:00+00	Alexandrium fundyense	16
1699	0	2018-06-25 04:00:00+00	Alexandrium fundyense	16
1700	0	2018-06-26 04:00:00+00	Alexandrium fundyense	16
1701	0	2018-06-27 04:00:00+00	Alexandrium fundyense	16
1702		2018-06-29 04:00:00+00	Alexandrium fundyense	16
1703		2018-07-02 04:00:00+00	Alexandrium fundyense	16
1704		2018-07-08 04:00:00+00	Alexandrium fundyense	16
\.


--
-- Data for Name: esp_instrument_espinstrument; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.esp_instrument_espinstrument (id, esp_name) FROM stdin;
1	ESP Dennis
2	ESP Don
3	ESP Jake
4	ESP Roman
\.


--
-- Data for Name: socialaccount_socialaccount; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.socialaccount_socialaccount (id, provider, uid, last_login, date_joined, extra_data, user_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.socialaccount_socialapp (id, provider, name, client_id, secret, key) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp_sites; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.socialaccount_socialapp_sites (id, socialapp_id, site_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialtoken; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.socialaccount_socialtoken (id, token, token_secret, expires_at, account_id, app_id) FROM stdin;
\.


--
-- Data for Name: stations_datapoint; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.stations_datapoint (id, measurement, measurement_date, station_id, species_id) FROM stdin;
371		2017-03-12 05:00:00+00	195	1
372		2017-03-19 04:00:00+00	195	1
373		2017-03-26 04:00:00+00	195	1
374		2017-03-27 04:00:00+00	195	1
375		2017-04-02 04:00:00+00	195	1
376	<40	2017-04-03 04:00:00+00	195	1
377		2017-04-09 04:00:00+00	195	1
378	<41	2017-04-10 04:00:00+00	195	1
379		2017-04-11 04:00:00+00	195	1
380		2017-04-16 04:00:00+00	195	1
381	<40	2017-04-17 04:00:00+00	195	1
382		2017-04-20 04:00:00+00	195	1
383		2017-04-23 04:00:00+00	195	1
384		2017-04-24 04:00:00+00	195	1
385	<39	2017-04-25 04:00:00+00	195	1
386		2017-04-30 04:00:00+00	195	1
387	<40	2017-05-01 04:00:00+00	195	1
388		2017-05-07 04:00:00+00	195	1
389	<39	2017-05-08 04:00:00+00	195	1
390		2017-05-09 04:00:00+00	195	1
391		2017-05-10 04:00:00+00	195	1
392		2017-05-14 04:00:00+00	195	1
393	<39	2017-05-15 04:00:00+00	195	1
394		2017-05-21 04:00:00+00	195	1
395	<40	2017-05-22 04:00:00+00	195	1
396		2017-05-28 04:00:00+00	195	1
397		2017-05-29 04:00:00+00	195	1
398	<39	2017-05-30 04:00:00+00	195	1
399		2017-06-02 04:00:00+00	195	1
400		2017-06-04 04:00:00+00	195	1
401	<39	2017-06-05 04:00:00+00	195	1
402		2017-06-09 04:00:00+00	195	1
403		2017-06-10 04:00:00+00	195	1
404		2017-06-11 04:00:00+00	195	1
405	<41	2017-06-12 04:00:00+00	195	1
406		2017-06-18 04:00:00+00	195	1
407	<40	2017-06-19 04:00:00+00	195	1
408		2017-06-22 04:00:00+00	195	1
409		2017-06-23 04:00:00+00	195	1
410		2017-06-25 04:00:00+00	195	1
411	<40	2017-06-26 04:00:00+00	195	1
412		2017-07-02 04:00:00+00	195	1
413		2017-07-05 04:00:00+00	195	1
414		2017-07-09 04:00:00+00	195	1
415		2017-07-10 04:00:00+00	195	1
416		2017-07-14 04:00:00+00	195	1
417		2017-07-16 04:00:00+00	195	1
418	<41	2017-07-17 04:00:00+00	195	1
419		2017-07-23 04:00:00+00	195	1
420	<41	2017-07-24 04:00:00+00	195	1
421		2017-07-30 04:00:00+00	195	1
422	<39	2017-07-31 04:00:00+00	195	1
423		2017-08-06 04:00:00+00	195	1
424	<41	2017-08-07 04:00:00+00	195	1
425		2017-08-08 04:00:00+00	195	1
426		2017-08-13 04:00:00+00	195	1
427	<41	2017-08-14 04:00:00+00	195	1
428		2017-08-17 04:00:00+00	195	1
429		2017-08-20 04:00:00+00	195	1
430		2017-08-21 04:00:00+00	195	1
431		2017-08-22 04:00:00+00	195	1
432		2017-08-23 04:00:00+00	195	1
433		2017-09-03 04:00:00+00	195	1
434		2017-09-04 04:00:00+00	195	1
435	<39	2017-09-05 04:00:00+00	195	1
436		2017-09-10 04:00:00+00	195	1
437	<40	2017-09-11 04:00:00+00	195	1
438		2017-09-17 04:00:00+00	195	1
439	<39	2017-09-18 04:00:00+00	195	1
440		2017-10-02 04:00:00+00	195	1
441		2017-10-10 04:00:00+00	195	1
442		2017-10-15 04:00:00+00	195	1
443	<38	2017-10-16 04:00:00+00	195	1
444		2018-03-12 04:00:00+00	195	1
223	0	2017-03-12 05:00:00+00	177	1
224		2017-03-19 04:00:00+00	177	1
225	0	2017-03-26 04:00:00+00	177	1
226		2017-03-27 04:00:00+00	177	1
227		2017-04-02 04:00:00+00	177	1
228		2017-04-03 04:00:00+00	177	1
229	0.6	2017-04-09 04:00:00+00	177	1
230		2017-04-10 04:00:00+00	177	1
231		2017-04-11 04:00:00+00	177	1
232	1.2	2017-04-16 04:00:00+00	177	1
233		2017-04-17 04:00:00+00	177	1
234		2017-04-20 04:00:00+00	177	1
235	5.7	2017-04-23 04:00:00+00	177	1
236		2017-04-24 04:00:00+00	177	1
237		2017-04-25 04:00:00+00	177	1
238	33	2017-04-30 04:00:00+00	177	1
239		2017-05-01 04:00:00+00	177	1
240	28.1	2017-05-07 04:00:00+00	177	1
241		2017-05-08 04:00:00+00	177	1
242		2017-05-09 04:00:00+00	177	1
243		2017-05-10 04:00:00+00	177	1
244	20.5	2017-05-14 04:00:00+00	177	1
245		2017-05-15 04:00:00+00	177	1
246	9.3	2017-05-21 04:00:00+00	177	1
247		2017-05-22 04:00:00+00	177	1
248	45.2	2017-05-28 04:00:00+00	177	1
249		2017-05-29 04:00:00+00	177	1
250		2017-05-30 04:00:00+00	177	1
251		2017-06-02 04:00:00+00	177	1
252	112.5	2017-06-04 04:00:00+00	177	1
253		2017-06-05 04:00:00+00	177	1
254		2017-06-09 04:00:00+00	177	1
255		2017-06-10 04:00:00+00	177	1
256	183.5	2017-06-11 04:00:00+00	177	1
257		2017-06-12 04:00:00+00	177	1
258	86.5	2017-06-18 04:00:00+00	177	1
259		2017-06-19 04:00:00+00	177	1
260		2017-06-22 04:00:00+00	177	1
261		2017-06-23 04:00:00+00	177	1
262	16	2017-06-25 04:00:00+00	177	1
263		2017-06-26 04:00:00+00	177	1
264	23.3	2017-07-02 04:00:00+00	177	1
265		2017-07-05 04:00:00+00	177	1
266	21.4	2017-07-09 04:00:00+00	177	1
267		2017-07-10 04:00:00+00	177	1
268		2017-07-14 04:00:00+00	177	1
269	11.3	2017-07-16 04:00:00+00	177	1
270		2017-07-17 04:00:00+00	177	1
271	1	2017-07-23 04:00:00+00	177	1
272		2017-07-24 04:00:00+00	177	1
273	0.7	2017-07-30 04:00:00+00	177	1
274		2017-07-31 04:00:00+00	177	1
275	8.4	2017-08-06 04:00:00+00	177	1
276		2017-08-07 04:00:00+00	177	1
277		2017-08-08 04:00:00+00	177	1
278	0	2017-08-13 04:00:00+00	177	1
279		2017-08-14 04:00:00+00	177	1
280		2017-08-17 04:00:00+00	177	1
281		2017-08-20 04:00:00+00	177	1
282		2017-08-21 04:00:00+00	177	1
283		2017-08-22 04:00:00+00	177	1
284		2017-08-23 04:00:00+00	177	1
285		2017-09-03 04:00:00+00	177	1
286		2017-09-04 04:00:00+00	177	1
287		2017-09-05 04:00:00+00	177	1
288		2017-09-10 04:00:00+00	177	1
289		2017-09-11 04:00:00+00	177	1
290		2017-09-17 04:00:00+00	177	1
291		2017-09-18 04:00:00+00	177	1
292		2017-10-02 04:00:00+00	177	1
293		2017-10-10 04:00:00+00	177	1
294		2017-10-15 04:00:00+00	177	1
295		2017-10-16 04:00:00+00	177	1
296	0	2018-03-12 04:00:00+00	177	1
1259	0	2017-03-12 05:00:00+00	183	1
1260		2017-03-19 04:00:00+00	183	1
1261	0	2017-03-26 04:00:00+00	183	1
1262		2017-03-27 04:00:00+00	183	1
1263	0.4	2017-04-02 04:00:00+00	183	1
1264		2017-04-03 04:00:00+00	183	1
1265	0.5	2017-04-09 04:00:00+00	183	1
1266		2017-04-10 04:00:00+00	183	1
1267		2017-04-11 04:00:00+00	183	1
1268	1.6	2017-04-16 04:00:00+00	183	1
1269		2017-04-17 04:00:00+00	183	1
1270		2017-04-20 04:00:00+00	183	1
1271	2.3	2017-04-23 04:00:00+00	183	1
1272		2017-04-24 04:00:00+00	183	1
1273		2017-04-25 04:00:00+00	183	1
1274	6.4	2017-04-30 04:00:00+00	183	1
1275		2017-05-01 04:00:00+00	183	1
1276	7.8	2017-05-07 04:00:00+00	183	1
1277		2017-05-08 04:00:00+00	183	1
1278		2017-05-09 04:00:00+00	183	1
1279		2017-05-10 04:00:00+00	183	1
1280	25.6	2017-05-14 04:00:00+00	183	1
1281		2017-05-15 04:00:00+00	183	1
1282	10.1	2017-05-21 04:00:00+00	183	1
1283		2017-05-22 04:00:00+00	183	1
1284	90.4	2017-05-28 04:00:00+00	183	1
1285		2017-05-29 04:00:00+00	183	1
1286		2017-05-30 04:00:00+00	183	1
1287		2017-06-02 04:00:00+00	183	1
1288	161.4	2017-06-04 04:00:00+00	183	1
1289		2017-06-05 04:00:00+00	183	1
1290		2017-06-09 04:00:00+00	183	1
1291		2017-06-10 04:00:00+00	183	1
1292	271.7	2017-06-11 04:00:00+00	183	1
1293		2017-06-12 04:00:00+00	183	1
1294	139.5	2017-06-18 04:00:00+00	183	1
1295		2017-06-19 04:00:00+00	183	1
1296		2017-06-22 04:00:00+00	183	1
1297		2017-06-23 04:00:00+00	183	1
1298	134.6	2017-06-25 04:00:00+00	183	1
1299		2017-06-26 04:00:00+00	183	1
1300	29.5	2017-07-02 04:00:00+00	183	1
1301		2017-07-05 04:00:00+00	183	1
1302	17	2017-07-09 04:00:00+00	183	1
1303		2017-07-10 04:00:00+00	183	1
1304		2017-07-14 04:00:00+00	183	1
1305	11.3	2017-07-16 04:00:00+00	183	1
1306		2017-07-17 04:00:00+00	183	1
1307	5.1	2017-07-23 04:00:00+00	183	1
1308		2017-07-24 04:00:00+00	183	1
1309	6.9	2017-07-30 04:00:00+00	183	1
1310		2017-07-31 04:00:00+00	183	1
1311	0.4	2017-08-06 04:00:00+00	183	1
1312		2017-08-07 04:00:00+00	183	1
1313		2017-08-08 04:00:00+00	183	1
1314	0	2017-08-13 04:00:00+00	183	1
1315		2017-08-14 04:00:00+00	183	1
1316		2017-08-17 04:00:00+00	183	1
1317	0.4	2017-08-20 04:00:00+00	183	1
1318		2017-08-21 04:00:00+00	183	1
1319		2017-08-22 04:00:00+00	183	1
1320		2017-08-23 04:00:00+00	183	1
1321		2017-09-03 04:00:00+00	183	1
1322		2017-09-04 04:00:00+00	183	1
1323		2017-09-05 04:00:00+00	183	1
1324		2017-09-10 04:00:00+00	183	1
1325		2017-09-11 04:00:00+00	183	1
1326		2017-09-17 04:00:00+00	183	1
1327		2017-09-18 04:00:00+00	183	1
1328		2017-10-02 04:00:00+00	183	1
1329		2017-10-10 04:00:00+00	183	1
1330		2017-10-15 04:00:00+00	183	1
1331		2017-10-16 04:00:00+00	183	1
1332	0.4	2018-03-12 04:00:00+00	183	1
519	0	2017-03-12 05:00:00+00	178	1
520		2017-03-19 04:00:00+00	178	1
521	0.5	2017-03-26 04:00:00+00	178	1
522		2017-03-27 04:00:00+00	178	1
523		2017-04-02 04:00:00+00	178	1
524		2017-04-03 04:00:00+00	178	1
525	0.8	2017-04-09 04:00:00+00	178	1
526		2017-04-10 04:00:00+00	178	1
527		2017-04-11 04:00:00+00	178	1
528	3.8	2017-04-16 04:00:00+00	178	1
529		2017-04-17 04:00:00+00	178	1
530		2017-04-20 04:00:00+00	178	1
531	18.1	2017-04-23 04:00:00+00	178	1
532		2017-04-24 04:00:00+00	178	1
533		2017-04-25 04:00:00+00	178	1
534	16.6	2017-04-30 04:00:00+00	178	1
535		2017-05-01 04:00:00+00	178	1
536	39.3	2017-05-07 04:00:00+00	178	1
537		2017-05-08 04:00:00+00	178	1
538		2017-05-09 04:00:00+00	178	1
539		2017-05-10 04:00:00+00	178	1
540	141	2017-05-14 04:00:00+00	178	1
541		2017-05-15 04:00:00+00	178	1
542	228.2	2017-05-21 04:00:00+00	178	1
543		2017-05-22 04:00:00+00	178	1
544	142.5	2017-05-28 04:00:00+00	178	1
545		2017-05-29 04:00:00+00	178	1
546		2017-05-30 04:00:00+00	178	1
547		2017-06-02 04:00:00+00	178	1
548	739	2017-06-04 04:00:00+00	178	1
549		2017-06-05 04:00:00+00	178	1
550		2017-06-09 04:00:00+00	178	1
551		2017-06-10 04:00:00+00	178	1
552	598.8	2017-06-11 04:00:00+00	178	1
553		2017-06-12 04:00:00+00	178	1
554	383	2017-06-18 04:00:00+00	178	1
555		2017-06-19 04:00:00+00	178	1
556		2017-06-22 04:00:00+00	178	1
557		2017-06-23 04:00:00+00	178	1
558	193.5	2017-06-25 04:00:00+00	178	1
559		2017-06-26 04:00:00+00	178	1
560	39.9	2017-07-02 04:00:00+00	178	1
561		2017-07-05 04:00:00+00	178	1
562	30.6	2017-07-09 04:00:00+00	178	1
563		2017-07-10 04:00:00+00	178	1
564		2017-07-14 04:00:00+00	178	1
565	26.4	2017-07-16 04:00:00+00	178	1
566		2017-07-17 04:00:00+00	178	1
567	20.2	2017-07-23 04:00:00+00	178	1
568		2017-07-24 04:00:00+00	178	1
569	18.8	2017-07-30 04:00:00+00	178	1
570		2017-07-31 04:00:00+00	178	1
571	13	2017-08-06 04:00:00+00	178	1
572		2017-08-07 04:00:00+00	178	1
573		2017-08-08 04:00:00+00	178	1
574	0.5	2017-08-13 04:00:00+00	178	1
575		2017-08-14 04:00:00+00	178	1
576		2017-08-17 04:00:00+00	178	1
577		2017-08-20 04:00:00+00	178	1
578		2017-08-21 04:00:00+00	178	1
579		2017-08-22 04:00:00+00	178	1
580		2017-08-23 04:00:00+00	178	1
581		2017-09-03 04:00:00+00	178	1
582		2017-09-04 04:00:00+00	178	1
583		2017-09-05 04:00:00+00	178	1
584		2017-09-10 04:00:00+00	178	1
585		2017-09-11 04:00:00+00	178	1
586		2017-09-17 04:00:00+00	178	1
587		2017-09-18 04:00:00+00	178	1
588		2017-10-02 04:00:00+00	178	1
589		2017-10-10 04:00:00+00	178	1
590		2017-10-15 04:00:00+00	178	1
591		2017-10-16 04:00:00+00	178	1
592	0.3	2018-03-12 04:00:00+00	178	1
815	0	2017-03-12 05:00:00+00	180	1
816		2017-03-19 04:00:00+00	180	1
817	0	2017-03-26 04:00:00+00	180	1
818		2017-03-27 04:00:00+00	180	1
819		2017-04-02 04:00:00+00	180	1
820		2017-04-03 04:00:00+00	180	1
821	0.9	2017-04-09 04:00:00+00	180	1
822		2017-04-10 04:00:00+00	180	1
823		2017-04-11 04:00:00+00	180	1
824	2.5	2017-04-16 04:00:00+00	180	1
825		2017-04-17 04:00:00+00	180	1
826		2017-04-20 04:00:00+00	180	1
827	2.4	2017-04-23 04:00:00+00	180	1
828		2017-04-24 04:00:00+00	180	1
829		2017-04-25 04:00:00+00	180	1
830	7.6	2017-04-30 04:00:00+00	180	1
831		2017-05-01 04:00:00+00	180	1
832	8.8	2017-05-07 04:00:00+00	180	1
833		2017-05-08 04:00:00+00	180	1
834		2017-05-09 04:00:00+00	180	1
835		2017-05-10 04:00:00+00	180	1
836	46.2	2017-05-14 04:00:00+00	180	1
837		2017-05-15 04:00:00+00	180	1
838	16.8	2017-05-21 04:00:00+00	180	1
839		2017-05-22 04:00:00+00	180	1
840	65.5	2017-05-28 04:00:00+00	180	1
841		2017-05-29 04:00:00+00	180	1
842		2017-05-30 04:00:00+00	180	1
843		2017-06-02 04:00:00+00	180	1
844	239.7	2017-06-04 04:00:00+00	180	1
845		2017-06-05 04:00:00+00	180	1
846		2017-06-09 04:00:00+00	180	1
847		2017-06-10 04:00:00+00	180	1
848	111.5	2017-06-11 04:00:00+00	180	1
849		2017-06-12 04:00:00+00	180	1
850	106.6	2017-06-18 04:00:00+00	180	1
851		2017-06-19 04:00:00+00	180	1
852		2017-06-22 04:00:00+00	180	1
853		2017-06-23 04:00:00+00	180	1
854	44	2017-06-25 04:00:00+00	180	1
855		2017-06-26 04:00:00+00	180	1
856	11.2	2017-07-02 04:00:00+00	180	1
857		2017-07-05 04:00:00+00	180	1
858	4	2017-07-09 04:00:00+00	180	1
859		2017-07-10 04:00:00+00	180	1
860		2017-07-14 04:00:00+00	180	1
861	10.4	2017-07-16 04:00:00+00	180	1
862		2017-07-17 04:00:00+00	180	1
863	0.3	2017-07-23 04:00:00+00	180	1
864		2017-07-24 04:00:00+00	180	1
865	0.5	2017-07-30 04:00:00+00	180	1
866		2017-07-31 04:00:00+00	180	1
867	0	2017-08-06 04:00:00+00	180	1
868		2017-08-07 04:00:00+00	180	1
869		2017-08-08 04:00:00+00	180	1
870	0	2017-08-13 04:00:00+00	180	1
871		2017-08-14 04:00:00+00	180	1
872		2017-08-17 04:00:00+00	180	1
873	0	2017-08-20 04:00:00+00	180	1
874		2017-08-21 04:00:00+00	180	1
875		2017-08-22 04:00:00+00	180	1
876		2017-08-23 04:00:00+00	180	1
667	0	2017-03-12 05:00:00+00	179	1
668		2017-03-19 04:00:00+00	179	1
669	0	2017-03-26 04:00:00+00	179	1
670		2017-03-27 04:00:00+00	179	1
671		2017-04-02 04:00:00+00	179	1
672		2017-04-03 04:00:00+00	179	1
673	0.7	2017-04-09 04:00:00+00	179	1
674		2017-04-10 04:00:00+00	179	1
675		2017-04-11 04:00:00+00	179	1
676	2.2	2017-04-16 04:00:00+00	179	1
677		2017-04-17 04:00:00+00	179	1
678		2017-04-20 04:00:00+00	179	1
679	3	2017-04-23 04:00:00+00	179	1
680		2017-04-24 04:00:00+00	179	1
681		2017-04-25 04:00:00+00	179	1
682	4.9	2017-04-30 04:00:00+00	179	1
683		2017-05-01 04:00:00+00	179	1
684	8.5	2017-05-07 04:00:00+00	179	1
685		2017-05-08 04:00:00+00	179	1
686		2017-05-09 04:00:00+00	179	1
687		2017-05-10 04:00:00+00	179	1
688	19.8	2017-05-14 04:00:00+00	179	1
689		2017-05-15 04:00:00+00	179	1
690	16.5	2017-05-21 04:00:00+00	179	1
691		2017-05-22 04:00:00+00	179	1
692	39	2017-05-28 04:00:00+00	179	1
693		2017-05-29 04:00:00+00	179	1
694		2017-05-30 04:00:00+00	179	1
695		2017-06-02 04:00:00+00	179	1
696	240.3	2017-06-04 04:00:00+00	179	1
697		2017-06-05 04:00:00+00	179	1
698		2017-06-09 04:00:00+00	179	1
699		2017-06-10 04:00:00+00	179	1
700	199.7	2017-06-11 04:00:00+00	179	1
701		2017-06-12 04:00:00+00	179	1
702	78.5	2017-06-18 04:00:00+00	179	1
703		2017-06-19 04:00:00+00	179	1
704		2017-06-22 04:00:00+00	179	1
705		2017-06-23 04:00:00+00	179	1
706	23	2017-06-25 04:00:00+00	179	1
707		2017-06-26 04:00:00+00	179	1
708	9.1	2017-07-02 04:00:00+00	179	1
709		2017-07-05 04:00:00+00	179	1
710	6.6	2017-07-09 04:00:00+00	179	1
711		2017-07-10 04:00:00+00	179	1
712		2017-07-14 04:00:00+00	179	1
713	4.4	2017-07-16 04:00:00+00	179	1
714		2017-07-17 04:00:00+00	179	1
715	0.4	2017-07-23 04:00:00+00	179	1
716		2017-07-24 04:00:00+00	179	1
717	0	2017-07-30 04:00:00+00	179	1
718		2017-07-31 04:00:00+00	179	1
719	0	2017-08-06 04:00:00+00	179	1
720		2017-08-07 04:00:00+00	179	1
721		2017-08-08 04:00:00+00	179	1
722	0	2017-08-13 04:00:00+00	179	1
723		2017-08-14 04:00:00+00	179	1
724		2017-08-17 04:00:00+00	179	1
725	0.3	2017-08-20 04:00:00+00	179	1
726		2017-08-21 04:00:00+00	179	1
727		2017-08-22 04:00:00+00	179	1
728		2017-08-23 04:00:00+00	179	1
729		2017-09-03 04:00:00+00	179	1
730		2017-09-04 04:00:00+00	179	1
731		2017-09-05 04:00:00+00	179	1
732		2017-09-10 04:00:00+00	179	1
733		2017-09-11 04:00:00+00	179	1
734		2017-09-17 04:00:00+00	179	1
735		2017-09-18 04:00:00+00	179	1
736		2017-10-02 04:00:00+00	179	1
737		2017-10-10 04:00:00+00	179	1
738		2017-10-15 04:00:00+00	179	1
739		2017-10-16 04:00:00+00	179	1
740	0.6	2018-03-12 04:00:00+00	179	1
877		2017-09-03 04:00:00+00	180	1
878		2017-09-04 04:00:00+00	180	1
879		2017-09-05 04:00:00+00	180	1
880		2017-09-10 04:00:00+00	180	1
881		2017-09-11 04:00:00+00	180	1
882		2017-09-17 04:00:00+00	180	1
883		2017-09-18 04:00:00+00	180	1
884		2017-10-02 04:00:00+00	180	1
885		2017-10-10 04:00:00+00	180	1
886		2017-10-15 04:00:00+00	180	1
887		2017-10-16 04:00:00+00	180	1
888	0.3	2018-03-12 04:00:00+00	180	1
1111		2017-03-12 05:00:00+00	182	1
1112		2017-03-19 04:00:00+00	182	1
1113		2017-03-26 04:00:00+00	182	1
1114		2017-03-27 04:00:00+00	182	1
1115	0.4	2017-04-02 04:00:00+00	182	1
1116		2017-04-03 04:00:00+00	182	1
1117	1	2017-04-09 04:00:00+00	182	1
1118		2017-04-10 04:00:00+00	182	1
1119		2017-04-11 04:00:00+00	182	1
1120	8	2017-04-16 04:00:00+00	182	1
1121		2017-04-17 04:00:00+00	182	1
1122		2017-04-20 04:00:00+00	182	1
1123	10.1	2017-04-23 04:00:00+00	182	1
1124		2017-04-24 04:00:00+00	182	1
1125		2017-04-25 04:00:00+00	182	1
1126	25.5	2017-04-30 04:00:00+00	182	1
1127		2017-05-01 04:00:00+00	182	1
1128	66.6	2017-05-07 04:00:00+00	182	1
1129		2017-05-08 04:00:00+00	182	1
1130		2017-05-09 04:00:00+00	182	1
1131		2017-05-10 04:00:00+00	182	1
1132	143.7	2017-05-14 04:00:00+00	182	1
1133		2017-05-15 04:00:00+00	182	1
1134	478.3	2017-05-21 04:00:00+00	182	1
1135		2017-05-22 04:00:00+00	182	1
1136	1485.1	2017-05-28 04:00:00+00	182	1
1137		2017-05-29 04:00:00+00	182	1
1138		2017-05-30 04:00:00+00	182	1
1139		2017-06-02 04:00:00+00	182	1
1140	1654.7	2017-06-04 04:00:00+00	182	1
1141		2017-06-05 04:00:00+00	182	1
1142		2017-06-09 04:00:00+00	182	1
1143		2017-06-10 04:00:00+00	182	1
1144	2970.5	2017-06-11 04:00:00+00	182	1
1145		2017-06-12 04:00:00+00	182	1
1146	917.8	2017-06-18 04:00:00+00	182	1
1147		2017-06-19 04:00:00+00	182	1
1148		2017-06-22 04:00:00+00	182	1
1149		2017-06-23 04:00:00+00	182	1
1150	457.2	2017-06-25 04:00:00+00	182	1
1151		2017-06-26 04:00:00+00	182	1
1152	184.6	2017-07-02 04:00:00+00	182	1
1153		2017-07-05 04:00:00+00	182	1
1154	62.2	2017-07-09 04:00:00+00	182	1
1155		2017-07-10 04:00:00+00	182	1
1156		2017-07-14 04:00:00+00	182	1
1157	73.9	2017-07-16 04:00:00+00	182	1
1158		2017-07-17 04:00:00+00	182	1
1159	46.9	2017-07-23 04:00:00+00	182	1
1160		2017-07-24 04:00:00+00	182	1
1161	39.7	2017-07-30 04:00:00+00	182	1
1162		2017-07-31 04:00:00+00	182	1
1163	27	2017-08-06 04:00:00+00	182	1
1164		2017-08-07 04:00:00+00	182	1
1165		2017-08-08 04:00:00+00	182	1
1166	29.2	2017-08-13 04:00:00+00	182	1
1167		2017-08-14 04:00:00+00	182	1
1168		2017-08-17 04:00:00+00	182	1
1169	14.2	2017-08-20 04:00:00+00	182	1
1170		2017-08-21 04:00:00+00	182	1
1171		2017-08-22 04:00:00+00	182	1
1172		2017-08-23 04:00:00+00	182	1
963	0	2017-03-12 05:00:00+00	181	1
964		2017-03-19 04:00:00+00	181	1
965	0	2017-03-26 04:00:00+00	181	1
966		2017-03-27 04:00:00+00	181	1
967	0.3	2017-04-02 04:00:00+00	181	1
968		2017-04-03 04:00:00+00	181	1
969	0.7	2017-04-09 04:00:00+00	181	1
970		2017-04-10 04:00:00+00	181	1
971		2017-04-11 04:00:00+00	181	1
972	6.3	2017-04-16 04:00:00+00	181	1
973		2017-04-17 04:00:00+00	181	1
974		2017-04-20 04:00:00+00	181	1
975	9.4	2017-04-23 04:00:00+00	181	1
976		2017-04-24 04:00:00+00	181	1
977		2017-04-25 04:00:00+00	181	1
978	18.2	2017-04-30 04:00:00+00	181	1
979		2017-05-01 04:00:00+00	181	1
980	116.4	2017-05-07 04:00:00+00	181	1
981		2017-05-08 04:00:00+00	181	1
982		2017-05-09 04:00:00+00	181	1
983		2017-05-10 04:00:00+00	181	1
984	118.4	2017-05-14 04:00:00+00	181	1
985		2017-05-15 04:00:00+00	181	1
986	107.5	2017-05-21 04:00:00+00	181	1
987		2017-05-22 04:00:00+00	181	1
988	301.1	2017-05-28 04:00:00+00	181	1
989		2017-05-29 04:00:00+00	181	1
990		2017-05-30 04:00:00+00	181	1
991		2017-06-02 04:00:00+00	181	1
992	3092.8	2017-06-04 04:00:00+00	181	1
993		2017-06-05 04:00:00+00	181	1
994		2017-06-09 04:00:00+00	181	1
995		2017-06-10 04:00:00+00	181	1
996	2351.6	2017-06-11 04:00:00+00	181	1
997		2017-06-12 04:00:00+00	181	1
998	873.6	2017-06-18 04:00:00+00	181	1
999		2017-06-19 04:00:00+00	181	1
1000		2017-06-22 04:00:00+00	181	1
1001		2017-06-23 04:00:00+00	181	1
1002	295.1	2017-06-25 04:00:00+00	181	1
1003		2017-06-26 04:00:00+00	181	1
1004	199.6	2017-07-02 04:00:00+00	181	1
1005		2017-07-05 04:00:00+00	181	1
1006	131.6	2017-07-09 04:00:00+00	181	1
1007		2017-07-10 04:00:00+00	181	1
1008		2017-07-14 04:00:00+00	181	1
1009	57.7	2017-07-16 04:00:00+00	181	1
1010		2017-07-17 04:00:00+00	181	1
1011	20.2	2017-07-23 04:00:00+00	181	1
1012		2017-07-24 04:00:00+00	181	1
1013	20.3	2017-07-30 04:00:00+00	181	1
1014		2017-07-31 04:00:00+00	181	1
1015	18.6	2017-08-06 04:00:00+00	181	1
1016		2017-08-07 04:00:00+00	181	1
1017		2017-08-08 04:00:00+00	181	1
1018	14.2	2017-08-13 04:00:00+00	181	1
1019		2017-08-14 04:00:00+00	181	1
1020		2017-08-17 04:00:00+00	181	1
1021	17	2017-08-20 04:00:00+00	181	1
1022		2017-08-21 04:00:00+00	181	1
1023		2017-08-22 04:00:00+00	181	1
1024		2017-08-23 04:00:00+00	181	1
1025		2017-09-03 04:00:00+00	181	1
1026		2017-09-04 04:00:00+00	181	1
1027		2017-09-05 04:00:00+00	181	1
1028		2017-09-10 04:00:00+00	181	1
1029		2017-09-11 04:00:00+00	181	1
1030		2017-09-17 04:00:00+00	181	1
1031		2017-09-18 04:00:00+00	181	1
1032		2017-10-02 04:00:00+00	181	1
1033		2017-10-10 04:00:00+00	181	1
1034		2017-10-15 04:00:00+00	181	1
1035		2017-10-16 04:00:00+00	181	1
1036	6.5	2018-03-12 04:00:00+00	181	1
1173		2017-09-03 04:00:00+00	182	1
1174		2017-09-04 04:00:00+00	182	1
1175		2017-09-05 04:00:00+00	182	1
1176		2017-09-10 04:00:00+00	182	1
1177		2017-09-11 04:00:00+00	182	1
1178		2017-09-17 04:00:00+00	182	1
1179		2017-09-18 04:00:00+00	182	1
1180		2017-10-02 04:00:00+00	182	1
1181		2017-10-10 04:00:00+00	182	1
1182		2017-10-15 04:00:00+00	182	1
1183		2017-10-16 04:00:00+00	182	1
1184	6.7	2018-03-12 04:00:00+00	182	1
1999		2017-03-12 05:00:00+00	188	1
1407	0	2017-03-12 05:00:00+00	184	1
1408		2017-03-19 04:00:00+00	184	1
1409	*1.1	2017-03-26 04:00:00+00	184	1
1410		2017-03-27 04:00:00+00	184	1
1411	*1.1	2017-04-02 04:00:00+00	184	1
1412		2017-04-03 04:00:00+00	184	1
1413	0	2017-04-09 04:00:00+00	184	1
1414		2017-04-10 04:00:00+00	184	1
1415		2017-04-11 04:00:00+00	184	1
1416	1.3	2017-04-16 04:00:00+00	184	1
1417		2017-04-17 04:00:00+00	184	1
1418		2017-04-20 04:00:00+00	184	1
1419	*24.4	2017-04-23 04:00:00+00	184	1
1420		2017-04-24 04:00:00+00	184	1
1421		2017-04-25 04:00:00+00	184	1
1422	2.2	2017-04-30 04:00:00+00	184	1
1423		2017-05-01 04:00:00+00	184	1
1424	3	2017-05-07 04:00:00+00	184	1
1425		2017-05-08 04:00:00+00	184	1
1426		2017-05-09 04:00:00+00	184	1
1427		2017-05-10 04:00:00+00	184	1
1428	78.2	2017-05-14 04:00:00+00	184	1
1429		2017-05-15 04:00:00+00	184	1
1430	46.8	2017-05-21 04:00:00+00	184	1
1431		2017-05-22 04:00:00+00	184	1
1432	78.2	2017-05-28 04:00:00+00	184	1
1433		2017-05-29 04:00:00+00	184	1
1434		2017-05-30 04:00:00+00	184	1
1435		2017-06-02 04:00:00+00	184	1
1436	102.8	2017-06-04 04:00:00+00	184	1
1437		2017-06-05 04:00:00+00	184	1
1438		2017-06-09 04:00:00+00	184	1
1439		2017-06-10 04:00:00+00	184	1
1440	35.9	2017-06-11 04:00:00+00	184	1
1441		2017-06-12 04:00:00+00	184	1
1442	24.4	2017-06-18 04:00:00+00	184	1
1443		2017-06-19 04:00:00+00	184	1
1444		2017-06-22 04:00:00+00	184	1
1445		2017-06-23 04:00:00+00	184	1
1446	4.2	2017-06-25 04:00:00+00	184	1
1447		2017-06-26 04:00:00+00	184	1
1448	4.7	2017-07-02 04:00:00+00	184	1
1449		2017-07-05 04:00:00+00	184	1
1450	0.9	2017-07-09 04:00:00+00	184	1
1451		2017-07-10 04:00:00+00	184	1
1452		2017-07-14 04:00:00+00	184	1
1453	0.7	2017-07-16 04:00:00+00	184	1
1454		2017-07-17 04:00:00+00	184	1
1455	0	2017-07-23 04:00:00+00	184	1
1456		2017-07-24 04:00:00+00	184	1
1457	0.9	2017-07-30 04:00:00+00	184	1
1458		2017-07-31 04:00:00+00	184	1
1459	*8.8	2017-08-06 04:00:00+00	184	1
1460		2017-08-07 04:00:00+00	184	1
1461		2017-08-08 04:00:00+00	184	1
1462	0	2017-08-13 04:00:00+00	184	1
1463		2017-08-14 04:00:00+00	184	1
1464		2017-08-17 04:00:00+00	184	1
1465	0	2017-08-20 04:00:00+00	184	1
1466		2017-08-21 04:00:00+00	184	1
1467		2017-08-22 04:00:00+00	184	1
1468		2017-08-23 04:00:00+00	184	1
1469		2017-09-03 04:00:00+00	184	1
1470		2017-09-04 04:00:00+00	184	1
1471		2017-09-05 04:00:00+00	184	1
1472		2017-09-10 04:00:00+00	184	1
1473		2017-09-11 04:00:00+00	184	1
1474		2017-09-17 04:00:00+00	184	1
1475		2017-09-18 04:00:00+00	184	1
1476		2017-10-02 04:00:00+00	184	1
1477		2017-10-10 04:00:00+00	184	1
1478		2017-10-15 04:00:00+00	184	1
1479		2017-10-16 04:00:00+00	184	1
1480	0	2018-03-12 04:00:00+00	184	1
2000		2017-03-19 04:00:00+00	188	1
2001	0	2017-03-26 04:00:00+00	188	1
2002		2017-03-27 04:00:00+00	188	1
2003		2017-04-02 04:00:00+00	188	1
2004		2017-04-03 04:00:00+00	188	1
2005	0	2017-04-09 04:00:00+00	188	1
2006		2017-04-10 04:00:00+00	188	1
2007		2017-04-11 04:00:00+00	188	1
2008		2017-04-16 04:00:00+00	188	1
2009		2017-04-17 04:00:00+00	188	1
2010		2017-04-20 04:00:00+00	188	1
2011	0	2017-04-23 04:00:00+00	188	1
2012		2017-04-24 04:00:00+00	188	1
2013		2017-04-25 04:00:00+00	188	1
2014	0.2	2017-04-30 04:00:00+00	188	1
2015		2017-05-01 04:00:00+00	188	1
2016	0	2017-05-07 04:00:00+00	188	1
2017		2017-05-08 04:00:00+00	188	1
2018		2017-05-09 04:00:00+00	188	1
2019		2017-05-10 04:00:00+00	188	1
2020	0.5	2017-05-14 04:00:00+00	188	1
2021		2017-05-15 04:00:00+00	188	1
2022	1.2	2017-05-21 04:00:00+00	188	1
2023		2017-05-22 04:00:00+00	188	1
2024	1.1	2017-05-28 04:00:00+00	188	1
2025		2017-05-29 04:00:00+00	188	1
2026		2017-05-30 04:00:00+00	188	1
2027		2017-06-02 04:00:00+00	188	1
2028	0.9	2017-06-04 04:00:00+00	188	1
1851		2017-03-12 05:00:00+00	187	1
1852		2017-03-19 04:00:00+00	187	1
1853	0	2017-03-26 04:00:00+00	187	1
1854		2017-03-27 04:00:00+00	187	1
1855		2017-04-02 04:00:00+00	187	1
1856		2017-04-03 04:00:00+00	187	1
1857	0	2017-04-09 04:00:00+00	187	1
1858		2017-04-10 04:00:00+00	187	1
1859		2017-04-11 04:00:00+00	187	1
1860		2017-04-16 04:00:00+00	187	1
1861		2017-04-17 04:00:00+00	187	1
1862		2017-04-20 04:00:00+00	187	1
1863	0	2017-04-23 04:00:00+00	187	1
1864		2017-04-24 04:00:00+00	187	1
1865		2017-04-25 04:00:00+00	187	1
1866	0.4	2017-04-30 04:00:00+00	187	1
1867		2017-05-01 04:00:00+00	187	1
1868	0.4	2017-05-07 04:00:00+00	187	1
1869		2017-05-08 04:00:00+00	187	1
1870		2017-05-09 04:00:00+00	187	1
1871		2017-05-10 04:00:00+00	187	1
1872	0	2017-05-14 04:00:00+00	187	1
1873		2017-05-15 04:00:00+00	187	1
1874	0	2017-05-21 04:00:00+00	187	1
1875		2017-05-22 04:00:00+00	187	1
1876	1.6	2017-05-28 04:00:00+00	187	1
1877		2017-05-29 04:00:00+00	187	1
1878		2017-05-30 04:00:00+00	187	1
1879		2017-06-02 04:00:00+00	187	1
1880	1.7	2017-06-04 04:00:00+00	187	1
1881		2017-06-05 04:00:00+00	187	1
1882		2017-06-09 04:00:00+00	187	1
1883		2017-06-10 04:00:00+00	187	1
1884	2.7	2017-06-11 04:00:00+00	187	1
1885		2017-06-12 04:00:00+00	187	1
1886	2.9	2017-06-18 04:00:00+00	187	1
1887		2017-06-19 04:00:00+00	187	1
1888		2017-06-22 04:00:00+00	187	1
1889		2017-06-23 04:00:00+00	187	1
1890	2	2017-06-25 04:00:00+00	187	1
1891		2017-06-26 04:00:00+00	187	1
1892	1	2017-07-02 04:00:00+00	187	1
1893		2017-07-05 04:00:00+00	187	1
1894	0.7	2017-07-09 04:00:00+00	187	1
1895		2017-07-10 04:00:00+00	187	1
1896		2017-07-14 04:00:00+00	187	1
1555	0	2017-03-12 05:00:00+00	185	1
1556		2017-03-19 04:00:00+00	185	1
1557	0	2017-03-26 04:00:00+00	185	1
1558		2017-03-27 04:00:00+00	185	1
1559	0.2	2017-04-02 04:00:00+00	185	1
1560		2017-04-03 04:00:00+00	185	1
1561	0	2017-04-09 04:00:00+00	185	1
1562		2017-04-10 04:00:00+00	185	1
1563		2017-04-11 04:00:00+00	185	1
1564	0.8	2017-04-16 04:00:00+00	185	1
1565		2017-04-17 04:00:00+00	185	1
1566		2017-04-20 04:00:00+00	185	1
1567	1.3	2017-04-23 04:00:00+00	185	1
1568		2017-04-24 04:00:00+00	185	1
1569		2017-04-25 04:00:00+00	185	1
1570	3	2017-04-30 04:00:00+00	185	1
1571		2017-05-01 04:00:00+00	185	1
1572	1.6	2017-05-07 04:00:00+00	185	1
1573		2017-05-08 04:00:00+00	185	1
1574		2017-05-09 04:00:00+00	185	1
1575		2017-05-10 04:00:00+00	185	1
1576	4.9	2017-05-14 04:00:00+00	185	1
1577		2017-05-15 04:00:00+00	185	1
1578	12.6	2017-05-21 04:00:00+00	185	1
1579		2017-05-22 04:00:00+00	185	1
1580	29.2	2017-05-28 04:00:00+00	185	1
1581		2017-05-29 04:00:00+00	185	1
1582		2017-05-30 04:00:00+00	185	1
1583		2017-06-02 04:00:00+00	185	1
1584	18.9	2017-06-04 04:00:00+00	185	1
1585		2017-06-05 04:00:00+00	185	1
1586		2017-06-09 04:00:00+00	185	1
1587		2017-06-10 04:00:00+00	185	1
1588	18.1	2017-06-11 04:00:00+00	185	1
1589		2017-06-12 04:00:00+00	185	1
1590	4.7	2017-06-18 04:00:00+00	185	1
1591		2017-06-19 04:00:00+00	185	1
1592		2017-06-22 04:00:00+00	185	1
1593		2017-06-23 04:00:00+00	185	1
1594	0.5	2017-06-25 04:00:00+00	185	1
1595		2017-06-26 04:00:00+00	185	1
1596	1.9	2017-07-02 04:00:00+00	185	1
1597		2017-07-05 04:00:00+00	185	1
1598	0.6	2017-07-09 04:00:00+00	185	1
1599		2017-07-10 04:00:00+00	185	1
1600		2017-07-14 04:00:00+00	185	1
1601	0.5	2017-07-16 04:00:00+00	185	1
1602		2017-07-17 04:00:00+00	185	1
1603	0.5	2017-07-23 04:00:00+00	185	1
1604		2017-07-24 04:00:00+00	185	1
1605	0.8	2017-07-30 04:00:00+00	185	1
1606		2017-07-31 04:00:00+00	185	1
1607	0.6	2017-08-06 04:00:00+00	185	1
1608		2017-08-07 04:00:00+00	185	1
1609		2017-08-08 04:00:00+00	185	1
1610	0.6	2017-08-13 04:00:00+00	185	1
1611		2017-08-14 04:00:00+00	185	1
1612		2017-08-17 04:00:00+00	185	1
1613	0	2017-08-20 04:00:00+00	185	1
1614		2017-08-21 04:00:00+00	185	1
1615		2017-08-22 04:00:00+00	185	1
1616		2017-08-23 04:00:00+00	185	1
1617		2017-09-03 04:00:00+00	185	1
1618		2017-09-04 04:00:00+00	185	1
1619		2017-09-05 04:00:00+00	185	1
1620		2017-09-10 04:00:00+00	185	1
1621		2017-09-11 04:00:00+00	185	1
1622		2017-09-17 04:00:00+00	185	1
1623		2017-09-18 04:00:00+00	185	1
1624		2017-10-02 04:00:00+00	185	1
1625		2017-10-10 04:00:00+00	185	1
1626		2017-10-15 04:00:00+00	185	1
1627		2017-10-16 04:00:00+00	185	1
1628	0	2018-03-12 04:00:00+00	185	1
1897	2.3	2017-07-16 04:00:00+00	187	1
1898		2017-07-17 04:00:00+00	187	1
1899	2	2017-07-23 04:00:00+00	187	1
1900		2017-07-24 04:00:00+00	187	1
1901	0.7	2017-07-30 04:00:00+00	187	1
1902		2017-07-31 04:00:00+00	187	1
1903	0	2017-08-06 04:00:00+00	187	1
1904		2017-08-07 04:00:00+00	187	1
1905		2017-08-08 04:00:00+00	187	1
1906	0	2017-08-13 04:00:00+00	187	1
1907		2017-08-14 04:00:00+00	187	1
1908		2017-08-17 04:00:00+00	187	1
1909	0	2017-08-20 04:00:00+00	187	1
1910		2017-08-21 04:00:00+00	187	1
1911		2017-08-22 04:00:00+00	187	1
1912		2017-08-23 04:00:00+00	187	1
1913		2017-09-03 04:00:00+00	187	1
1914		2017-09-04 04:00:00+00	187	1
1915		2017-09-05 04:00:00+00	187	1
1916		2017-09-10 04:00:00+00	187	1
1917		2017-09-11 04:00:00+00	187	1
1918		2017-09-17 04:00:00+00	187	1
1919		2017-09-18 04:00:00+00	187	1
1920		2017-10-02 04:00:00+00	187	1
1921		2017-10-10 04:00:00+00	187	1
1922		2017-10-15 04:00:00+00	187	1
1923		2017-10-16 04:00:00+00	187	1
1924		2018-03-12 04:00:00+00	187	1
2029		2017-06-05 04:00:00+00	188	1
2030		2017-06-09 04:00:00+00	188	1
2031		2017-06-10 04:00:00+00	188	1
2032	0.9	2017-06-11 04:00:00+00	188	1
2033		2017-06-12 04:00:00+00	188	1
2034	0.4	2017-06-18 04:00:00+00	188	1
2035		2017-06-19 04:00:00+00	188	1
2036		2017-06-22 04:00:00+00	188	1
2591		2017-03-12 05:00:00+00	192	1
2592		2017-03-19 04:00:00+00	192	1
2593	0	2017-03-26 04:00:00+00	192	1
2594		2017-03-27 04:00:00+00	192	1
2595		2017-04-02 04:00:00+00	192	1
2596		2017-04-03 04:00:00+00	192	1
2597	0.4	2017-04-09 04:00:00+00	192	1
2598		2017-04-10 04:00:00+00	192	1
2599		2017-04-11 04:00:00+00	192	1
2600		2017-04-16 04:00:00+00	192	1
2601		2017-04-17 04:00:00+00	192	1
2602		2017-04-20 04:00:00+00	192	1
2603	1.9	2017-04-23 04:00:00+00	192	1
2604		2017-04-24 04:00:00+00	192	1
2605		2017-04-25 04:00:00+00	192	1
2606	2.3	2017-04-30 04:00:00+00	192	1
2607		2017-05-01 04:00:00+00	192	1
2608	1.7	2017-05-07 04:00:00+00	192	1
2609		2017-05-08 04:00:00+00	192	1
2610		2017-05-09 04:00:00+00	192	1
2611		2017-05-10 04:00:00+00	192	1
2612	3.6	2017-05-14 04:00:00+00	192	1
2613		2017-05-15 04:00:00+00	192	1
2614	12.8	2017-05-21 04:00:00+00	192	1
2615		2017-05-22 04:00:00+00	192	1
2616	9.4	2017-05-28 04:00:00+00	192	1
2617		2017-05-29 04:00:00+00	192	1
2618		2017-05-30 04:00:00+00	192	1
2619		2017-06-02 04:00:00+00	192	1
2620	8.8	2017-06-04 04:00:00+00	192	1
2621		2017-06-05 04:00:00+00	192	1
2622		2017-06-09 04:00:00+00	192	1
2623		2017-06-10 04:00:00+00	192	1
2624	8	2017-06-11 04:00:00+00	192	1
2625		2017-06-12 04:00:00+00	192	1
2626	4.1	2017-06-18 04:00:00+00	192	1
1703		2017-03-12 05:00:00+00	186	1
1704		2017-03-19 04:00:00+00	186	1
1705	0	2017-03-26 04:00:00+00	186	1
1706		2017-03-27 04:00:00+00	186	1
1707		2017-04-02 04:00:00+00	186	1
1708		2017-04-03 04:00:00+00	186	1
1709	0	2017-04-09 04:00:00+00	186	1
1710		2017-04-10 04:00:00+00	186	1
1711		2017-04-11 04:00:00+00	186	1
1712		2017-04-16 04:00:00+00	186	1
1713		2017-04-17 04:00:00+00	186	1
1714		2017-04-20 04:00:00+00	186	1
1715	0	2017-04-23 04:00:00+00	186	1
1716		2017-04-24 04:00:00+00	186	1
1717		2017-04-25 04:00:00+00	186	1
1718	0.4	2017-04-30 04:00:00+00	186	1
1719		2017-05-01 04:00:00+00	186	1
1720	0	2017-05-07 04:00:00+00	186	1
1721		2017-05-08 04:00:00+00	186	1
1722		2017-05-09 04:00:00+00	186	1
1723		2017-05-10 04:00:00+00	186	1
1724	0.3	2017-05-14 04:00:00+00	186	1
1725		2017-05-15 04:00:00+00	186	1
1726	0.9	2017-05-21 04:00:00+00	186	1
1727		2017-05-22 04:00:00+00	186	1
1728	1	2017-05-28 04:00:00+00	186	1
1729		2017-05-29 04:00:00+00	186	1
1730		2017-05-30 04:00:00+00	186	1
1731		2017-06-02 04:00:00+00	186	1
1732	1	2017-06-04 04:00:00+00	186	1
1733		2017-06-05 04:00:00+00	186	1
1734		2017-06-09 04:00:00+00	186	1
1735		2017-06-10 04:00:00+00	186	1
1736	1.7	2017-06-11 04:00:00+00	186	1
1737		2017-06-12 04:00:00+00	186	1
1738	0.9	2017-06-18 04:00:00+00	186	1
1739		2017-06-19 04:00:00+00	186	1
1740		2017-06-22 04:00:00+00	186	1
1741		2017-06-23 04:00:00+00	186	1
1742	0.6	2017-06-25 04:00:00+00	186	1
1743		2017-06-26 04:00:00+00	186	1
1744	0.2	2017-07-02 04:00:00+00	186	1
1745		2017-07-05 04:00:00+00	186	1
1746	0	2017-07-09 04:00:00+00	186	1
1747		2017-07-10 04:00:00+00	186	1
1748		2017-07-14 04:00:00+00	186	1
1749	0	2017-07-16 04:00:00+00	186	1
1750		2017-07-17 04:00:00+00	186	1
1751	0	2017-07-23 04:00:00+00	186	1
1752		2017-07-24 04:00:00+00	186	1
1753	0.2	2017-07-30 04:00:00+00	186	1
1754		2017-07-31 04:00:00+00	186	1
1755	0	2017-08-06 04:00:00+00	186	1
1756		2017-08-07 04:00:00+00	186	1
1757		2017-08-08 04:00:00+00	186	1
1758	0	2017-08-13 04:00:00+00	186	1
1759		2017-08-14 04:00:00+00	186	1
1760		2017-08-17 04:00:00+00	186	1
1761	0	2017-08-20 04:00:00+00	186	1
1762		2017-08-21 04:00:00+00	186	1
1763		2017-08-22 04:00:00+00	186	1
1764		2017-08-23 04:00:00+00	186	1
1765		2017-09-03 04:00:00+00	186	1
1766		2017-09-04 04:00:00+00	186	1
1767		2017-09-05 04:00:00+00	186	1
1768		2017-09-10 04:00:00+00	186	1
1769		2017-09-11 04:00:00+00	186	1
1770		2017-09-17 04:00:00+00	186	1
1771		2017-09-18 04:00:00+00	186	1
1772		2017-10-02 04:00:00+00	186	1
1773		2017-10-10 04:00:00+00	186	1
1774		2017-10-15 04:00:00+00	186	1
1775		2017-10-16 04:00:00+00	186	1
1776		2018-03-12 04:00:00+00	186	1
2627		2017-06-19 04:00:00+00	192	1
2628		2017-06-22 04:00:00+00	192	1
2629		2017-06-23 04:00:00+00	192	1
2630	14.9	2017-06-25 04:00:00+00	192	1
2631		2017-06-26 04:00:00+00	192	1
2632	37.1	2017-07-02 04:00:00+00	192	1
2633		2017-07-05 04:00:00+00	192	1
2634	88.3	2017-07-09 04:00:00+00	192	1
2635		2017-07-10 04:00:00+00	192	1
2636		2017-07-14 04:00:00+00	192	1
2637	218.1	2017-07-16 04:00:00+00	192	1
2638		2017-07-17 04:00:00+00	192	1
2639	73.4	2017-07-23 04:00:00+00	192	1
2640		2017-07-24 04:00:00+00	192	1
2641	37.8	2017-07-30 04:00:00+00	192	1
2642		2017-07-31 04:00:00+00	192	1
2643	6.6	2017-08-06 04:00:00+00	192	1
2644		2017-08-07 04:00:00+00	192	1
2645		2017-08-08 04:00:00+00	192	1
2646	1.7	2017-08-13 04:00:00+00	192	1
2647		2017-08-14 04:00:00+00	192	1
2648		2017-08-17 04:00:00+00	192	1
2649	0.9	2017-08-20 04:00:00+00	192	1
2650		2017-08-21 04:00:00+00	192	1
2651		2017-08-22 04:00:00+00	192	1
2652		2017-08-23 04:00:00+00	192	1
2653		2017-09-03 04:00:00+00	192	1
2654		2017-09-04 04:00:00+00	192	1
2655		2017-09-05 04:00:00+00	192	1
2656		2017-09-10 04:00:00+00	192	1
2657		2017-09-11 04:00:00+00	192	1
2658		2017-09-17 04:00:00+00	192	1
2659		2017-09-18 04:00:00+00	192	1
2660		2017-10-02 04:00:00+00	192	1
2037		2017-06-23 04:00:00+00	188	1
2038	0.5	2017-06-25 04:00:00+00	188	1
2039		2017-06-26 04:00:00+00	188	1
2040	0.5	2017-07-02 04:00:00+00	188	1
2041		2017-07-05 04:00:00+00	188	1
2042	0.7	2017-07-09 04:00:00+00	188	1
2043		2017-07-10 04:00:00+00	188	1
2044		2017-07-14 04:00:00+00	188	1
2045	1	2017-07-16 04:00:00+00	188	1
2046		2017-07-17 04:00:00+00	188	1
2047	2.7	2017-07-23 04:00:00+00	188	1
2048		2017-07-24 04:00:00+00	188	1
2049	1	2017-07-30 04:00:00+00	188	1
2050		2017-07-31 04:00:00+00	188	1
2051	0	2017-08-06 04:00:00+00	188	1
2052		2017-08-07 04:00:00+00	188	1
2053		2017-08-08 04:00:00+00	188	1
2054	0.5	2017-08-13 04:00:00+00	188	1
2055		2017-08-14 04:00:00+00	188	1
2056		2017-08-17 04:00:00+00	188	1
2057	0	2017-08-20 04:00:00+00	188	1
2058		2017-08-21 04:00:00+00	188	1
2059		2017-08-22 04:00:00+00	188	1
2060		2017-08-23 04:00:00+00	188	1
2061		2017-09-03 04:00:00+00	188	1
2062		2017-09-04 04:00:00+00	188	1
2063		2017-09-05 04:00:00+00	188	1
2064		2017-09-10 04:00:00+00	188	1
2065		2017-09-11 04:00:00+00	188	1
2066		2017-09-17 04:00:00+00	188	1
2067		2017-09-18 04:00:00+00	188	1
2068		2017-10-02 04:00:00+00	188	1
2069		2017-10-10 04:00:00+00	188	1
2070		2017-10-15 04:00:00+00	188	1
2071		2017-10-16 04:00:00+00	188	1
2072		2018-03-12 04:00:00+00	188	1
2443		2017-03-12 05:00:00+00	191	1
2444		2017-03-19 04:00:00+00	191	1
2445	0	2017-03-26 04:00:00+00	191	1
2446		2017-03-27 04:00:00+00	191	1
2447		2017-04-02 04:00:00+00	191	1
2448		2017-04-03 04:00:00+00	191	1
2449	0	2017-04-09 04:00:00+00	191	1
2450		2017-04-10 04:00:00+00	191	1
2451		2017-04-11 04:00:00+00	191	1
2452		2017-04-16 04:00:00+00	191	1
2453		2017-04-17 04:00:00+00	191	1
2454		2017-04-20 04:00:00+00	191	1
2455	0.8	2017-04-23 04:00:00+00	191	1
2456		2017-04-24 04:00:00+00	191	1
2457		2017-04-25 04:00:00+00	191	1
2458	3.8	2017-04-30 04:00:00+00	191	1
2459		2017-05-01 04:00:00+00	191	1
2460	3.1	2017-05-07 04:00:00+00	191	1
2461		2017-05-08 04:00:00+00	191	1
2462		2017-05-09 04:00:00+00	191	1
2463		2017-05-10 04:00:00+00	191	1
2464	31.9	2017-05-14 04:00:00+00	191	1
2465		2017-05-15 04:00:00+00	191	1
2466	42	2017-05-21 04:00:00+00	191	1
2467		2017-05-22 04:00:00+00	191	1
2468	13.6	2017-05-28 04:00:00+00	191	1
2469		2017-05-29 04:00:00+00	191	1
2470		2017-05-30 04:00:00+00	191	1
2471		2017-06-02 04:00:00+00	191	1
2472	0.8	2017-06-04 04:00:00+00	191	1
2473		2017-06-05 04:00:00+00	191	1
2474		2017-06-09 04:00:00+00	191	1
2475		2017-06-10 04:00:00+00	191	1
2476	7	2017-06-11 04:00:00+00	191	1
2477		2017-06-12 04:00:00+00	191	1
2478	5.9	2017-06-18 04:00:00+00	191	1
2479		2017-06-19 04:00:00+00	191	1
2480		2017-06-22 04:00:00+00	191	1
2481		2017-06-23 04:00:00+00	191	1
2482	2.4	2017-06-25 04:00:00+00	191	1
2483		2017-06-26 04:00:00+00	191	1
2484	2	2017-07-02 04:00:00+00	191	1
2485		2017-07-05 04:00:00+00	191	1
2486	1.5	2017-07-09 04:00:00+00	191	1
2487		2017-07-10 04:00:00+00	191	1
2488		2017-07-14 04:00:00+00	191	1
2489	91.1	2017-07-16 04:00:00+00	191	1
2490		2017-07-17 04:00:00+00	191	1
2491	43.6	2017-07-23 04:00:00+00	191	1
2492		2017-07-24 04:00:00+00	191	1
2493	45.8	2017-07-30 04:00:00+00	191	1
2494		2017-07-31 04:00:00+00	191	1
2495	7.5	2017-08-06 04:00:00+00	191	1
2496		2017-08-07 04:00:00+00	191	1
2497		2017-08-08 04:00:00+00	191	1
2498	3.5	2017-08-13 04:00:00+00	191	1
2499		2017-08-14 04:00:00+00	191	1
2500		2017-08-17 04:00:00+00	191	1
2501	0.8	2017-08-20 04:00:00+00	191	1
2502		2017-08-21 04:00:00+00	191	1
2503		2017-08-22 04:00:00+00	191	1
2504		2017-08-23 04:00:00+00	191	1
2505		2017-09-03 04:00:00+00	191	1
2506		2017-09-04 04:00:00+00	191	1
2507		2017-09-05 04:00:00+00	191	1
2508		2017-09-10 04:00:00+00	191	1
2509		2017-09-11 04:00:00+00	191	1
2510		2017-09-17 04:00:00+00	191	1
2511		2017-09-18 04:00:00+00	191	1
2512		2017-10-02 04:00:00+00	191	1
2513		2017-10-10 04:00:00+00	191	1
2514		2017-10-15 04:00:00+00	191	1
2515		2017-10-16 04:00:00+00	191	1
2147		2017-03-12 05:00:00+00	189	1
2148		2017-03-19 04:00:00+00	189	1
2149	0	2017-03-26 04:00:00+00	189	1
2150		2017-03-27 04:00:00+00	189	1
2151		2017-04-02 04:00:00+00	189	1
2152		2017-04-03 04:00:00+00	189	1
2153	0	2017-04-09 04:00:00+00	189	1
2154		2017-04-10 04:00:00+00	189	1
2155		2017-04-11 04:00:00+00	189	1
2156		2017-04-16 04:00:00+00	189	1
2157		2017-04-17 04:00:00+00	189	1
2158		2017-04-20 04:00:00+00	189	1
2159	0	2017-04-23 04:00:00+00	189	1
2160		2017-04-24 04:00:00+00	189	1
2161		2017-04-25 04:00:00+00	189	1
2162	0.3	2017-04-30 04:00:00+00	189	1
2163		2017-05-01 04:00:00+00	189	1
2164	0.4	2017-05-07 04:00:00+00	189	1
2165		2017-05-08 04:00:00+00	189	1
2166		2017-05-09 04:00:00+00	189	1
2167		2017-05-10 04:00:00+00	189	1
2168	0	2017-05-14 04:00:00+00	189	1
2169		2017-05-15 04:00:00+00	189	1
2170	0	2017-05-21 04:00:00+00	189	1
2171		2017-05-22 04:00:00+00	189	1
2172	0	2017-05-28 04:00:00+00	189	1
2173		2017-05-29 04:00:00+00	189	1
2174		2017-05-30 04:00:00+00	189	1
2175		2017-06-02 04:00:00+00	189	1
2176	0	2017-06-04 04:00:00+00	189	1
2177		2017-06-05 04:00:00+00	189	1
2178		2017-06-09 04:00:00+00	189	1
2179		2017-06-10 04:00:00+00	189	1
2180	0	2017-06-11 04:00:00+00	189	1
2181		2017-06-12 04:00:00+00	189	1
2182	0	2017-06-18 04:00:00+00	189	1
2183		2017-06-19 04:00:00+00	189	1
2184		2017-06-22 04:00:00+00	189	1
2185		2017-06-23 04:00:00+00	189	1
2186	0	2017-06-25 04:00:00+00	189	1
2187		2017-06-26 04:00:00+00	189	1
2188	0	2017-07-02 04:00:00+00	189	1
2189		2017-07-05 04:00:00+00	189	1
2190	0	2017-07-09 04:00:00+00	189	1
2191		2017-07-10 04:00:00+00	189	1
2192		2017-07-14 04:00:00+00	189	1
2193	0	2017-07-16 04:00:00+00	189	1
2194		2017-07-17 04:00:00+00	189	1
2195	0	2017-07-23 04:00:00+00	189	1
2196		2017-07-24 04:00:00+00	189	1
2197	0	2017-07-30 04:00:00+00	189	1
2198		2017-07-31 04:00:00+00	189	1
2199	0.2	2017-08-06 04:00:00+00	189	1
2200		2017-08-07 04:00:00+00	189	1
2201		2017-08-08 04:00:00+00	189	1
2202	0	2017-08-13 04:00:00+00	189	1
2203		2017-08-14 04:00:00+00	189	1
2204		2017-08-17 04:00:00+00	189	1
2205	0	2017-08-20 04:00:00+00	189	1
2206		2017-08-21 04:00:00+00	189	1
2207		2017-08-22 04:00:00+00	189	1
2208		2017-08-23 04:00:00+00	189	1
2209		2017-09-03 04:00:00+00	189	1
2210		2017-09-04 04:00:00+00	189	1
2211		2017-09-05 04:00:00+00	189	1
2212		2017-09-10 04:00:00+00	189	1
2213		2017-09-11 04:00:00+00	189	1
2214		2017-09-17 04:00:00+00	189	1
2215		2017-09-18 04:00:00+00	189	1
2216		2017-10-02 04:00:00+00	189	1
2217		2017-10-10 04:00:00+00	189	1
2218		2017-10-15 04:00:00+00	189	1
2219		2017-10-16 04:00:00+00	189	1
2220		2018-03-12 04:00:00+00	189	1
2516		2018-03-12 04:00:00+00	191	1
2661		2017-10-10 04:00:00+00	192	1
2662		2017-10-15 04:00:00+00	192	1
2663		2017-10-16 04:00:00+00	192	1
2664		2018-03-12 04:00:00+00	192	1
3183		2017-03-12 05:00:00+00	197	1
3184		2017-03-19 04:00:00+00	197	1
2739		2017-03-12 05:00:00+00	193	1
2740		2017-03-19 04:00:00+00	193	1
2741	0	2017-03-26 04:00:00+00	193	1
2742		2017-03-27 04:00:00+00	193	1
2743		2017-04-02 04:00:00+00	193	1
2744		2017-04-03 04:00:00+00	193	1
2745	0.3	2017-04-09 04:00:00+00	193	1
2746		2017-04-10 04:00:00+00	193	1
2747		2017-04-11 04:00:00+00	193	1
2748		2017-04-16 04:00:00+00	193	1
2749		2017-04-17 04:00:00+00	193	1
2750		2017-04-20 04:00:00+00	193	1
2751	1	2017-04-23 04:00:00+00	193	1
2752		2017-04-24 04:00:00+00	193	1
2753		2017-04-25 04:00:00+00	193	1
2754	1.5	2017-04-30 04:00:00+00	193	1
2755		2017-05-01 04:00:00+00	193	1
2756	1.4	2017-05-07 04:00:00+00	193	1
2757		2017-05-08 04:00:00+00	193	1
2758		2017-05-09 04:00:00+00	193	1
2759		2017-05-10 04:00:00+00	193	1
2760	3.1	2017-05-14 04:00:00+00	193	1
2761		2017-05-15 04:00:00+00	193	1
2762	4.8	2017-05-21 04:00:00+00	193	1
2763		2017-05-22 04:00:00+00	193	1
2764	2.8	2017-05-28 04:00:00+00	193	1
2765		2017-05-29 04:00:00+00	193	1
2766		2017-05-30 04:00:00+00	193	1
2767		2017-06-02 04:00:00+00	193	1
2768	10.9	2017-06-04 04:00:00+00	193	1
2769		2017-06-05 04:00:00+00	193	1
2770		2017-06-09 04:00:00+00	193	1
2771		2017-06-10 04:00:00+00	193	1
2772	7	2017-06-11 04:00:00+00	193	1
2773		2017-06-12 04:00:00+00	193	1
2774	13	2017-06-18 04:00:00+00	193	1
2775		2017-06-19 04:00:00+00	193	1
2776		2017-06-22 04:00:00+00	193	1
2777		2017-06-23 04:00:00+00	193	1
2778	11.1	2017-06-25 04:00:00+00	193	1
2779		2017-06-26 04:00:00+00	193	1
2780	11.4	2017-07-02 04:00:00+00	193	1
2781		2017-07-05 04:00:00+00	193	1
2782	44.9	2017-07-09 04:00:00+00	193	1
2783		2017-07-10 04:00:00+00	193	1
2784		2017-07-14 04:00:00+00	193	1
2785	112.9	2017-07-16 04:00:00+00	193	1
2786		2017-07-17 04:00:00+00	193	1
2787	61	2017-07-23 04:00:00+00	193	1
2788		2017-07-24 04:00:00+00	193	1
2789	32	2017-07-30 04:00:00+00	193	1
2790		2017-07-31 04:00:00+00	193	1
2791	3.1	2017-08-06 04:00:00+00	193	1
2792		2017-08-07 04:00:00+00	193	1
2793		2017-08-08 04:00:00+00	193	1
2794	0	2017-08-13 04:00:00+00	193	1
2795		2017-08-14 04:00:00+00	193	1
2796		2017-08-17 04:00:00+00	193	1
2797	0.5	2017-08-20 04:00:00+00	193	1
2798		2017-08-21 04:00:00+00	193	1
2799		2017-08-22 04:00:00+00	193	1
2800		2017-08-23 04:00:00+00	193	1
2801		2017-09-03 04:00:00+00	193	1
2802		2017-09-04 04:00:00+00	193	1
2803		2017-09-05 04:00:00+00	193	1
2804		2017-09-10 04:00:00+00	193	1
2295		2017-03-12 05:00:00+00	190	1
2296		2017-03-19 04:00:00+00	190	1
2297	0	2017-03-26 04:00:00+00	190	1
2298		2017-03-27 04:00:00+00	190	1
2299		2017-04-02 04:00:00+00	190	1
2300		2017-04-03 04:00:00+00	190	1
2301	0	2017-04-09 04:00:00+00	190	1
2302		2017-04-10 04:00:00+00	190	1
2303		2017-04-11 04:00:00+00	190	1
2304		2017-04-16 04:00:00+00	190	1
2305		2017-04-17 04:00:00+00	190	1
2306		2017-04-20 04:00:00+00	190	1
2307	0	2017-04-23 04:00:00+00	190	1
2308		2017-04-24 04:00:00+00	190	1
2309		2017-04-25 04:00:00+00	190	1
2310	1.3	2017-04-30 04:00:00+00	190	1
2311		2017-05-01 04:00:00+00	190	1
2312	0.4	2017-05-07 04:00:00+00	190	1
2313		2017-05-08 04:00:00+00	190	1
2314		2017-05-09 04:00:00+00	190	1
2315		2017-05-10 04:00:00+00	190	1
2316	0.7	2017-05-14 04:00:00+00	190	1
2317		2017-05-15 04:00:00+00	190	1
2318	1.6	2017-05-21 04:00:00+00	190	1
2319		2017-05-22 04:00:00+00	190	1
2320	0.9	2017-05-28 04:00:00+00	190	1
2321		2017-05-29 04:00:00+00	190	1
2322		2017-05-30 04:00:00+00	190	1
2323		2017-06-02 04:00:00+00	190	1
2324	0.8	2017-06-04 04:00:00+00	190	1
2325		2017-06-05 04:00:00+00	190	1
2326		2017-06-09 04:00:00+00	190	1
2327		2017-06-10 04:00:00+00	190	1
2328	0.6	2017-06-11 04:00:00+00	190	1
2329		2017-06-12 04:00:00+00	190	1
2330	0	2017-06-18 04:00:00+00	190	1
2331		2017-06-19 04:00:00+00	190	1
2332		2017-06-22 04:00:00+00	190	1
2333		2017-06-23 04:00:00+00	190	1
2334	0.4	2017-06-25 04:00:00+00	190	1
2335		2017-06-26 04:00:00+00	190	1
2336	0	2017-07-02 04:00:00+00	190	1
2337		2017-07-05 04:00:00+00	190	1
2338	0.1	2017-07-09 04:00:00+00	190	1
2339		2017-07-10 04:00:00+00	190	1
2340		2017-07-14 04:00:00+00	190	1
2341	1.1	2017-07-16 04:00:00+00	190	1
2342		2017-07-17 04:00:00+00	190	1
2343	0.5	2017-07-23 04:00:00+00	190	1
2344		2017-07-24 04:00:00+00	190	1
2345	0	2017-07-30 04:00:00+00	190	1
2346		2017-07-31 04:00:00+00	190	1
2347	0	2017-08-06 04:00:00+00	190	1
2348		2017-08-07 04:00:00+00	190	1
2349		2017-08-08 04:00:00+00	190	1
2350	0	2017-08-13 04:00:00+00	190	1
2351		2017-08-14 04:00:00+00	190	1
2352		2017-08-17 04:00:00+00	190	1
2353	0	2017-08-20 04:00:00+00	190	1
2354		2017-08-21 04:00:00+00	190	1
2355		2017-08-22 04:00:00+00	190	1
2356		2017-08-23 04:00:00+00	190	1
2357		2017-09-03 04:00:00+00	190	1
2358		2017-09-04 04:00:00+00	190	1
2359		2017-09-05 04:00:00+00	190	1
2360		2017-09-10 04:00:00+00	190	1
2361		2017-09-11 04:00:00+00	190	1
2362		2017-09-17 04:00:00+00	190	1
2363		2017-09-18 04:00:00+00	190	1
2364		2017-10-02 04:00:00+00	190	1
2365		2017-10-10 04:00:00+00	190	1
2366		2017-10-15 04:00:00+00	190	1
2367		2017-10-16 04:00:00+00	190	1
2368		2018-03-12 04:00:00+00	190	1
3185		2017-03-26 04:00:00+00	197	1
3186		2017-03-27 04:00:00+00	197	1
3187		2017-04-02 04:00:00+00	197	1
3188	<39	2017-04-03 04:00:00+00	197	1
3189		2017-04-09 04:00:00+00	197	1
3190	<40	2017-04-10 04:00:00+00	197	1
3191		2017-04-11 04:00:00+00	197	1
3192		2017-04-16 04:00:00+00	197	1
3193	<39	2017-04-17 04:00:00+00	197	1
3194		2017-04-20 04:00:00+00	197	1
3195		2017-04-23 04:00:00+00	197	1
3196		2017-04-24 04:00:00+00	197	1
3197	<40	2017-04-25 04:00:00+00	197	1
3198		2017-04-30 04:00:00+00	197	1
3199	<39	2017-05-01 04:00:00+00	197	1
3200		2017-05-07 04:00:00+00	197	1
3201	<38	2017-05-08 04:00:00+00	197	1
3202		2017-05-09 04:00:00+00	197	1
3203		2017-05-10 04:00:00+00	197	1
3204		2017-05-14 04:00:00+00	197	1
3205	<41	2017-05-15 04:00:00+00	197	1
3206		2017-05-21 04:00:00+00	197	1
3207	<40	2017-05-22 04:00:00+00	197	1
3208		2017-05-28 04:00:00+00	197	1
3209		2017-05-29 04:00:00+00	197	1
3210	<40	2017-05-30 04:00:00+00	197	1
3211		2017-06-02 04:00:00+00	197	1
3212		2017-06-04 04:00:00+00	197	1
3213	<40	2017-06-05 04:00:00+00	197	1
3214		2017-06-09 04:00:00+00	197	1
3215		2017-06-10 04:00:00+00	197	1
3216		2017-06-11 04:00:00+00	197	1
3217	<40	2017-06-12 04:00:00+00	197	1
3218		2017-06-18 04:00:00+00	197	1
3219	<42	2017-06-19 04:00:00+00	197	1
3220		2017-06-22 04:00:00+00	197	1
3221		2017-06-23 04:00:00+00	197	1
3222		2017-06-25 04:00:00+00	197	1
3223	<39	2017-06-26 04:00:00+00	197	1
3224		2017-07-02 04:00:00+00	197	1
3225		2017-07-05 04:00:00+00	197	1
3226		2017-07-09 04:00:00+00	197	1
3227		2017-07-10 04:00:00+00	197	1
3228		2017-07-14 04:00:00+00	197	1
3229		2017-07-16 04:00:00+00	197	1
3230	<40	2017-07-17 04:00:00+00	197	1
3231		2017-07-23 04:00:00+00	197	1
3232	<40	2017-07-24 04:00:00+00	197	1
3233		2017-07-30 04:00:00+00	197	1
3234	<40	2017-07-31 04:00:00+00	197	1
3235		2017-08-06 04:00:00+00	197	1
3236	<40	2017-08-07 04:00:00+00	197	1
3237		2017-08-08 04:00:00+00	197	1
3238		2017-08-13 04:00:00+00	197	1
3239	<41	2017-08-14 04:00:00+00	197	1
3240		2017-08-17 04:00:00+00	197	1
3241		2017-08-20 04:00:00+00	197	1
3242		2017-08-21 04:00:00+00	197	1
3243		2017-08-22 04:00:00+00	197	1
3244		2017-08-23 04:00:00+00	197	1
3245		2017-09-03 04:00:00+00	197	1
3246		2017-09-04 04:00:00+00	197	1
3247	<40	2017-09-05 04:00:00+00	197	1
3248		2017-09-10 04:00:00+00	197	1
3249	<40	2017-09-11 04:00:00+00	197	1
3250		2017-09-17 04:00:00+00	197	1
3251	<39	2017-09-18 04:00:00+00	197	1
3252		2017-10-02 04:00:00+00	197	1
3253		2017-10-10 04:00:00+00	197	1
3254		2017-10-15 04:00:00+00	197	1
3255	<40	2017-10-16 04:00:00+00	197	1
3256		2018-03-12 04:00:00+00	197	1
4071		2017-03-12 05:00:00+00	203	1
4072		2017-03-19 04:00:00+00	203	1
4073		2017-03-26 04:00:00+00	203	1
4074		2017-03-27 04:00:00+00	203	1
4075		2017-04-02 04:00:00+00	203	1
4076	<39	2017-04-03 04:00:00+00	203	1
4077		2017-04-09 04:00:00+00	203	1
4078	<39	2017-04-10 04:00:00+00	203	1
4079		2017-04-11 04:00:00+00	203	1
4080		2017-04-16 04:00:00+00	203	1
4081		2017-04-17 04:00:00+00	203	1
4082	<37	2017-04-20 04:00:00+00	203	1
4083		2017-04-23 04:00:00+00	203	1
4084		2017-04-24 04:00:00+00	203	1
4085	<40	2017-04-25 04:00:00+00	203	1
4086		2017-04-30 04:00:00+00	203	1
4087	<40	2017-05-01 04:00:00+00	203	1
4088		2017-05-07 04:00:00+00	203	1
4089	<39	2017-05-08 04:00:00+00	203	1
4090		2017-05-09 04:00:00+00	203	1
4091		2017-05-10 04:00:00+00	203	1
4092		2017-05-14 04:00:00+00	203	1
4093	<39	2017-05-15 04:00:00+00	203	1
4094		2017-05-21 04:00:00+00	203	1
4095	<41	2017-05-22 04:00:00+00	203	1
4096		2017-05-28 04:00:00+00	203	1
4097		2017-05-29 04:00:00+00	203	1
4098	<40	2017-05-30 04:00:00+00	203	1
4099		2017-06-02 04:00:00+00	203	1
4100		2017-06-04 04:00:00+00	203	1
4101	<39	2017-06-05 04:00:00+00	203	1
4102		2017-06-09 04:00:00+00	203	1
4103		2017-06-10 04:00:00+00	203	1
4104		2017-06-11 04:00:00+00	203	1
4105	<39	2017-06-12 04:00:00+00	203	1
4106	<40	2017-06-18 04:00:00+00	203	1
4107		2017-06-19 04:00:00+00	203	1
4108		2017-06-22 04:00:00+00	203	1
4109		2017-06-23 04:00:00+00	203	1
4110		2017-06-25 04:00:00+00	203	1
4111	<40	2017-06-26 04:00:00+00	203	1
4112		2017-07-02 04:00:00+00	203	1
4113		2017-07-05 04:00:00+00	203	1
4114		2017-07-09 04:00:00+00	203	1
4115		2017-07-10 04:00:00+00	203	1
4116		2017-07-14 04:00:00+00	203	1
4117		2017-07-16 04:00:00+00	203	1
4118	<40	2017-07-17 04:00:00+00	203	1
4119		2017-07-23 04:00:00+00	203	1
4120	<39	2017-07-24 04:00:00+00	203	1
4121		2017-07-30 04:00:00+00	203	1
4122	<40	2017-07-31 04:00:00+00	203	1
4123		2017-08-06 04:00:00+00	203	1
4124	<39	2017-08-07 04:00:00+00	203	1
4125		2017-08-08 04:00:00+00	203	1
4126		2017-08-13 04:00:00+00	203	1
4127	<41	2017-08-14 04:00:00+00	203	1
4128		2017-08-17 04:00:00+00	203	1
4129		2017-08-20 04:00:00+00	203	1
4130	<40	2017-08-21 04:00:00+00	203	1
4131		2017-08-22 04:00:00+00	203	1
4132		2017-08-23 04:00:00+00	203	1
4133		2017-09-03 04:00:00+00	203	1
4134		2017-09-04 04:00:00+00	203	1
4135	<38	2017-09-05 04:00:00+00	203	1
4136		2017-09-10 04:00:00+00	203	1
4137	<39	2017-09-11 04:00:00+00	203	1
4138		2017-09-17 04:00:00+00	203	1
4139	<39	2017-09-18 04:00:00+00	203	1
4140		2017-10-02 04:00:00+00	203	1
4141		2017-10-10 04:00:00+00	203	1
4142		2017-10-15 04:00:00+00	203	1
4143	<40	2017-10-16 04:00:00+00	203	1
3487		2017-04-11 04:00:00+00	199	1
3488		2017-04-16 04:00:00+00	199	1
3489	<40	2017-04-17 04:00:00+00	199	1
2805		2017-09-11 04:00:00+00	193	1
2806		2017-09-17 04:00:00+00	193	1
2807		2017-09-18 04:00:00+00	193	1
2808		2017-10-02 04:00:00+00	193	1
2809		2017-10-10 04:00:00+00	193	1
2810		2017-10-15 04:00:00+00	193	1
2811		2017-10-16 04:00:00+00	193	1
2812		2018-03-12 04:00:00+00	193	1
4144		2018-03-12 04:00:00+00	203	1
5107		2017-03-12 05:00:00+00	210	1
5108		2017-03-19 04:00:00+00	210	1
5109		2017-03-26 04:00:00+00	210	1
5110		2017-03-27 04:00:00+00	210	1
5111		2017-04-02 04:00:00+00	210	1
5112		2017-04-03 04:00:00+00	210	1
5113		2017-04-09 04:00:00+00	210	1
5114	<39	2017-04-10 04:00:00+00	210	1
5115		2017-04-11 04:00:00+00	210	1
5116		2017-04-16 04:00:00+00	210	1
5117		2017-04-17 04:00:00+00	210	1
5118		2017-04-20 04:00:00+00	210	1
5119		2017-04-23 04:00:00+00	210	1
5120		2017-04-24 04:00:00+00	210	1
5121	<40	2017-04-25 04:00:00+00	210	1
5122		2017-04-30 04:00:00+00	210	1
5123		2017-05-01 04:00:00+00	210	1
5124		2017-05-07 04:00:00+00	210	1
5125		2017-05-08 04:00:00+00	210	1
5126		2017-05-09 04:00:00+00	210	1
5127		2017-05-10 04:00:00+00	210	1
5128		2017-05-14 04:00:00+00	210	1
5129		2017-05-15 04:00:00+00	210	1
5130		2017-05-21 04:00:00+00	210	1
5131	<40	2017-05-22 04:00:00+00	210	1
5132		2017-05-28 04:00:00+00	210	1
5133		2017-05-29 04:00:00+00	210	1
5134	<39	2017-05-30 04:00:00+00	210	1
5135		2017-06-02 04:00:00+00	210	1
5136		2017-06-04 04:00:00+00	210	1
5137		2017-06-05 04:00:00+00	210	1
5138		2017-06-09 04:00:00+00	210	1
5139		2017-06-10 04:00:00+00	210	1
5140		2017-06-11 04:00:00+00	210	1
5141	<39	2017-06-12 04:00:00+00	210	1
5142		2017-06-18 04:00:00+00	210	1
5143		2017-06-19 04:00:00+00	210	1
5144		2017-06-22 04:00:00+00	210	1
5145		2017-06-23 04:00:00+00	210	1
5146		2017-06-25 04:00:00+00	210	1
5147		2017-06-26 04:00:00+00	210	1
5148		2017-07-02 04:00:00+00	210	1
5149		2017-07-05 04:00:00+00	210	1
5150		2017-07-09 04:00:00+00	210	1
5151		2017-07-10 04:00:00+00	210	1
5152		2017-07-14 04:00:00+00	210	1
5153		2017-07-16 04:00:00+00	210	1
5154		2017-07-17 04:00:00+00	210	1
5155		2017-07-23 04:00:00+00	210	1
5156		2017-07-24 04:00:00+00	210	1
5157		2017-07-30 04:00:00+00	210	1
5158	<40	2017-07-31 04:00:00+00	210	1
5159		2017-08-06 04:00:00+00	210	1
5160	<39	2017-08-07 04:00:00+00	210	1
5161		2017-08-08 04:00:00+00	210	1
5162		2017-08-13 04:00:00+00	210	1
5163		2017-08-14 04:00:00+00	210	1
5164		2017-08-17 04:00:00+00	210	1
5165		2017-08-20 04:00:00+00	210	1
5166		2017-08-21 04:00:00+00	210	1
5167		2017-08-22 04:00:00+00	210	1
5168		2017-08-23 04:00:00+00	210	1
5169		2017-09-03 04:00:00+00	210	1
5170		2017-09-04 04:00:00+00	210	1
5171		2017-09-05 04:00:00+00	210	1
5172		2017-09-10 04:00:00+00	210	1
5173		2017-09-11 04:00:00+00	210	1
5174		2017-09-17 04:00:00+00	210	1
5175	<39	2017-09-18 04:00:00+00	210	1
5176		2017-10-02 04:00:00+00	210	1
5177		2017-10-10 04:00:00+00	210	1
5178		2017-10-15 04:00:00+00	210	1
5179		2017-10-16 04:00:00+00	210	1
2887		2017-03-12 05:00:00+00	194	1
2888		2017-03-19 04:00:00+00	194	1
2889	0	2017-03-26 04:00:00+00	194	1
2890		2017-03-27 04:00:00+00	194	1
2891		2017-04-02 04:00:00+00	194	1
2892		2017-04-03 04:00:00+00	194	1
2893	0.4	2017-04-09 04:00:00+00	194	1
2894		2017-04-10 04:00:00+00	194	1
2895		2017-04-11 04:00:00+00	194	1
2896		2017-04-16 04:00:00+00	194	1
2897		2017-04-17 04:00:00+00	194	1
2898		2017-04-20 04:00:00+00	194	1
2899	5.8	2017-04-23 04:00:00+00	194	1
2900		2017-04-24 04:00:00+00	194	1
2901		2017-04-25 04:00:00+00	194	1
2902	14.4	2017-04-30 04:00:00+00	194	1
2903		2017-05-01 04:00:00+00	194	1
2904	9.3	2017-05-07 04:00:00+00	194	1
2905		2017-05-08 04:00:00+00	194	1
2906		2017-05-09 04:00:00+00	194	1
2907		2017-05-10 04:00:00+00	194	1
2908	20.5	2017-05-14 04:00:00+00	194	1
2909		2017-05-15 04:00:00+00	194	1
2910	21.2	2017-05-21 04:00:00+00	194	1
2911		2017-05-22 04:00:00+00	194	1
2912	0	2017-05-28 04:00:00+00	194	1
2913		2017-05-29 04:00:00+00	194	1
2914		2017-05-30 04:00:00+00	194	1
2915		2017-06-02 04:00:00+00	194	1
2916	14.3	2017-06-04 04:00:00+00	194	1
2917		2017-06-05 04:00:00+00	194	1
2918		2017-06-09 04:00:00+00	194	1
2919		2017-06-10 04:00:00+00	194	1
2920	55	2017-06-11 04:00:00+00	194	1
2921		2017-06-12 04:00:00+00	194	1
2922	87.7	2017-06-18 04:00:00+00	194	1
2923		2017-06-19 04:00:00+00	194	1
2924		2017-06-22 04:00:00+00	194	1
2925		2017-06-23 04:00:00+00	194	1
2926	105.6	2017-06-25 04:00:00+00	194	1
2927		2017-06-26 04:00:00+00	194	1
2928	146.8	2017-07-02 04:00:00+00	194	1
2929		2017-07-05 04:00:00+00	194	1
2930	136.7	2017-07-09 04:00:00+00	194	1
2931		2017-07-10 04:00:00+00	194	1
2932		2017-07-14 04:00:00+00	194	1
2933	394.9	2017-07-16 04:00:00+00	194	1
2934		2017-07-17 04:00:00+00	194	1
2935	190	2017-07-23 04:00:00+00	194	1
2936		2017-07-24 04:00:00+00	194	1
2937	61.3	2017-07-30 04:00:00+00	194	1
2938		2017-07-31 04:00:00+00	194	1
2939	26.7	2017-08-06 04:00:00+00	194	1
2940		2017-08-07 04:00:00+00	194	1
2941		2017-08-08 04:00:00+00	194	1
2942	14.5	2017-08-13 04:00:00+00	194	1
2943		2017-08-14 04:00:00+00	194	1
2944		2017-08-17 04:00:00+00	194	1
2945	12.8	2017-08-20 04:00:00+00	194	1
2946		2017-08-21 04:00:00+00	194	1
2947		2017-08-22 04:00:00+00	194	1
2948		2017-08-23 04:00:00+00	194	1
2949		2017-09-03 04:00:00+00	194	1
2950		2017-09-04 04:00:00+00	194	1
2951		2017-09-05 04:00:00+00	194	1
2952		2017-09-10 04:00:00+00	194	1
2953		2017-09-11 04:00:00+00	194	1
2954		2017-09-17 04:00:00+00	194	1
2955		2017-09-18 04:00:00+00	194	1
2956		2017-10-02 04:00:00+00	194	1
2957		2017-10-10 04:00:00+00	194	1
3479		2017-03-12 05:00:00+00	199	1
3480		2017-03-19 04:00:00+00	199	1
2958		2017-10-15 04:00:00+00	194	1
2959		2017-10-16 04:00:00+00	194	1
2960		2018-03-12 04:00:00+00	194	1
3331		2017-03-12 05:00:00+00	198	1
3332		2017-03-19 04:00:00+00	198	1
3333		2017-03-26 04:00:00+00	198	1
3334		2017-03-27 04:00:00+00	198	1
3335		2017-04-02 04:00:00+00	198	1
3336	<39	2017-04-03 04:00:00+00	198	1
3337		2017-04-09 04:00:00+00	198	1
3338	<40	2017-04-10 04:00:00+00	198	1
3339		2017-04-11 04:00:00+00	198	1
3340		2017-04-16 04:00:00+00	198	1
3341	<38	2017-04-17 04:00:00+00	198	1
3342		2017-04-20 04:00:00+00	198	1
3343		2017-04-23 04:00:00+00	198	1
3344		2017-04-24 04:00:00+00	198	1
3345	<39	2017-04-25 04:00:00+00	198	1
3346		2017-04-30 04:00:00+00	198	1
3347	<40	2017-05-01 04:00:00+00	198	1
3348		2017-05-07 04:00:00+00	198	1
3349	<38	2017-05-08 04:00:00+00	198	1
3350		2017-05-09 04:00:00+00	198	1
3351		2017-05-10 04:00:00+00	198	1
3352		2017-05-14 04:00:00+00	198	1
3353	<39	2017-05-15 04:00:00+00	198	1
3354		2017-05-21 04:00:00+00	198	1
3355	<41	2017-05-22 04:00:00+00	198	1
3356		2017-05-28 04:00:00+00	198	1
3357		2017-05-29 04:00:00+00	198	1
3358	<41	2017-05-30 04:00:00+00	198	1
3359		2017-06-02 04:00:00+00	198	1
3360		2017-06-04 04:00:00+00	198	1
3361	<39	2017-06-05 04:00:00+00	198	1
3362		2017-06-09 04:00:00+00	198	1
3363		2017-06-10 04:00:00+00	198	1
3364		2017-06-11 04:00:00+00	198	1
3365	<40	2017-06-12 04:00:00+00	198	1
3366		2017-06-18 04:00:00+00	198	1
3367	<41	2017-06-19 04:00:00+00	198	1
3368		2017-06-22 04:00:00+00	198	1
3369		2017-06-23 04:00:00+00	198	1
3370		2017-06-25 04:00:00+00	198	1
3371	<39	2017-06-26 04:00:00+00	198	1
3372		2017-07-02 04:00:00+00	198	1
3373		2017-07-05 04:00:00+00	198	1
3374		2017-07-09 04:00:00+00	198	1
3375		2017-07-10 04:00:00+00	198	1
3376		2017-07-14 04:00:00+00	198	1
3377		2017-07-16 04:00:00+00	198	1
3378	<39	2017-07-17 04:00:00+00	198	1
3379		2017-07-23 04:00:00+00	198	1
3380	<41	2017-07-24 04:00:00+00	198	1
3381		2017-07-30 04:00:00+00	198	1
3382	<40	2017-07-31 04:00:00+00	198	1
3383		2017-08-06 04:00:00+00	198	1
3384	<40	2017-08-07 04:00:00+00	198	1
3385		2017-08-08 04:00:00+00	198	1
3386		2017-08-13 04:00:00+00	198	1
3387	<41	2017-08-14 04:00:00+00	198	1
3388		2017-08-17 04:00:00+00	198	1
3389		2017-08-20 04:00:00+00	198	1
3390		2017-08-21 04:00:00+00	198	1
3391		2017-08-22 04:00:00+00	198	1
3392		2017-08-23 04:00:00+00	198	1
3393		2017-09-03 04:00:00+00	198	1
3394		2017-09-04 04:00:00+00	198	1
3395		2017-09-05 04:00:00+00	198	1
3396		2017-09-10 04:00:00+00	198	1
3397	<40	2017-09-11 04:00:00+00	198	1
3398		2017-09-17 04:00:00+00	198	1
3399		2017-09-18 04:00:00+00	198	1
3400		2017-10-02 04:00:00+00	198	1
3401		2017-10-10 04:00:00+00	198	1
3402		2017-10-15 04:00:00+00	198	1
3403	<40	2017-10-16 04:00:00+00	198	1
3404		2018-03-12 04:00:00+00	198	1
3035		2017-03-12 05:00:00+00	196	1
3036		2017-03-19 04:00:00+00	196	1
3037		2017-03-26 04:00:00+00	196	1
3038		2017-03-27 04:00:00+00	196	1
3039		2017-04-02 04:00:00+00	196	1
3040		2017-04-03 04:00:00+00	196	1
3041		2017-04-09 04:00:00+00	196	1
3042	<41	2017-04-10 04:00:00+00	196	1
3043		2017-04-11 04:00:00+00	196	1
3044		2017-04-16 04:00:00+00	196	1
3045	<39	2017-04-17 04:00:00+00	196	1
3046		2017-04-20 04:00:00+00	196	1
3047		2017-04-23 04:00:00+00	196	1
3048		2017-04-24 04:00:00+00	196	1
3049	<39	2017-04-25 04:00:00+00	196	1
3050		2017-04-30 04:00:00+00	196	1
3051	<39	2017-05-01 04:00:00+00	196	1
3052		2017-05-07 04:00:00+00	196	1
3053	<38	2017-05-08 04:00:00+00	196	1
3054		2017-05-09 04:00:00+00	196	1
3055		2017-05-10 04:00:00+00	196	1
3056		2017-05-14 04:00:00+00	196	1
3057	<40	2017-05-15 04:00:00+00	196	1
3058		2017-05-21 04:00:00+00	196	1
3059	<41	2017-05-22 04:00:00+00	196	1
3060		2017-05-28 04:00:00+00	196	1
3061		2017-05-29 04:00:00+00	196	1
3062	<39	2017-05-30 04:00:00+00	196	1
3063		2017-06-02 04:00:00+00	196	1
3064		2017-06-04 04:00:00+00	196	1
3065	<39	2017-06-05 04:00:00+00	196	1
3066		2017-06-09 04:00:00+00	196	1
3067		2017-06-10 04:00:00+00	196	1
3068		2017-06-11 04:00:00+00	196	1
3069	<40	2017-06-12 04:00:00+00	196	1
3070		2017-06-18 04:00:00+00	196	1
3071	<41	2017-06-19 04:00:00+00	196	1
3072		2017-06-22 04:00:00+00	196	1
3073		2017-06-23 04:00:00+00	196	1
3074		2017-06-25 04:00:00+00	196	1
3075	<39	2017-06-26 04:00:00+00	196	1
3076		2017-07-02 04:00:00+00	196	1
3077		2017-07-05 04:00:00+00	196	1
3078		2017-07-09 04:00:00+00	196	1
3079		2017-07-10 04:00:00+00	196	1
3080		2017-07-14 04:00:00+00	196	1
3081		2017-07-16 04:00:00+00	196	1
3082	<40	2017-07-17 04:00:00+00	196	1
3083		2017-07-23 04:00:00+00	196	1
3084	<40	2017-07-24 04:00:00+00	196	1
3085		2017-07-30 04:00:00+00	196	1
3086	<40	2017-07-31 04:00:00+00	196	1
3087		2017-08-06 04:00:00+00	196	1
3088	<41	2017-08-07 04:00:00+00	196	1
3089		2017-08-08 04:00:00+00	196	1
3090		2017-08-13 04:00:00+00	196	1
3091	<40	2017-08-14 04:00:00+00	196	1
3092		2017-08-17 04:00:00+00	196	1
3093		2017-08-20 04:00:00+00	196	1
3094		2017-08-21 04:00:00+00	196	1
3095		2017-08-22 04:00:00+00	196	1
3096		2017-08-23 04:00:00+00	196	1
3097		2017-09-03 04:00:00+00	196	1
3098		2017-09-04 04:00:00+00	196	1
3099	<41	2017-09-05 04:00:00+00	196	1
3100		2017-09-10 04:00:00+00	196	1
3101	<39	2017-09-11 04:00:00+00	196	1
3102		2017-09-17 04:00:00+00	196	1
3103	<39	2017-09-18 04:00:00+00	196	1
3104		2017-10-02 04:00:00+00	196	1
3105		2017-10-10 04:00:00+00	196	1
3106		2017-10-15 04:00:00+00	196	1
3107	<40	2017-10-16 04:00:00+00	196	1
3108		2018-03-12 04:00:00+00	196	1
3481		2017-03-26 04:00:00+00	199	1
3482		2017-03-27 04:00:00+00	199	1
3483		2017-04-02 04:00:00+00	199	1
3484		2017-04-03 04:00:00+00	199	1
3485		2017-04-09 04:00:00+00	199	1
3486		2017-04-10 04:00:00+00	199	1
3490		2017-04-20 04:00:00+00	199	1
3491		2017-04-23 04:00:00+00	199	1
3492		2017-04-24 04:00:00+00	199	1
3493	<39	2017-04-25 04:00:00+00	199	1
3494		2017-04-30 04:00:00+00	199	1
3495	<40	2017-05-01 04:00:00+00	199	1
3496		2017-05-07 04:00:00+00	199	1
3497	<38	2017-05-08 04:00:00+00	199	1
3498		2017-05-09 04:00:00+00	199	1
3499		2017-05-10 04:00:00+00	199	1
3500		2017-05-14 04:00:00+00	199	1
3501	<40	2017-05-15 04:00:00+00	199	1
3502		2017-05-21 04:00:00+00	199	1
3503	<41	2017-05-22 04:00:00+00	199	1
3504		2017-05-28 04:00:00+00	199	1
3505		2017-05-29 04:00:00+00	199	1
3506	<41	2017-05-30 04:00:00+00	199	1
3507		2017-06-02 04:00:00+00	199	1
3508		2017-06-04 04:00:00+00	199	1
3509	<39	2017-06-05 04:00:00+00	199	1
3510		2017-06-09 04:00:00+00	199	1
3511		2017-06-10 04:00:00+00	199	1
3512		2017-06-11 04:00:00+00	199	1
3513	<40	2017-06-12 04:00:00+00	199	1
3514	<42	2017-06-18 04:00:00+00	199	1
3515		2017-06-19 04:00:00+00	199	1
3516		2017-06-22 04:00:00+00	199	1
3517		2017-06-23 04:00:00+00	199	1
3518		2017-06-25 04:00:00+00	199	1
3519	<39	2017-06-26 04:00:00+00	199	1
3520		2017-07-02 04:00:00+00	199	1
3521		2017-07-05 04:00:00+00	199	1
3522		2017-07-09 04:00:00+00	199	1
3523		2017-07-10 04:00:00+00	199	1
3524		2017-07-14 04:00:00+00	199	1
3525		2017-07-16 04:00:00+00	199	1
3526	<40	2017-07-17 04:00:00+00	199	1
3527		2017-07-23 04:00:00+00	199	1
3528	<41	2017-07-24 04:00:00+00	199	1
3529		2017-07-30 04:00:00+00	199	1
3530	<41	2017-07-31 04:00:00+00	199	1
3531		2017-08-06 04:00:00+00	199	1
3532	<38	2017-08-07 04:00:00+00	199	1
3533		2017-08-08 04:00:00+00	199	1
3534		2017-08-13 04:00:00+00	199	1
3535	<41	2017-08-14 04:00:00+00	199	1
3536		2017-08-17 04:00:00+00	199	1
3537		2017-08-20 04:00:00+00	199	1
3538		2017-08-21 04:00:00+00	199	1
3539		2017-08-22 04:00:00+00	199	1
3540		2017-08-23 04:00:00+00	199	1
3541		2017-09-03 04:00:00+00	199	1
3542		2017-09-04 04:00:00+00	199	1
3543		2017-09-05 04:00:00+00	199	1
3544		2017-09-10 04:00:00+00	199	1
3545	<40	2017-09-11 04:00:00+00	199	1
3546		2017-09-17 04:00:00+00	199	1
3547	<40	2017-09-18 04:00:00+00	199	1
3548		2017-10-02 04:00:00+00	199	1
3549		2017-10-10 04:00:00+00	199	1
3550		2017-10-15 04:00:00+00	199	1
3551	<40	2017-10-16 04:00:00+00	199	1
3552		2018-03-12 04:00:00+00	199	1
5180		2018-03-12 04:00:00+00	210	1
3627		2017-03-12 05:00:00+00	200	1
3628	<39	2017-03-19 04:00:00+00	200	1
3629		2017-03-26 04:00:00+00	200	1
3630	<41	2017-03-27 04:00:00+00	200	1
3631	<41	2017-04-02 04:00:00+00	200	1
3632		2017-04-03 04:00:00+00	200	1
3633	<39	2017-04-09 04:00:00+00	200	1
3634		2017-04-10 04:00:00+00	200	1
3635		2017-04-11 04:00:00+00	200	1
3636		2017-04-16 04:00:00+00	200	1
3637	<38	2017-04-17 04:00:00+00	200	1
3638		2017-04-20 04:00:00+00	200	1
3639		2017-04-23 04:00:00+00	200	1
3640		2017-04-24 04:00:00+00	200	1
3641	<41	2017-04-25 04:00:00+00	200	1
3642	47	2017-04-30 04:00:00+00	200	1
3643		2017-05-01 04:00:00+00	200	1
3644		2017-05-07 04:00:00+00	200	1
3645	117	2017-05-08 04:00:00+00	200	1
3646		2017-05-09 04:00:00+00	200	1
3647		2017-05-10 04:00:00+00	200	1
3648	119	2017-05-14 04:00:00+00	200	1
3649		2017-05-15 04:00:00+00	200	1
3650		2017-05-21 04:00:00+00	200	1
3651	46	2017-05-22 04:00:00+00	200	1
3652		2017-05-28 04:00:00+00	200	1
3653	<39	2017-05-29 04:00:00+00	200	1
3654		2017-05-30 04:00:00+00	200	1
3655		2017-06-02 04:00:00+00	200	1
3656	<39	2017-06-04 04:00:00+00	200	1
3657		2017-06-05 04:00:00+00	200	1
3658		2017-06-09 04:00:00+00	200	1
3659		2017-06-10 04:00:00+00	200	1
3660	<40	2017-06-11 04:00:00+00	200	1
3661		2017-06-12 04:00:00+00	200	1
3662	<40	2017-06-18 04:00:00+00	200	1
3663		2017-06-19 04:00:00+00	200	1
3664		2017-06-22 04:00:00+00	200	1
3665		2017-06-23 04:00:00+00	200	1
3666	<39	2017-06-25 04:00:00+00	200	1
3667		2017-06-26 04:00:00+00	200	1
3668		2017-07-02 04:00:00+00	200	1
3669		2017-07-05 04:00:00+00	200	1
3670		2017-07-09 04:00:00+00	200	1
3671		2017-07-10 04:00:00+00	200	1
3672		2017-07-14 04:00:00+00	200	1
3673	<40	2017-07-16 04:00:00+00	200	1
3674		2017-07-17 04:00:00+00	200	1
3675	<40	2017-07-23 04:00:00+00	200	1
3676		2017-07-24 04:00:00+00	200	1
3677	<39	2017-07-30 04:00:00+00	200	1
3678		2017-07-31 04:00:00+00	200	1
3679		2017-08-06 04:00:00+00	200	1
3680	<38	2017-08-07 04:00:00+00	200	1
3681		2017-08-08 04:00:00+00	200	1
3682	<40	2017-08-13 04:00:00+00	200	1
3683		2017-08-14 04:00:00+00	200	1
3684		2017-08-17 04:00:00+00	200	1
3685		2017-08-20 04:00:00+00	200	1
3686	<40	2017-08-21 04:00:00+00	200	1
3687		2017-08-22 04:00:00+00	200	1
3688		2017-08-23 04:00:00+00	200	1
3689		2017-09-03 04:00:00+00	200	1
3690	<40	2017-09-04 04:00:00+00	200	1
3691		2017-09-05 04:00:00+00	200	1
3692	<39	2017-09-10 04:00:00+00	200	1
3693		2017-09-11 04:00:00+00	200	1
3694	<39	2017-09-17 04:00:00+00	200	1
3695		2017-09-18 04:00:00+00	200	1
3696		2017-10-02 04:00:00+00	200	1
3697		2017-10-10 04:00:00+00	200	1
3698	<41	2017-10-15 04:00:00+00	200	1
3699		2017-10-16 04:00:00+00	200	1
3700		2018-03-12 04:00:00+00	200	1
4219		2017-03-12 05:00:00+00	204	1
4220		2017-03-19 04:00:00+00	204	1
4221		2017-03-26 04:00:00+00	204	1
4222		2017-03-27 04:00:00+00	204	1
4223		2017-04-02 04:00:00+00	204	1
4224		2017-04-03 04:00:00+00	204	1
4225		2017-04-09 04:00:00+00	204	1
4226	<40	2017-04-10 04:00:00+00	204	1
4227		2017-04-11 04:00:00+00	204	1
4228		2017-04-16 04:00:00+00	204	1
4229		2017-04-17 04:00:00+00	204	1
4230	<38	2017-04-20 04:00:00+00	204	1
4231		2017-04-23 04:00:00+00	204	1
4232		2017-04-24 04:00:00+00	204	1
4233	<39	2017-04-25 04:00:00+00	204	1
4234		2017-04-30 04:00:00+00	204	1
4235	<39	2017-05-01 04:00:00+00	204	1
4236		2017-05-07 04:00:00+00	204	1
4237	<38	2017-05-08 04:00:00+00	204	1
4238		2017-05-09 04:00:00+00	204	1
4239		2017-05-10 04:00:00+00	204	1
4240		2017-05-14 04:00:00+00	204	1
4241	<39	2017-05-15 04:00:00+00	204	1
4242		2017-05-21 04:00:00+00	204	1
4243	<40	2017-05-22 04:00:00+00	204	1
4244		2017-05-28 04:00:00+00	204	1
4245		2017-05-29 04:00:00+00	204	1
4246	<39	2017-05-30 04:00:00+00	204	1
4247		2017-06-02 04:00:00+00	204	1
4248		2017-06-04 04:00:00+00	204	1
4249	<38	2017-06-05 04:00:00+00	204	1
4250		2017-06-09 04:00:00+00	204	1
4251		2017-06-10 04:00:00+00	204	1
4252		2017-06-11 04:00:00+00	204	1
4253	<40	2017-06-12 04:00:00+00	204	1
4254	<40	2017-06-18 04:00:00+00	204	1
4255		2017-06-19 04:00:00+00	204	1
4256		2017-06-22 04:00:00+00	204	1
4257		2017-06-23 04:00:00+00	204	1
4258		2017-06-25 04:00:00+00	204	1
4259	<40	2017-06-26 04:00:00+00	204	1
4260		2017-07-02 04:00:00+00	204	1
4261		2017-07-05 04:00:00+00	204	1
4262		2017-07-09 04:00:00+00	204	1
4263		2017-07-10 04:00:00+00	204	1
4264		2017-07-14 04:00:00+00	204	1
4265		2017-07-16 04:00:00+00	204	1
4266	<41	2017-07-17 04:00:00+00	204	1
4267		2017-07-23 04:00:00+00	204	1
4268	<39	2017-07-24 04:00:00+00	204	1
4269		2017-07-30 04:00:00+00	204	1
4270	<40	2017-07-31 04:00:00+00	204	1
4271		2017-08-06 04:00:00+00	204	1
4272	<39	2017-08-07 04:00:00+00	204	1
4273		2017-08-08 04:00:00+00	204	1
4274		2017-08-13 04:00:00+00	204	1
4275	<41	2017-08-14 04:00:00+00	204	1
4276		2017-08-17 04:00:00+00	204	1
4277		2017-08-20 04:00:00+00	204	1
4278	<41	2017-08-21 04:00:00+00	204	1
4279		2017-08-22 04:00:00+00	204	1
4280		2017-08-23 04:00:00+00	204	1
4281		2017-09-03 04:00:00+00	204	1
4282		2017-09-04 04:00:00+00	204	1
4283	<40	2017-09-05 04:00:00+00	204	1
4284		2017-09-10 04:00:00+00	204	1
4285	<40	2017-09-11 04:00:00+00	204	1
4286		2017-09-17 04:00:00+00	204	1
4287	<38	2017-09-18 04:00:00+00	204	1
4288		2017-10-02 04:00:00+00	204	1
4289		2017-10-10 04:00:00+00	204	1
4290		2017-10-15 04:00:00+00	204	1
4291	<40	2017-10-16 04:00:00+00	204	1
4292		2018-03-12 04:00:00+00	204	1
3775		2017-03-12 05:00:00+00	201	1
3776	<38	2017-03-19 04:00:00+00	201	1
3777	<40	2017-03-26 04:00:00+00	201	1
3778		2017-03-27 04:00:00+00	201	1
3779	<41	2017-04-02 04:00:00+00	201	1
3780		2017-04-03 04:00:00+00	201	1
3781	<39	2017-04-09 04:00:00+00	201	1
3782		2017-04-10 04:00:00+00	201	1
3783		2017-04-11 04:00:00+00	201	1
3784		2017-04-16 04:00:00+00	201	1
3785		2017-04-17 04:00:00+00	201	1
3786	<37	2017-04-20 04:00:00+00	201	1
3787	43	2017-04-23 04:00:00+00	201	1
3788		2017-04-24 04:00:00+00	201	1
3789		2017-04-25 04:00:00+00	201	1
3790	50	2017-04-30 04:00:00+00	201	1
3791		2017-05-01 04:00:00+00	201	1
3792	72	2017-05-07 04:00:00+00	201	1
3793		2017-05-08 04:00:00+00	201	1
3794		2017-05-09 04:00:00+00	201	1
3795		2017-05-10 04:00:00+00	201	1
3796	62	2017-05-14 04:00:00+00	201	1
3797		2017-05-15 04:00:00+00	201	1
3798	49	2017-05-21 04:00:00+00	201	1
3799		2017-05-22 04:00:00+00	201	1
3800	41	2017-05-28 04:00:00+00	201	1
3801		2017-05-29 04:00:00+00	201	1
3802		2017-05-30 04:00:00+00	201	1
3803		2017-06-02 04:00:00+00	201	1
3804	<39	2017-06-04 04:00:00+00	201	1
3805		2017-06-05 04:00:00+00	201	1
3806		2017-06-09 04:00:00+00	201	1
3807	<39	2017-06-10 04:00:00+00	201	1
3808		2017-06-11 04:00:00+00	201	1
3809		2017-06-12 04:00:00+00	201	1
3810	<40	2017-06-18 04:00:00+00	201	1
3811		2017-06-19 04:00:00+00	201	1
3812		2017-06-22 04:00:00+00	201	1
3813		2017-06-23 04:00:00+00	201	1
3814	<40	2017-06-25 04:00:00+00	201	1
3815		2017-06-26 04:00:00+00	201	1
3816		2017-07-02 04:00:00+00	201	1
3817		2017-07-05 04:00:00+00	201	1
3818		2017-07-09 04:00:00+00	201	1
3819		2017-07-10 04:00:00+00	201	1
3820		2017-07-14 04:00:00+00	201	1
3821	<39	2017-07-16 04:00:00+00	201	1
3822		2017-07-17 04:00:00+00	201	1
3823	<40	2017-07-23 04:00:00+00	201	1
3824		2017-07-24 04:00:00+00	201	1
3825	<30	2017-07-30 04:00:00+00	201	1
3826		2017-07-31 04:00:00+00	201	1
3827	<38	2017-08-06 04:00:00+00	201	1
3828		2017-08-07 04:00:00+00	201	1
3829		2017-08-08 04:00:00+00	201	1
3830	<40	2017-08-13 04:00:00+00	201	1
3831		2017-08-14 04:00:00+00	201	1
3832		2017-08-17 04:00:00+00	201	1
3833	<40	2017-08-20 04:00:00+00	201	1
3834		2017-08-21 04:00:00+00	201	1
3835		2017-08-22 04:00:00+00	201	1
3836		2017-08-23 04:00:00+00	201	1
3837	<41	2017-09-03 04:00:00+00	201	1
3838		2017-09-04 04:00:00+00	201	1
3839		2017-09-05 04:00:00+00	201	1
3840	<38	2017-09-10 04:00:00+00	201	1
3841		2017-09-11 04:00:00+00	201	1
3842	<40	2017-09-17 04:00:00+00	201	1
3843		2017-09-18 04:00:00+00	201	1
3844		2017-10-02 04:00:00+00	201	1
3845		2017-10-10 04:00:00+00	201	1
3846	<41	2017-10-15 04:00:00+00	201	1
3847		2017-10-16 04:00:00+00	201	1
3848		2018-03-12 04:00:00+00	201	1
3923		2017-03-12 05:00:00+00	202	1
3924	51	2017-03-19 04:00:00+00	202	1
3925	55	2017-03-26 04:00:00+00	202	1
3926		2017-03-27 04:00:00+00	202	1
3927	47	2017-04-02 04:00:00+00	202	1
3928		2017-04-03 04:00:00+00	202	1
3929	44	2017-04-09 04:00:00+00	202	1
3930		2017-04-10 04:00:00+00	202	1
3931		2017-04-11 04:00:00+00	202	1
3932		2017-04-16 04:00:00+00	202	1
3933		2017-04-17 04:00:00+00	202	1
3934	44	2017-04-20 04:00:00+00	202	1
3935	58	2017-04-23 04:00:00+00	202	1
3936		2017-04-24 04:00:00+00	202	1
3937		2017-04-25 04:00:00+00	202	1
3938	73	2017-04-30 04:00:00+00	202	1
3939		2017-05-01 04:00:00+00	202	1
3940	60	2017-05-07 04:00:00+00	202	1
3941		2017-05-08 04:00:00+00	202	1
3942		2017-05-09 04:00:00+00	202	1
3943		2017-05-10 04:00:00+00	202	1
3944	150	2017-05-14 04:00:00+00	202	1
3945		2017-05-15 04:00:00+00	202	1
3946	290	2017-05-21 04:00:00+00	202	1
3947		2017-05-22 04:00:00+00	202	1
3948	74	2017-05-28 04:00:00+00	202	1
3949		2017-05-29 04:00:00+00	202	1
3950		2017-05-30 04:00:00+00	202	1
3951		2017-06-02 04:00:00+00	202	1
3952	59	2017-06-04 04:00:00+00	202	1
3953		2017-06-05 04:00:00+00	202	1
3954		2017-06-09 04:00:00+00	202	1
3955	44	2017-06-10 04:00:00+00	202	1
3956		2017-06-11 04:00:00+00	202	1
3957		2017-06-12 04:00:00+00	202	1
3958	42	2017-06-18 04:00:00+00	202	1
3959		2017-06-19 04:00:00+00	202	1
3960		2017-06-22 04:00:00+00	202	1
3961		2017-06-23 04:00:00+00	202	1
3962	<39	2017-06-25 04:00:00+00	202	1
3963		2017-06-26 04:00:00+00	202	1
3964		2017-07-02 04:00:00+00	202	1
3965		2017-07-05 04:00:00+00	202	1
3966		2017-07-09 04:00:00+00	202	1
3967		2017-07-10 04:00:00+00	202	1
3968		2017-07-14 04:00:00+00	202	1
3969	<40	2017-07-16 04:00:00+00	202	1
3970		2017-07-17 04:00:00+00	202	1
3971		2017-07-23 04:00:00+00	202	1
3972		2017-07-24 04:00:00+00	202	1
3973		2017-07-30 04:00:00+00	202	1
3974		2017-07-31 04:00:00+00	202	1
3975		2017-08-06 04:00:00+00	202	1
3976		2017-08-07 04:00:00+00	202	1
3977		2017-08-08 04:00:00+00	202	1
3978		2017-08-13 04:00:00+00	202	1
3979		2017-08-14 04:00:00+00	202	1
3980		2017-08-17 04:00:00+00	202	1
3981	<40	2017-08-20 04:00:00+00	202	1
3982		2017-08-21 04:00:00+00	202	1
3983		2017-08-22 04:00:00+00	202	1
3984		2017-08-23 04:00:00+00	202	1
3985	<41	2017-09-03 04:00:00+00	202	1
3986		2017-09-04 04:00:00+00	202	1
3987		2017-09-05 04:00:00+00	202	1
3988		2017-09-10 04:00:00+00	202	1
3989	<40	2017-09-11 04:00:00+00	202	1
3990	<39	2017-09-17 04:00:00+00	202	1
3991		2017-09-18 04:00:00+00	202	1
3992		2017-10-02 04:00:00+00	202	1
3993		2017-10-10 04:00:00+00	202	1
3994	<41	2017-10-15 04:00:00+00	202	1
3995		2017-10-16 04:00:00+00	202	1
3996		2018-03-12 04:00:00+00	202	1
4367		2017-03-12 05:00:00+00	205	1
4368		2017-03-19 04:00:00+00	205	1
4369		2017-03-26 04:00:00+00	205	1
4370		2017-03-27 04:00:00+00	205	1
4371		2017-04-02 04:00:00+00	205	1
4372	<40	2017-04-03 04:00:00+00	205	1
4373		2017-04-09 04:00:00+00	205	1
4374	<39	2017-04-10 04:00:00+00	205	1
4375		2017-04-11 04:00:00+00	205	1
4376		2017-04-16 04:00:00+00	205	1
4377		2017-04-17 04:00:00+00	205	1
4378		2017-04-20 04:00:00+00	205	1
4379		2017-04-23 04:00:00+00	205	1
4380		2017-04-24 04:00:00+00	205	1
4381	<39	2017-04-25 04:00:00+00	205	1
4382		2017-04-30 04:00:00+00	205	1
4383	<39	2017-05-01 04:00:00+00	205	1
4384		2017-05-07 04:00:00+00	205	1
4385		2017-05-08 04:00:00+00	205	1
4386		2017-05-09 04:00:00+00	205	1
4387	<38	2017-05-10 04:00:00+00	205	1
4388		2017-05-14 04:00:00+00	205	1
4389		2017-05-15 04:00:00+00	205	1
4390		2017-05-21 04:00:00+00	205	1
4391	<40	2017-05-22 04:00:00+00	205	1
4392		2017-05-28 04:00:00+00	205	1
4393		2017-05-29 04:00:00+00	205	1
4394	<40	2017-05-30 04:00:00+00	205	1
4395		2017-06-02 04:00:00+00	205	1
4396		2017-06-04 04:00:00+00	205	1
4397		2017-06-05 04:00:00+00	205	1
4398		2017-06-09 04:00:00+00	205	1
4399		2017-06-10 04:00:00+00	205	1
4400		2017-06-11 04:00:00+00	205	1
4401	<41	2017-06-12 04:00:00+00	205	1
4402		2017-06-18 04:00:00+00	205	1
4403	49	2017-06-19 04:00:00+00	205	1
4404	<41	2017-06-22 04:00:00+00	205	1
4405		2017-06-23 04:00:00+00	205	1
4406		2017-06-25 04:00:00+00	205	1
4407	44	2017-06-26 04:00:00+00	205	1
4408		2017-07-02 04:00:00+00	205	1
4409		2017-07-05 04:00:00+00	205	1
4410		2017-07-09 04:00:00+00	205	1
4411		2017-07-10 04:00:00+00	205	1
4412		2017-07-14 04:00:00+00	205	1
4413		2017-07-16 04:00:00+00	205	1
4414	<40	2017-07-17 04:00:00+00	205	1
4415		2017-07-23 04:00:00+00	205	1
4416	<39	2017-07-24 04:00:00+00	205	1
4417		2017-07-30 04:00:00+00	205	1
4418	<40	2017-07-31 04:00:00+00	205	1
4419		2017-08-06 04:00:00+00	205	1
4420		2017-08-07 04:00:00+00	205	1
4421	<38	2017-08-08 04:00:00+00	205	1
4422		2017-08-13 04:00:00+00	205	1
4423	<40	2017-08-14 04:00:00+00	205	1
4424		2017-08-17 04:00:00+00	205	1
4425		2017-08-20 04:00:00+00	205	1
4426		2017-08-21 04:00:00+00	205	1
4427		2017-08-22 04:00:00+00	205	1
4428	<41	2017-08-23 04:00:00+00	205	1
4429		2017-09-03 04:00:00+00	205	1
4430		2017-09-04 04:00:00+00	205	1
4431	<38	2017-09-05 04:00:00+00	205	1
4432		2017-09-10 04:00:00+00	205	1
4433	<40	2017-09-11 04:00:00+00	205	1
4434		2017-09-17 04:00:00+00	205	1
4435	<37	2017-09-18 04:00:00+00	205	1
4436		2017-10-02 04:00:00+00	205	1
4437		2017-10-10 04:00:00+00	205	1
4438		2017-10-15 04:00:00+00	205	1
4439	<41	2017-10-16 04:00:00+00	205	1
4440		2018-03-12 04:00:00+00	205	1
4515		2017-03-12 05:00:00+00	206	1
4516		2017-03-19 04:00:00+00	206	1
4517		2017-03-26 04:00:00+00	206	1
4518		2017-03-27 04:00:00+00	206	1
4519		2017-04-02 04:00:00+00	206	1
4520	<41	2017-04-03 04:00:00+00	206	1
4521		2017-04-09 04:00:00+00	206	1
4522		2017-04-10 04:00:00+00	206	1
4523	<39	2017-04-11 04:00:00+00	206	1
4524		2017-04-16 04:00:00+00	206	1
4525		2017-04-17 04:00:00+00	206	1
4526	<38	2017-04-20 04:00:00+00	206	1
4527		2017-04-23 04:00:00+00	206	1
4528	<38	2017-04-24 04:00:00+00	206	1
4529		2017-04-25 04:00:00+00	206	1
4530		2017-04-30 04:00:00+00	206	1
4531	<38	2017-05-01 04:00:00+00	206	1
4532		2017-05-07 04:00:00+00	206	1
4533		2017-05-08 04:00:00+00	206	1
4534	<38	2017-05-09 04:00:00+00	206	1
4535		2017-05-10 04:00:00+00	206	1
4536		2017-05-14 04:00:00+00	206	1
4537	<39	2017-05-15 04:00:00+00	206	1
4538		2017-05-21 04:00:00+00	206	1
4539	<41	2017-05-22 04:00:00+00	206	1
4540		2017-05-28 04:00:00+00	206	1
4541		2017-05-29 04:00:00+00	206	1
4542	<39	2017-05-30 04:00:00+00	206	1
4543	43	2017-06-02 04:00:00+00	206	1
4544		2017-06-04 04:00:00+00	206	1
4545	<40	2017-06-05 04:00:00+00	206	1
4546	<41	2017-06-09 04:00:00+00	206	1
4547		2017-06-10 04:00:00+00	206	1
4548		2017-06-11 04:00:00+00	206	1
4549	<40	2017-06-12 04:00:00+00	206	1
4550		2017-06-18 04:00:00+00	206	1
4551	49	2017-06-19 04:00:00+00	206	1
4552		2017-06-22 04:00:00+00	206	1
4553	48	2017-06-23 04:00:00+00	206	1
4554		2017-06-25 04:00:00+00	206	1
4555	44	2017-06-26 04:00:00+00	206	1
4556		2017-07-02 04:00:00+00	206	1
4557	51	2017-07-05 04:00:00+00	206	1
4558		2017-07-09 04:00:00+00	206	1
4559		2017-07-10 04:00:00+00	206	1
4560		2017-07-14 04:00:00+00	206	1
4561		2017-07-16 04:00:00+00	206	1
4562	40	2017-07-17 04:00:00+00	206	1
4563		2017-07-23 04:00:00+00	206	1
4564	<40	2017-07-24 04:00:00+00	206	1
4565		2017-07-30 04:00:00+00	206	1
4566	<41	2017-07-31 04:00:00+00	206	1
4567		2017-08-06 04:00:00+00	206	1
4568		2017-08-07 04:00:00+00	206	1
4569	<38	2017-08-08 04:00:00+00	206	1
4570		2017-08-13 04:00:00+00	206	1
4571	<40	2017-08-14 04:00:00+00	206	1
4572		2017-08-17 04:00:00+00	206	1
4573		2017-08-20 04:00:00+00	206	1
4574		2017-08-21 04:00:00+00	206	1
4575	<41	2017-08-22 04:00:00+00	206	1
4576		2017-08-23 04:00:00+00	206	1
4577		2017-09-03 04:00:00+00	206	1
4578		2017-09-04 04:00:00+00	206	1
4579	<38	2017-09-05 04:00:00+00	206	1
4580		2017-09-10 04:00:00+00	206	1
4581	<39	2017-09-11 04:00:00+00	206	1
4582		2017-09-17 04:00:00+00	206	1
4583	<37	2017-09-18 04:00:00+00	206	1
4584	<39	2017-10-02 04:00:00+00	206	1
4585	<40	2017-10-10 04:00:00+00	206	1
4586		2017-10-15 04:00:00+00	206	1
4587	<39	2017-10-16 04:00:00+00	206	1
4588		2018-03-12 04:00:00+00	206	1
5255		2017-03-12 05:00:00+00	211	2
5256		2017-03-19 04:00:00+00	211	2
5257		2017-03-26 04:00:00+00	211	2
5258		2017-03-27 04:00:00+00	211	2
5259		2017-04-02 04:00:00+00	211	2
5260		2017-04-03 04:00:00+00	211	2
5261		2017-04-09 04:00:00+00	211	2
5262		2017-04-10 04:00:00+00	211	2
5263		2017-04-11 04:00:00+00	211	2
5264		2017-04-16 04:00:00+00	211	2
5265		2017-04-17 04:00:00+00	211	2
5266		2017-04-20 04:00:00+00	211	2
5267		2017-04-23 04:00:00+00	211	2
5268		2017-04-24 04:00:00+00	211	2
5269		2017-04-25 04:00:00+00	211	2
5270	41	2017-04-30 04:00:00+00	211	2
5271		2017-05-01 04:00:00+00	211	2
5272	41	2017-05-07 04:00:00+00	211	2
5273		2017-05-08 04:00:00+00	211	2
5274		2017-05-09 04:00:00+00	211	2
5275		2017-05-10 04:00:00+00	211	2
5276		2017-05-14 04:00:00+00	211	2
5277		2017-05-15 04:00:00+00	211	2
5278		2017-05-21 04:00:00+00	211	2
5279		2017-05-22 04:00:00+00	211	2
5280		2017-05-28 04:00:00+00	211	2
5281		2017-05-29 04:00:00+00	211	2
5282		2017-05-30 04:00:00+00	211	2
5283		2017-06-02 04:00:00+00	211	2
5284		2017-06-04 04:00:00+00	211	2
5285	<39	2017-06-05 04:00:00+00	211	2
5286		2017-06-09 04:00:00+00	211	2
5287		2017-06-10 04:00:00+00	211	2
5288		2017-06-11 04:00:00+00	211	2
5289		2017-06-12 04:00:00+00	211	2
5290		2017-06-18 04:00:00+00	211	2
5291		2017-06-19 04:00:00+00	211	2
5292		2017-06-22 04:00:00+00	211	2
5293	51	2017-06-23 04:00:00+00	211	2
5294		2017-06-25 04:00:00+00	211	2
5295		2017-06-26 04:00:00+00	211	2
5296		2017-07-02 04:00:00+00	211	2
5297		2017-07-05 04:00:00+00	211	2
5298		2017-07-09 04:00:00+00	211	2
5299		2017-07-10 04:00:00+00	211	2
5300		2017-07-14 04:00:00+00	211	2
5301		2017-07-16 04:00:00+00	211	2
5302		2017-07-17 04:00:00+00	211	2
5303		2017-07-23 04:00:00+00	211	2
5304		2017-07-24 04:00:00+00	211	2
5305		2017-07-30 04:00:00+00	211	2
5306		2017-07-31 04:00:00+00	211	2
5307		2017-08-06 04:00:00+00	211	2
5308		2017-08-07 04:00:00+00	211	2
5309		2017-08-08 04:00:00+00	211	2
5310		2017-08-13 04:00:00+00	211	2
5311		2017-08-14 04:00:00+00	211	2
5312		2017-08-17 04:00:00+00	211	2
5313		2017-08-20 04:00:00+00	211	2
5314		2017-08-21 04:00:00+00	211	2
5315		2017-08-22 04:00:00+00	211	2
5316		2017-08-23 04:00:00+00	211	2
5317		2017-09-03 04:00:00+00	211	2
5318		2017-09-04 04:00:00+00	211	2
5319		2017-09-05 04:00:00+00	211	2
5320		2017-09-10 04:00:00+00	211	2
5321		2017-09-11 04:00:00+00	211	2
5322		2017-09-17 04:00:00+00	211	2
5323		2017-09-18 04:00:00+00	211	2
5324		2017-10-02 04:00:00+00	211	2
5325		2017-10-10 04:00:00+00	211	2
5326		2017-10-15 04:00:00+00	211	2
5327		2017-10-16 04:00:00+00	211	2
5328		2018-03-12 04:00:00+00	211	2
4663		2017-03-12 05:00:00+00	207	1
4664		2017-03-19 04:00:00+00	207	1
4665		2017-03-26 04:00:00+00	207	1
4666		2017-03-27 04:00:00+00	207	1
4667		2017-04-02 04:00:00+00	207	1
4668	<39	2017-04-03 04:00:00+00	207	1
4669		2017-04-09 04:00:00+00	207	1
4670	<40	2017-04-10 04:00:00+00	207	1
4671		2017-04-11 04:00:00+00	207	1
4672		2017-04-16 04:00:00+00	207	1
4673		2017-04-17 04:00:00+00	207	1
4674	<38	2017-04-20 04:00:00+00	207	1
4675		2017-04-23 04:00:00+00	207	1
4676	<40	2017-04-24 04:00:00+00	207	1
4677		2017-04-25 04:00:00+00	207	1
4678		2017-04-30 04:00:00+00	207	1
4679	<41	2017-05-01 04:00:00+00	207	1
4680		2017-05-07 04:00:00+00	207	1
4681		2017-05-08 04:00:00+00	207	1
4682	<38	2017-05-09 04:00:00+00	207	1
4683		2017-05-10 04:00:00+00	207	1
4684		2017-05-14 04:00:00+00	207	1
4685	<40	2017-05-15 04:00:00+00	207	1
4686		2017-05-21 04:00:00+00	207	1
4687	<40	2017-05-22 04:00:00+00	207	1
4688		2017-05-28 04:00:00+00	207	1
4689		2017-05-29 04:00:00+00	207	1
4690	<38	2017-05-30 04:00:00+00	207	1
4691	<39	2017-06-02 04:00:00+00	207	1
4692		2017-06-04 04:00:00+00	207	1
4693	44	2017-06-05 04:00:00+00	207	1
4694	51	2017-06-09 04:00:00+00	207	1
4695		2017-06-10 04:00:00+00	207	1
4696		2017-06-11 04:00:00+00	207	1
4697	44	2017-06-12 04:00:00+00	207	1
4698		2017-06-18 04:00:00+00	207	1
4699	47	2017-06-19 04:00:00+00	207	1
4700	81	2017-06-22 04:00:00+00	207	1
4701		2017-06-23 04:00:00+00	207	1
4702	56	2017-06-25 04:00:00+00	207	1
4703	106	2017-06-26 04:00:00+00	207	1
4704		2017-07-02 04:00:00+00	207	1
4705	115	2017-07-05 04:00:00+00	207	1
4706		2017-07-09 04:00:00+00	207	1
4707		2017-07-10 04:00:00+00	207	1
4708		2017-07-14 04:00:00+00	207	1
4709		2017-07-16 04:00:00+00	207	1
4710		2017-07-17 04:00:00+00	207	1
4711		2017-07-23 04:00:00+00	207	1
4712	<40	2017-07-24 04:00:00+00	207	1
4713		2017-07-30 04:00:00+00	207	1
4714	<40	2017-07-31 04:00:00+00	207	1
4715		2017-08-06 04:00:00+00	207	1
4716	<38	2017-08-07 04:00:00+00	207	1
4717		2017-08-08 04:00:00+00	207	1
4718		2017-08-13 04:00:00+00	207	1
4719	<41	2017-08-14 04:00:00+00	207	1
4720		2017-08-17 04:00:00+00	207	1
4721		2017-08-20 04:00:00+00	207	1
4722		2017-08-21 04:00:00+00	207	1
4723	<41	2017-08-22 04:00:00+00	207	1
4724		2017-08-23 04:00:00+00	207	1
4725		2017-09-03 04:00:00+00	207	1
4726		2017-09-04 04:00:00+00	207	1
4727	<39	2017-09-05 04:00:00+00	207	1
4728		2017-09-10 04:00:00+00	207	1
4729	<39	2017-09-11 04:00:00+00	207	1
4730		2017-09-17 04:00:00+00	207	1
4731	<38	2017-09-18 04:00:00+00	207	1
4732	<37	2017-10-02 04:00:00+00	207	1
4733	<40	2017-10-10 04:00:00+00	207	1
4734		2017-10-15 04:00:00+00	207	1
4735	<40	2017-10-16 04:00:00+00	207	1
4736		2018-03-12 04:00:00+00	207	1
4811		2017-03-12 05:00:00+00	208	1
4812		2017-03-19 04:00:00+00	208	1
4813		2017-03-26 04:00:00+00	208	1
4814		2017-03-27 04:00:00+00	208	1
4815		2017-04-02 04:00:00+00	208	1
4816	<40	2017-04-03 04:00:00+00	208	1
4817		2017-04-09 04:00:00+00	208	1
4818	<39	2017-04-10 04:00:00+00	208	1
4819		2017-04-11 04:00:00+00	208	1
4820		2017-04-16 04:00:00+00	208	1
4821		2017-04-17 04:00:00+00	208	1
4822	<38	2017-04-20 04:00:00+00	208	1
4823		2017-04-23 04:00:00+00	208	1
4824	<40	2017-04-24 04:00:00+00	208	1
4825		2017-04-25 04:00:00+00	208	1
4826		2017-04-30 04:00:00+00	208	1
4827	<41	2017-05-01 04:00:00+00	208	1
4828		2017-05-07 04:00:00+00	208	1
4829		2017-05-08 04:00:00+00	208	1
4830	<38	2017-05-09 04:00:00+00	208	1
4831		2017-05-10 04:00:00+00	208	1
4832		2017-05-14 04:00:00+00	208	1
4833	<39	2017-05-15 04:00:00+00	208	1
4834		2017-05-21 04:00:00+00	208	1
4835	<39	2017-05-22 04:00:00+00	208	1
4836		2017-05-28 04:00:00+00	208	1
4837		2017-05-29 04:00:00+00	208	1
4838	<39	2017-05-30 04:00:00+00	208	1
4839	<40	2017-06-02 04:00:00+00	208	1
4840		2017-06-04 04:00:00+00	208	1
4841	<41	2017-06-05 04:00:00+00	208	1
4842	50	2017-06-09 04:00:00+00	208	1
4843		2017-06-10 04:00:00+00	208	1
4844		2017-06-11 04:00:00+00	208	1
4845	<41	2017-06-12 04:00:00+00	208	1
4846		2017-06-18 04:00:00+00	208	1
4847	43	2017-06-19 04:00:00+00	208	1
4848		2017-06-22 04:00:00+00	208	1
4849	54	2017-06-23 04:00:00+00	208	1
4850	60	2017-06-25 04:00:00+00	208	1
4851	54	2017-06-26 04:00:00+00	208	1
4852		2017-07-02 04:00:00+00	208	1
4853	51	2017-07-05 04:00:00+00	208	1
4854		2017-07-09 04:00:00+00	208	1
4855		2017-07-10 04:00:00+00	208	1
4856		2017-07-14 04:00:00+00	208	1
4857		2017-07-16 04:00:00+00	208	1
4858	40	2017-07-17 04:00:00+00	208	1
4859		2017-07-23 04:00:00+00	208	1
4860	<39	2017-07-24 04:00:00+00	208	1
4861		2017-07-30 04:00:00+00	208	1
4862	<39	2017-07-31 04:00:00+00	208	1
4863		2017-08-06 04:00:00+00	208	1
4864	<38	2017-08-07 04:00:00+00	208	1
4865		2017-08-08 04:00:00+00	208	1
4866		2017-08-13 04:00:00+00	208	1
4867	<41	2017-08-14 04:00:00+00	208	1
4868		2017-08-17 04:00:00+00	208	1
4869		2017-08-20 04:00:00+00	208	1
4870		2017-08-21 04:00:00+00	208	1
4871	<40	2017-08-22 04:00:00+00	208	1
4872		2017-08-23 04:00:00+00	208	1
4873		2017-09-03 04:00:00+00	208	1
4874		2017-09-04 04:00:00+00	208	1
4875	<38	2017-09-05 04:00:00+00	208	1
4876		2017-09-10 04:00:00+00	208	1
4877	<39	2017-09-11 04:00:00+00	208	1
4878		2017-09-17 04:00:00+00	208	1
4879	<38	2017-09-18 04:00:00+00	208	1
4880	<42	2017-10-02 04:00:00+00	208	1
4881	<37	2017-10-10 04:00:00+00	208	1
4882		2017-10-15 04:00:00+00	208	1
4883	<41	2017-10-16 04:00:00+00	208	1
4884		2018-03-12 04:00:00+00	208	1
5403		2017-03-12 05:00:00+00	202	2
5404		2017-03-19 04:00:00+00	202	2
5405		2017-03-26 04:00:00+00	202	2
5406		2017-03-27 04:00:00+00	202	2
5407		2017-04-02 04:00:00+00	202	2
5408		2017-04-03 04:00:00+00	202	2
5409		2017-04-09 04:00:00+00	202	2
5410		2017-04-10 04:00:00+00	202	2
5411		2017-04-11 04:00:00+00	202	2
5412		2017-04-16 04:00:00+00	202	2
5413		2017-04-17 04:00:00+00	202	2
5414		2017-04-20 04:00:00+00	202	2
5415		2017-04-23 04:00:00+00	202	2
5416		2017-04-24 04:00:00+00	202	2
5417		2017-04-25 04:00:00+00	202	2
5418		2017-04-30 04:00:00+00	202	2
5419		2017-05-01 04:00:00+00	202	2
5420		2017-05-07 04:00:00+00	202	2
5421		2017-05-08 04:00:00+00	202	2
5422		2017-05-09 04:00:00+00	202	2
5423		2017-05-10 04:00:00+00	202	2
5424	56	2017-05-14 04:00:00+00	202	2
5425		2017-05-15 04:00:00+00	202	2
5426	<39	2017-05-21 04:00:00+00	202	2
5427		2017-05-22 04:00:00+00	202	2
5428	<38	2017-05-28 04:00:00+00	202	2
5429		2017-05-29 04:00:00+00	202	2
5430		2017-05-30 04:00:00+00	202	2
5431		2017-06-02 04:00:00+00	202	2
5432		2017-06-04 04:00:00+00	202	2
5433		2017-06-05 04:00:00+00	202	2
5434		2017-06-09 04:00:00+00	202	2
5435		2017-06-10 04:00:00+00	202	2
5436		2017-06-11 04:00:00+00	202	2
5437		2017-06-12 04:00:00+00	202	2
5438		2017-06-18 04:00:00+00	202	2
5439		2017-06-19 04:00:00+00	202	2
5440		2017-06-22 04:00:00+00	202	2
5441		2017-06-23 04:00:00+00	202	2
5442		2017-06-25 04:00:00+00	202	2
5443		2017-06-26 04:00:00+00	202	2
5444		2017-07-02 04:00:00+00	202	2
5445		2017-07-05 04:00:00+00	202	2
5446		2017-07-09 04:00:00+00	202	2
5447		2017-07-10 04:00:00+00	202	2
5448		2017-07-14 04:00:00+00	202	2
5449		2017-07-16 04:00:00+00	202	2
5450		2017-07-17 04:00:00+00	202	2
5451		2017-07-23 04:00:00+00	202	2
5452		2017-07-24 04:00:00+00	202	2
5453		2017-07-30 04:00:00+00	202	2
5454		2017-07-31 04:00:00+00	202	2
5455		2017-08-06 04:00:00+00	202	2
5456		2017-08-07 04:00:00+00	202	2
5457		2017-08-08 04:00:00+00	202	2
5458		2017-08-13 04:00:00+00	202	2
5459		2017-08-14 04:00:00+00	202	2
5460		2017-08-17 04:00:00+00	202	2
5461		2017-08-20 04:00:00+00	202	2
5462		2017-08-21 04:00:00+00	202	2
5463		2017-08-22 04:00:00+00	202	2
5464		2017-08-23 04:00:00+00	202	2
5465		2017-09-03 04:00:00+00	202	2
5466		2017-09-04 04:00:00+00	202	2
5467		2017-09-05 04:00:00+00	202	2
5468		2017-09-10 04:00:00+00	202	2
5469		2017-09-11 04:00:00+00	202	2
5470		2017-09-17 04:00:00+00	202	2
5471		2017-09-18 04:00:00+00	202	2
5472		2017-10-02 04:00:00+00	202	2
5473		2017-10-10 04:00:00+00	202	2
5474		2017-10-15 04:00:00+00	202	2
5475		2017-10-16 04:00:00+00	202	2
5476		2018-03-12 04:00:00+00	202	2
4959		2017-03-12 05:00:00+00	209	1
4960		2017-03-19 04:00:00+00	209	1
4961		2017-03-26 04:00:00+00	209	1
4962		2017-03-27 04:00:00+00	209	1
4963		2017-04-02 04:00:00+00	209	1
4964		2017-04-03 04:00:00+00	209	1
4965		2017-04-09 04:00:00+00	209	1
4966	<39	2017-04-10 04:00:00+00	209	1
4967		2017-04-11 04:00:00+00	209	1
4968		2017-04-16 04:00:00+00	209	1
4969		2017-04-17 04:00:00+00	209	1
4970	<37	2017-04-20 04:00:00+00	209	1
4971		2017-04-23 04:00:00+00	209	1
4972		2017-04-24 04:00:00+00	209	1
4973	<38	2017-04-25 04:00:00+00	209	1
4974		2017-04-30 04:00:00+00	209	1
4975	<40	2017-05-01 04:00:00+00	209	1
4976		2017-05-07 04:00:00+00	209	1
4977	<38	2017-05-08 04:00:00+00	209	1
4978		2017-05-09 04:00:00+00	209	1
4979		2017-05-10 04:00:00+00	209	1
4980		2017-05-14 04:00:00+00	209	1
4981	<38	2017-05-15 04:00:00+00	209	1
4982		2017-05-21 04:00:00+00	209	1
4983	<39	2017-05-22 04:00:00+00	209	1
4984		2017-05-28 04:00:00+00	209	1
4985		2017-05-29 04:00:00+00	209	1
4986	<40	2017-05-30 04:00:00+00	209	1
4987		2017-06-02 04:00:00+00	209	1
4988		2017-06-04 04:00:00+00	209	1
4989	<39	2017-06-05 04:00:00+00	209	1
4990		2017-06-09 04:00:00+00	209	1
4991		2017-06-10 04:00:00+00	209	1
4992		2017-06-11 04:00:00+00	209	1
4993	<39	2017-06-12 04:00:00+00	209	1
4994		2017-06-18 04:00:00+00	209	1
4995	<40	2017-06-19 04:00:00+00	209	1
4996		2017-06-22 04:00:00+00	209	1
4997		2017-06-23 04:00:00+00	209	1
4998		2017-06-25 04:00:00+00	209	1
4999	<39	2017-06-26 04:00:00+00	209	1
5000		2017-07-02 04:00:00+00	209	1
5001		2017-07-05 04:00:00+00	209	1
5002		2017-07-09 04:00:00+00	209	1
5003		2017-07-10 04:00:00+00	209	1
5004		2017-07-14 04:00:00+00	209	1
5005		2017-07-16 04:00:00+00	209	1
5006	<40	2017-07-17 04:00:00+00	209	1
5007		2017-07-23 04:00:00+00	209	1
5008	<39	2017-07-24 04:00:00+00	209	1
5009		2017-07-30 04:00:00+00	209	1
5010	<41	2017-07-31 04:00:00+00	209	1
5011		2017-08-06 04:00:00+00	209	1
5012	<39	2017-08-07 04:00:00+00	209	1
5013		2017-08-08 04:00:00+00	209	1
5014		2017-08-13 04:00:00+00	209	1
5015	<39	2017-08-14 04:00:00+00	209	1
5016		2017-08-17 04:00:00+00	209	1
5017		2017-08-20 04:00:00+00	209	1
5018	<41	2017-08-21 04:00:00+00	209	1
5019		2017-08-22 04:00:00+00	209	1
5020		2017-08-23 04:00:00+00	209	1
5021		2017-09-03 04:00:00+00	209	1
5022		2017-09-04 04:00:00+00	209	1
5023		2017-09-05 04:00:00+00	209	1
5024		2017-09-10 04:00:00+00	209	1
5025	<41	2017-09-11 04:00:00+00	209	1
5026		2017-09-17 04:00:00+00	209	1
5027	<40	2017-09-18 04:00:00+00	209	1
5028		2017-10-02 04:00:00+00	209	1
5029		2017-10-10 04:00:00+00	209	1
5030		2017-10-15 04:00:00+00	209	1
5031	<41	2017-10-16 04:00:00+00	209	1
5032		2018-03-12 04:00:00+00	209	1
5551		2017-03-12 05:00:00+00	201	2
5552		2017-03-19 04:00:00+00	201	2
5553		2017-03-26 04:00:00+00	201	2
5554		2017-03-27 04:00:00+00	201	2
5555		2017-04-02 04:00:00+00	201	2
5556		2017-04-03 04:00:00+00	201	2
5557		2017-04-09 04:00:00+00	201	2
5558		2017-04-10 04:00:00+00	201	2
5559		2017-04-11 04:00:00+00	201	2
5560		2017-04-16 04:00:00+00	201	2
5561		2017-04-17 04:00:00+00	201	2
5562		2017-04-20 04:00:00+00	201	2
5563		2017-04-23 04:00:00+00	201	2
5564		2017-04-24 04:00:00+00	201	2
5565		2017-04-25 04:00:00+00	201	2
5566		2017-04-30 04:00:00+00	201	2
5567		2017-05-01 04:00:00+00	201	2
5568		2017-05-07 04:00:00+00	201	2
5569		2017-05-08 04:00:00+00	201	2
5570		2017-05-09 04:00:00+00	201	2
5571		2017-05-10 04:00:00+00	201	2
5572		2017-05-14 04:00:00+00	201	2
5573		2017-05-15 04:00:00+00	201	2
5574		2017-05-21 04:00:00+00	201	2
5575		2017-05-22 04:00:00+00	201	2
5576		2017-05-28 04:00:00+00	201	2
5577		2017-05-29 04:00:00+00	201	2
5578		2017-05-30 04:00:00+00	201	2
5579		2017-06-02 04:00:00+00	201	2
5580	<39	2017-06-04 04:00:00+00	201	2
5581		2017-06-05 04:00:00+00	201	2
5582		2017-06-09 04:00:00+00	201	2
5583		2017-06-10 04:00:00+00	201	2
5584		2017-06-11 04:00:00+00	201	2
5585		2017-06-12 04:00:00+00	201	2
5586		2017-06-18 04:00:00+00	201	2
5587		2017-06-19 04:00:00+00	201	2
5588		2017-06-22 04:00:00+00	201	2
5589		2017-06-23 04:00:00+00	201	2
5590		2017-06-25 04:00:00+00	201	2
5591		2017-06-26 04:00:00+00	201	2
5592		2017-07-02 04:00:00+00	201	2
5593		2017-07-05 04:00:00+00	201	2
5594		2017-07-09 04:00:00+00	201	2
5595		2017-07-10 04:00:00+00	201	2
5596		2017-07-14 04:00:00+00	201	2
5597		2017-07-16 04:00:00+00	201	2
5598		2017-07-17 04:00:00+00	201	2
5599		2017-07-23 04:00:00+00	201	2
5600		2017-07-24 04:00:00+00	201	2
5601		2017-07-30 04:00:00+00	201	2
5602		2017-07-31 04:00:00+00	201	2
5603		2017-08-06 04:00:00+00	201	2
5604		2017-08-07 04:00:00+00	201	2
5605		2017-08-08 04:00:00+00	201	2
5606		2017-08-13 04:00:00+00	201	2
5607		2017-08-14 04:00:00+00	201	2
5608		2017-08-17 04:00:00+00	201	2
5609		2017-08-20 04:00:00+00	201	2
5610		2017-08-21 04:00:00+00	201	2
5611		2017-08-22 04:00:00+00	201	2
5612		2017-08-23 04:00:00+00	201	2
5613		2017-09-03 04:00:00+00	201	2
5614		2017-09-04 04:00:00+00	201	2
5615		2017-09-05 04:00:00+00	201	2
5616		2017-09-10 04:00:00+00	201	2
5617		2017-09-11 04:00:00+00	201	2
5618		2017-09-17 04:00:00+00	201	2
5619		2017-09-18 04:00:00+00	201	2
5620		2017-10-02 04:00:00+00	201	2
5621		2017-10-10 04:00:00+00	201	2
5622		2017-10-15 04:00:00+00	201	2
5623		2017-10-16 04:00:00+00	201	2
5624		2018-03-12 04:00:00+00	201	2
5626	<39	2017-05-30 04:00:00+00	214	1
5628	<40	2017-06-26 04:00:00+00	205	3
5703		2017-03-12 05:00:00+00	206	3
5704		2017-03-19 04:00:00+00	206	3
5705		2017-03-26 04:00:00+00	206	3
5706		2017-03-27 04:00:00+00	206	3
5707		2017-04-02 04:00:00+00	206	3
5708		2017-04-03 04:00:00+00	206	3
5709		2017-04-09 04:00:00+00	206	3
5710		2017-04-10 04:00:00+00	206	3
5711		2017-04-11 04:00:00+00	206	3
5712		2017-04-16 04:00:00+00	206	3
5713		2017-04-17 04:00:00+00	206	3
5714		2017-04-20 04:00:00+00	206	3
5715		2017-04-23 04:00:00+00	206	3
5716		2017-04-24 04:00:00+00	206	3
5717		2017-04-25 04:00:00+00	206	3
5718		2017-04-30 04:00:00+00	206	3
5719		2017-05-01 04:00:00+00	206	3
5720		2017-05-07 04:00:00+00	206	3
5721		2017-05-08 04:00:00+00	206	3
5722		2017-05-09 04:00:00+00	206	3
5723		2017-05-10 04:00:00+00	206	3
5724		2017-05-14 04:00:00+00	206	3
5725		2017-05-15 04:00:00+00	206	3
5726		2017-05-21 04:00:00+00	206	3
5727		2017-05-22 04:00:00+00	206	3
5728		2017-05-28 04:00:00+00	206	3
5729		2017-05-29 04:00:00+00	206	3
5730		2017-05-30 04:00:00+00	206	3
5731		2017-06-02 04:00:00+00	206	3
5732		2017-06-04 04:00:00+00	206	3
5733		2017-06-05 04:00:00+00	206	3
5734		2017-06-09 04:00:00+00	206	3
5735		2017-06-10 04:00:00+00	206	3
5736		2017-06-11 04:00:00+00	206	3
5737		2017-06-12 04:00:00+00	206	3
5738		2017-06-18 04:00:00+00	206	3
5739		2017-06-19 04:00:00+00	206	3
5740		2017-06-22 04:00:00+00	206	3
5741		2017-06-23 04:00:00+00	206	3
5742		2017-06-25 04:00:00+00	206	3
5743	<39	2017-06-26 04:00:00+00	206	3
5744	<40	2017-07-02 04:00:00+00	206	3
5745		2017-07-05 04:00:00+00	206	3
5746		2017-07-09 04:00:00+00	206	3
5747	<32	2017-07-10 04:00:00+00	206	3
5748	<41	2017-07-14 04:00:00+00	206	3
5749		2017-07-16 04:00:00+00	206	3
5750		2017-07-17 04:00:00+00	206	3
5751		2017-07-23 04:00:00+00	206	3
5752		2017-07-24 04:00:00+00	206	3
5753		2017-07-30 04:00:00+00	206	3
5754		2017-07-31 04:00:00+00	206	3
5755		2017-08-06 04:00:00+00	206	3
5756		2017-08-07 04:00:00+00	206	3
5757		2017-08-08 04:00:00+00	206	3
5758		2017-08-13 04:00:00+00	206	3
5759		2017-08-14 04:00:00+00	206	3
5760		2017-08-17 04:00:00+00	206	3
5761		2017-08-20 04:00:00+00	206	3
5762		2017-08-21 04:00:00+00	206	3
5763		2017-08-22 04:00:00+00	206	3
5764		2017-08-23 04:00:00+00	206	3
5765		2017-09-03 04:00:00+00	206	3
5766		2017-09-04 04:00:00+00	206	3
5767		2017-09-05 04:00:00+00	206	3
5768		2017-09-10 04:00:00+00	206	3
5769		2017-09-11 04:00:00+00	206	3
5770		2017-09-17 04:00:00+00	206	3
5771		2017-09-18 04:00:00+00	206	3
5772		2017-10-02 04:00:00+00	206	3
5773		2017-10-10 04:00:00+00	206	3
5774		2017-10-15 04:00:00+00	206	3
5775		2017-10-16 04:00:00+00	206	3
5776		2018-03-12 04:00:00+00	206	3
5851		2017-03-12 05:00:00+00	207	3
5852		2017-03-19 04:00:00+00	207	3
5853		2017-03-26 04:00:00+00	207	3
5854		2017-03-27 04:00:00+00	207	3
5855		2017-04-02 04:00:00+00	207	3
5856		2017-04-03 04:00:00+00	207	3
5857		2017-04-09 04:00:00+00	207	3
5858		2017-04-10 04:00:00+00	207	3
5859		2017-04-11 04:00:00+00	207	3
5860		2017-04-16 04:00:00+00	207	3
5861		2017-04-17 04:00:00+00	207	3
5862		2017-04-20 04:00:00+00	207	3
5863		2017-04-23 04:00:00+00	207	3
5864		2017-04-24 04:00:00+00	207	3
5865		2017-04-25 04:00:00+00	207	3
5866		2017-04-30 04:00:00+00	207	3
5867		2017-05-01 04:00:00+00	207	3
5868		2017-05-07 04:00:00+00	207	3
5869		2017-05-08 04:00:00+00	207	3
5870		2017-05-09 04:00:00+00	207	3
5871		2017-05-10 04:00:00+00	207	3
5872		2017-05-14 04:00:00+00	207	3
5873		2017-05-15 04:00:00+00	207	3
5874		2017-05-21 04:00:00+00	207	3
5875		2017-05-22 04:00:00+00	207	3
5876		2017-05-28 04:00:00+00	207	3
5877		2017-05-29 04:00:00+00	207	3
5878		2017-05-30 04:00:00+00	207	3
5879		2017-06-02 04:00:00+00	207	3
5880		2017-06-04 04:00:00+00	207	3
5881		2017-06-05 04:00:00+00	207	3
5882		2017-06-09 04:00:00+00	207	3
5883		2017-06-10 04:00:00+00	207	3
5884		2017-06-11 04:00:00+00	207	3
5885		2017-06-12 04:00:00+00	207	3
5886		2017-06-18 04:00:00+00	207	3
5887		2017-06-19 04:00:00+00	207	3
5888		2017-06-22 04:00:00+00	207	3
5889		2017-06-23 04:00:00+00	207	3
5890		2017-06-25 04:00:00+00	207	3
5891	47	2017-06-26 04:00:00+00	207	3
5892	41	2017-07-02 04:00:00+00	207	3
5893	49	2017-07-05 04:00:00+00	207	3
5894	70	2017-07-09 04:00:00+00	207	3
5895		2017-07-10 04:00:00+00	207	3
5896	<39	2017-07-14 04:00:00+00	207	3
5897		2017-07-16 04:00:00+00	207	3
5898		2017-07-17 04:00:00+00	207	3
5899		2017-07-23 04:00:00+00	207	3
5900	<38	2017-07-24 04:00:00+00	207	3
5901		2017-07-30 04:00:00+00	207	3
5902		2017-07-31 04:00:00+00	207	3
5903		2017-08-06 04:00:00+00	207	3
5904		2017-08-07 04:00:00+00	207	3
5905		2017-08-08 04:00:00+00	207	3
5906		2017-08-13 04:00:00+00	207	3
5907		2017-08-14 04:00:00+00	207	3
5908		2017-08-17 04:00:00+00	207	3
5909		2017-08-20 04:00:00+00	207	3
5910		2017-08-21 04:00:00+00	207	3
5911		2017-08-22 04:00:00+00	207	3
5912		2017-08-23 04:00:00+00	207	3
5913		2017-09-03 04:00:00+00	207	3
5914		2017-09-04 04:00:00+00	207	3
5915		2017-09-05 04:00:00+00	207	3
5916		2017-09-10 04:00:00+00	207	3
5917		2017-09-11 04:00:00+00	207	3
5918		2017-09-17 04:00:00+00	207	3
5919		2017-09-18 04:00:00+00	207	3
5920		2017-10-02 04:00:00+00	207	3
5921		2017-10-10 04:00:00+00	207	3
5922		2017-10-15 04:00:00+00	207	3
5923		2017-10-16 04:00:00+00	207	3
5924		2018-03-12 04:00:00+00	207	3
5999		2017-03-12 05:00:00+00	208	3
6000		2017-03-19 04:00:00+00	208	3
6001		2017-03-26 04:00:00+00	208	3
6002		2017-03-27 04:00:00+00	208	3
6003		2017-04-02 04:00:00+00	208	3
6004		2017-04-03 04:00:00+00	208	3
6005		2017-04-09 04:00:00+00	208	3
6006		2017-04-10 04:00:00+00	208	3
6007		2017-04-11 04:00:00+00	208	3
6008		2017-04-16 04:00:00+00	208	3
6009		2017-04-17 04:00:00+00	208	3
6010		2017-04-20 04:00:00+00	208	3
6011		2017-04-23 04:00:00+00	208	3
6012		2017-04-24 04:00:00+00	208	3
6013		2017-04-25 04:00:00+00	208	3
6014		2017-04-30 04:00:00+00	208	3
6015		2017-05-01 04:00:00+00	208	3
6016		2017-05-07 04:00:00+00	208	3
6017		2017-05-08 04:00:00+00	208	3
6018		2017-05-09 04:00:00+00	208	3
6019		2017-05-10 04:00:00+00	208	3
6020		2017-05-14 04:00:00+00	208	3
6021		2017-05-15 04:00:00+00	208	3
6022		2017-05-21 04:00:00+00	208	3
6023		2017-05-22 04:00:00+00	208	3
6024		2017-05-28 04:00:00+00	208	3
6025		2017-05-29 04:00:00+00	208	3
6026		2017-05-30 04:00:00+00	208	3
6027		2017-06-02 04:00:00+00	208	3
6028		2017-06-04 04:00:00+00	208	3
6029		2017-06-05 04:00:00+00	208	3
6030		2017-06-09 04:00:00+00	208	3
6031		2017-06-10 04:00:00+00	208	3
6032		2017-06-11 04:00:00+00	208	3
6033		2017-06-12 04:00:00+00	208	3
6034		2017-06-18 04:00:00+00	208	3
6035		2017-06-19 04:00:00+00	208	3
6036		2017-06-22 04:00:00+00	208	3
6037		2017-06-23 04:00:00+00	208	3
6038		2017-06-25 04:00:00+00	208	3
6039	48	2017-06-26 04:00:00+00	208	3
6040	<40	2017-07-02 04:00:00+00	208	3
6041		2017-07-05 04:00:00+00	208	3
6042	55	2017-07-09 04:00:00+00	208	3
6043	45	2017-07-10 04:00:00+00	208	3
6044	44	2017-07-14 04:00:00+00	208	3
6045		2017-07-16 04:00:00+00	208	3
6046		2017-07-17 04:00:00+00	208	3
6047		2017-07-23 04:00:00+00	208	3
6048	<39	2017-07-24 04:00:00+00	208	3
6049		2017-07-30 04:00:00+00	208	3
6050		2017-07-31 04:00:00+00	208	3
6051		2017-08-06 04:00:00+00	208	3
6052		2017-08-07 04:00:00+00	208	3
6053		2017-08-08 04:00:00+00	208	3
6054		2017-08-13 04:00:00+00	208	3
6055		2017-08-14 04:00:00+00	208	3
6056		2017-08-17 04:00:00+00	208	3
6057		2017-08-20 04:00:00+00	208	3
6058		2017-08-21 04:00:00+00	208	3
6059		2017-08-22 04:00:00+00	208	3
6060		2017-08-23 04:00:00+00	208	3
6061		2017-09-03 04:00:00+00	208	3
6062		2017-09-04 04:00:00+00	208	3
6063		2017-09-05 04:00:00+00	208	3
6064		2017-09-10 04:00:00+00	208	3
6065		2017-09-11 04:00:00+00	208	3
6066		2017-09-17 04:00:00+00	208	3
6067		2017-09-18 04:00:00+00	208	3
6068		2017-10-02 04:00:00+00	208	3
6069		2017-10-10 04:00:00+00	208	3
6070		2017-10-15 04:00:00+00	208	3
6071		2017-10-16 04:00:00+00	208	3
6072		2018-03-12 04:00:00+00	208	3
6074	<33	2017-08-17 04:00:00+00	219	4
\.


--
-- Data for Name: stations_species; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.stations_species (id, species_name, italicize) FROM stdin;
1	Mytilus edulis	t
2	Ocean Quahog	f
3	Mya arenaria	t
4	Other	f
\.


--
-- Data for Name: stations_station; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.stations_station (id, station_name, station_location, latitude, longitude, state) FROM stdin;
177	10.11	Ogunquit River	43.2541000	-70.5940000	Maine
178	10.33	Spurwink River	43.5809000	-70.2754000	Maine
179	12.01	Basin Point	43.7424000	-70.0439000	Maine
180	12.03	Potts Point	43.7354000	-70.0264000	Maine
181	12.13	Lumbo's Hole	43.8313000	-70.0288000	Maine
182	12.28	Bear Island	43.7923000	-69.8824000	Maine
183	12.34	Head Beach	43.7211000	-69.8516000	Maine
184	15.25	Christmas Cove Town Landing	43.8470000	-69.5537000	Maine
185	16.41	Port Clyde	43.9273000	-69.2528000	Maine
186	19.15	Stonington	44.1562000	-68.6667000	Maine
187	21.09	Bass Harbor	44.1562000	-68.6667000	Maine
188	23.07	Corea Harbor	44.3986000	-67.9705000	Maine
189	24.08	Ripley Point	44.5213000	-67.7973000	Maine
190	25.06	Kelley Point	44.5511000	-67.5667000	Maine
191	26.07	Cutler Harbor	44.7193000	-67.2048000	Maine
192	26.15	Lubec Channel	44.8492000	-66.9749000	Maine
193	27.05	Gove Point	44.9102000	-67.0628000	Maine
194	27.46	Gleason Cove	44.9674000	-67.0539000	Maine
195	MB11	Cohasset Little Harbor	42.2783000	-70.7979000	Massachusetts
196	MB7	Scituate Yacht Club	42.2034000	-70.7239000	Massachusetts
197	MB5	Marshfield Damon Point	42.1519000	-70.7277000	Massachusetts
198	CCB42	Plymouth, harbor ramp	41.9712000	-70.6572000	Massachusetts
199	BB45	Sandwich CCC NE	41.7664475	-70.4693499	Massachusetts
200	OC3	Orleans Robert’s Cove	41.8358000	-69.9717000	Massachusetts
201	OC5	Eastham Hemenway	41.8231000	-69.9651000	Massachusetts
202	OC6	Eastham Salt Pond	41.8359000	-69.9722000	Massachusetts
203	SC52	Chatham Nickerson Market	41.6891000	-69.9515000	Massachusetts
204	CCB25	Dennis Sesuit Harbor	41.7600000	-70.1545000	Massachusetts
205	N2	Newburyport Merrimack	42.8195000	-70.9494000	Massachusetts
206	N4	Ipswich Plum Island Sound	42.7343000	-70.8031000	Massachusetts
207	N7	Essex Conomo Point	42.6541000	-70.7460000	Massachusetts
208	N9	Gloucester Annisquam Yacht Club	42.6523000	-70.6788330	Massachusetts
209	CCB4	Provincetown Harbor	42.0515000	-70.1720000	Massachusetts
210	CCB11	Wellfleet Harbor	41.9045000	-70.0379000	Massachusetts
211	Unlisted	Eastham/quahog	41.8369636	-70.0211373	Massachusetts
214	V24	Edgartown, MVCO	41.3931000	-70.5675000	Massachusetts
219	NT3	Wauwinet, Nantucket	41.3310000	-69.9984000	Massachusetts
\.


--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.users_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, name) FROM stdin;
1	argon2$argon2i$v=19$m=512,t=2,p=2$VU83ZUl3anlCRnBr$81FNXVPKqzDedBZ/qDDP2g	2019-01-18 18:23:04.416587+00	t	eandrews			eandrews@whoi.edu	t	t	2018-12-17 19:03:29.68439+00	
\.


--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.users_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: habmap_database
--

COPY public.users_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.account_emailaddress_id_seq', 1, true);


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.account_emailconfirmation_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 84, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 4036, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 50, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 68, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, false);


--
-- Name: esp_instrument_deployment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.esp_instrument_deployment_id_seq', 16, true);


--
-- Name: esp_instrument_espdatapoint_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.esp_instrument_espdatapoint_id_seq', 1704, true);


--
-- Name: esp_instrument_espinstrument_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.esp_instrument_espinstrument_id_seq', 4, true);


--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.socialaccount_socialaccount_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_sites_id_seq', 1, false);


--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.socialaccount_socialtoken_id_seq', 1, false);


--
-- Name: stations_datapoint_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.stations_datapoint_id_seq', 6074, true);


--
-- Name: stations_species_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.stations_species_id_seq', 4, true);


--
-- Name: stations_station_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.stations_station_id_seq', 367, true);


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.users_user_groups_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.users_user_id_seq', 1, true);


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: habmap_database
--

SELECT pg_catalog.setval('public.users_user_user_permissions_id_seq', 1, false);


--
-- Name: account_emailaddress account_emailaddress_email_key; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_email_key UNIQUE (email);


--
-- Name: account_emailaddress account_emailaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_pkey PRIMARY KEY (id);


--
-- Name: account_emailconfirmation account_emailconfirmation_key_key; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_key_key UNIQUE (key);


--
-- Name: account_emailconfirmation account_emailconfirmation_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: esp_instrument_deployment esp_instrument_deployment_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.esp_instrument_deployment
    ADD CONSTRAINT esp_instrument_deployment_pkey PRIMARY KEY (id);


--
-- Name: esp_instrument_espdatapoint esp_instrument_espdatapoint_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.esp_instrument_espdatapoint
    ADD CONSTRAINT esp_instrument_espdatapoint_pkey PRIMARY KEY (id);


--
-- Name: esp_instrument_espinstrument esp_instrument_espinstrument_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.esp_instrument_espinstrument
    ADD CONSTRAINT esp_instrument_espinstrument_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_provider_uid_fc810c6e_uniq; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_provider_uid_fc810c6e_uniq UNIQUE (provider, uid);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq UNIQUE (socialapp_id, site_id);


--
-- Name: socialaccount_socialapp socialaccount_socialapp_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.socialaccount_socialapp
    ADD CONSTRAINT socialaccount_socialapp_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp_sites_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq UNIQUE (app_id, account_id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_pkey PRIMARY KEY (id);


--
-- Name: stations_datapoint stations_datapoint_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.stations_datapoint
    ADD CONSTRAINT stations_datapoint_pkey PRIMARY KEY (id);


--
-- Name: stations_species stations_species_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.stations_species
    ADD CONSTRAINT stations_species_pkey PRIMARY KEY (id);


--
-- Name: stations_station stations_station_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.stations_station
    ADD CONSTRAINT stations_station_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_user_id_group_id_b88eab82_uniq; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_group_id_b88eab82_uniq UNIQUE (user_id, group_id);


--
-- Name: users_user users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_permission_id_43338c45_uniq; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_permission_id_43338c45_uniq UNIQUE (user_id, permission_id);


--
-- Name: users_user users_user_username_key; Type: CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_username_key UNIQUE (username);


--
-- Name: account_emailaddress_email_03be32b2_like; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX account_emailaddress_email_03be32b2_like ON public.account_emailaddress USING btree (email varchar_pattern_ops);


--
-- Name: account_emailaddress_user_id_2c513194; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX account_emailaddress_user_id_2c513194 ON public.account_emailaddress USING btree (user_id);


--
-- Name: account_emailconfirmation_email_address_id_5b7f8c58; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX account_emailconfirmation_email_address_id_5b7f8c58 ON public.account_emailconfirmation USING btree (email_address_id);


--
-- Name: account_emailconfirmation_key_f43612bd_like; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX account_emailconfirmation_key_f43612bd_like ON public.account_emailconfirmation USING btree (key varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: esp_instrument_deployment_espinstrument_id_bd8ad35c; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX esp_instrument_deployment_espinstrument_id_bd8ad35c ON public.esp_instrument_deployment USING btree (espinstrument_id);


--
-- Name: esp_instrument_espdatapoint_deployment_id_3fcaa755; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX esp_instrument_espdatapoint_deployment_id_3fcaa755 ON public.esp_instrument_espdatapoint USING btree (deployment_id);


--
-- Name: socialaccount_socialaccount_user_id_8146e70c; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX socialaccount_socialaccount_user_id_8146e70c ON public.socialaccount_socialaccount USING btree (user_id);


--
-- Name: socialaccount_socialapp_sites_site_id_2579dee5; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX socialaccount_socialapp_sites_site_id_2579dee5 ON public.socialaccount_socialapp_sites USING btree (site_id);


--
-- Name: socialaccount_socialapp_sites_socialapp_id_97fb6e7d; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX socialaccount_socialapp_sites_socialapp_id_97fb6e7d ON public.socialaccount_socialapp_sites USING btree (socialapp_id);


--
-- Name: socialaccount_socialtoken_account_id_951f210e; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX socialaccount_socialtoken_account_id_951f210e ON public.socialaccount_socialtoken USING btree (account_id);


--
-- Name: socialaccount_socialtoken_app_id_636a42d7; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX socialaccount_socialtoken_app_id_636a42d7 ON public.socialaccount_socialtoken USING btree (app_id);


--
-- Name: stations_datapoint_species_id_813f105a; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX stations_datapoint_species_id_813f105a ON public.stations_datapoint USING btree (species_id);


--
-- Name: stations_datapoint_station_id_8fdff48f; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX stations_datapoint_station_id_8fdff48f ON public.stations_datapoint USING btree (station_id);


--
-- Name: users_user_groups_group_id_9afc8d0e; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX users_user_groups_group_id_9afc8d0e ON public.users_user_groups USING btree (group_id);


--
-- Name: users_user_groups_user_id_5f6f5a90; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX users_user_groups_user_id_5f6f5a90 ON public.users_user_groups USING btree (user_id);


--
-- Name: users_user_user_permissions_permission_id_0b93982e; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX users_user_user_permissions_permission_id_0b93982e ON public.users_user_user_permissions USING btree (permission_id);


--
-- Name: users_user_user_permissions_user_id_20aca447; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX users_user_user_permissions_user_id_20aca447 ON public.users_user_user_permissions USING btree (user_id);


--
-- Name: users_user_username_06e46fe6_like; Type: INDEX; Schema: public; Owner: habmap_database
--

CREATE INDEX users_user_username_06e46fe6_like ON public.users_user USING btree (username varchar_pattern_ops);


--
-- Name: account_emailaddress account_emailaddress_user_id_2c513194_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_user_id_2c513194_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_emailconfirmation account_emailconfirm_email_address_id_5b7f8c58_fk_account_e; Type: FK CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirm_email_address_id_5b7f8c58_fk_account_e FOREIGN KEY (email_address_id) REFERENCES public.account_emailaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: esp_instrument_deployment esp_instrument_deplo_espinstrument_id_bd8ad35c_fk_esp_instr; Type: FK CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.esp_instrument_deployment
    ADD CONSTRAINT esp_instrument_deplo_espinstrument_id_bd8ad35c_fk_esp_instr FOREIGN KEY (espinstrument_id) REFERENCES public.esp_instrument_espinstrument(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: esp_instrument_espdatapoint esp_instrument_espda_deployment_id_3fcaa755_fk_esp_instr; Type: FK CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.esp_instrument_espdatapoint
    ADD CONSTRAINT esp_instrument_espda_deployment_id_3fcaa755_fk_esp_instr FOREIGN KEY (deployment_id) REFERENCES public.esp_instrument_deployment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_account_id_951f210e_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_account_id_951f210e_fk_socialacc FOREIGN KEY (account_id) REFERENCES public.socialaccount_socialaccount(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_app_id_636a42d7_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_app_id_636a42d7_fk_socialacc FOREIGN KEY (app_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_site_id_2579dee5_fk_django_si; Type: FK CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_site_id_2579dee5_fk_django_si FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc FOREIGN KEY (socialapp_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: stations_datapoint stations_datapoint_species_id_813f105a_fk_stations_species_id; Type: FK CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.stations_datapoint
    ADD CONSTRAINT stations_datapoint_species_id_813f105a_fk_stations_species_id FOREIGN KEY (species_id) REFERENCES public.stations_species(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: stations_datapoint stations_datapoint_station_id_8fdff48f_fk_stations_station_id; Type: FK CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.stations_datapoint
    ADD CONSTRAINT stations_datapoint_station_id_8fdff48f_fk_stations_station_id FOREIGN KEY (station_id) REFERENCES public.stations_station(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_group_id_9afc8d0e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_group_id_9afc8d0e_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_user_id_5f6f5a90_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_5f6f5a90_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_perm_permission_id_0b93982e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_perm_permission_id_0b93982e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_20aca447_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: habmap_database
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_20aca447_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

